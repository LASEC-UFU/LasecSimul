# Mapeamento inicial de classes SimulIDE

O código tenta primeiro a classe declarada pelo próprio catálogo (`package.simulidePaint.source.className`). O fallback incluído cobre:

| SimulIDE | LasecSimul typeId |
|---|---|
| Resistor | passive.resistor |
| VarResistor | passive.variable_resistor |
| Potentiometer | passive.potentiometer |
| ResistorDip | passive.resistor_dip |
| Capacitor | passive.capacitor |
| elCapacitor | passive.electrolytic_capacitor |
| Inductor | passive.inductor |
| VarCapacitor | passive.variable_capacitor |
| VarInductor | passive.variable_inductor |
| Thermistor | sensors.thermistor |
| Diode | active.diode |
| Zener | active.zener |
| OpAmp | active.opamp |
| Comparator | active.comparator |
| MuxAnalog | active.analog_mux |
| VoltReg | active.volt_regulator |
| Led | outputs.led |
| LedRgb | outputs.led_rgb |
| LedBar | outputs.led_bar |
| LedMatrix | outputs.led_matrix |
| SevenSegment | outputs.seven_segment |
| DcMotor | outputs.dc_motor |
| Stepper | outputs.stepper |
| Lamp | outputs.incandescent_lamp |
| Push | switches.push |
| Switch | switches.switch |
| SwitchDip | switches.switch_dip |
| Relay | switches.relay |
| KeyPad | switches.keypad |
| Bus | connectors.bus |
| Tunnel | connectors.tunnel |
| Socket | connectors.socket |
| Header | connectors.header |
| Probe | meters.probe |
| Ampmeter | meters.ampmeter |
| Voltimeter / Voltmeter | instruments.voltmeter |
| FreqMeter | meters.freqmeter |
| Oscope / Oscilloscope | meters.oscope |
| LogicAnalyzer | meters.logic_analyzer |
| DcVoltageSource | sources.dc_voltage |
| FixedVolt | sources.fixed_volt |
| Clock | sources.clock |
| WaveGen | sources.wave_gen |
| VoltSource | sources.voltage_source |
| CurrSource | sources.current_source |
| Csource | sources.controlled_source |
| Battery | sources.battery |
| Rail | sources.rail |
| Ground | other.ground |
| TextComponent / Text | graphics.text |
| Rectangle | graphics.rectangle |
| Ellipse | graphics.ellipse |
| Line | graphics.line |
| Image | graphics.image |

## Propriedades

O mapeador começa pelos `defaultProperties` e `propertySchema` do catálogo. Propriedades do SimulIDE são comparadas sem diferença de maiúsculas/minúsculas, `_`, `-` ou espaços. Existem aliases especiais para frequência, `SatCurrent`, `Norm_Close`, etc.

Valores numéricos entendem prefixos de engenharia:

- p, n, u/µ/μ, m, k, M, G, T;
- aceita `°` e `º` em unidades de temperatura;
- exemplos: `1 kΩ` → `1000`, `10 uF` → `0.00001`, `152.4 ºC` → `152.4`.

Propriedades ainda sem equivalente não impedem a importação: são preservadas como `__ui_simulideRaw_*` e registradas como avisos. Tipo/pino sem equivalente também **não bloqueia** a v4: o componente vira `import.simulide.unresolved`, seus pins conectados e fios são preservados e o usuário finaliza depois.


## Mapeamento visual detalhado

Os gráficos têm regras específicas que prevalecem sobre aliases globais. Em especial, `TextComponent.Color` é fundo, enquanto `Font_Color` é a cor do texto. `Line` usa `H_size`/`V_size` como vetor geométrico; não é reduzida a uma rotação cardinal. `Z_Value` é mantido em `properties.zValue`. Consulte `GRAPHICS-FIDELITY.md`.


## Casos reais adicionais da v4

```text
Thermistor lPin -> a
Thermistor rPin -> b
Thermistor B -> b_coeff
Thermistor R25 -> r25

OpAmp Out_Imped -> outImpedance
OpAmp Power_Pins -> powerPins
OpAmp Switch_Pins -> switchPins
OpAmp Volt_Pos -> voltPos
OpAmp Volt_Neg -> voltNeg

LED Grounded -> grounded
FixedVolt Small -> small
Probe Small -> small
```
