# Changeset esperado no LasecSimul

## Arquivos novos

```text
extension/src/import/simulide/SimulideTypes.ts
extension/src/import/simulide/SimulideParser.ts
extension/src/import/simulide/SimulideGeometry.ts
extension/src/import/simulide/SimulideComponentMapper.ts
extension/src/import/simulide/SimulidePropertyMapper.ts
extension/src/import/simulide/SimulideToLasecConverter.ts
extension/src/import/simulide/SimulideImporter.ts
extension/src/import/simulide/SimulideImportReport.ts
extension/src/import/simulide/SimulideOpenWorkflow.ts
extension/src/import/simulide/index.ts
extension/src/ui/panels/SimulideImportCustomEditorProvider.ts
```

## Arquivos existentes a alterar

### `extension/src/project/projectCommands.ts`

- importar `isSimulideCircuitPath` e `openSimulideAsLsproj`;
- `openProjectCommand()` passa a aceitar `.lsproj`, `.sim1`, `.sim2`;
- adicionar `openSupportedProjectFile()`;
- `.lsproj` continua chamando `openProjectFile()` sem mudança de semântica.

### `extension/src/extension.ts`

- importar `SimulideImportCustomEditorProvider`;
- registrar `lasecsimul.simulideImportEditor` com as mesmas callbacks de abertura usadas pelo provider de `.lsproj`.

### `extension/package.json`

- adicionar `customEditors` para `*.sim1` e `*.sim2`;
- opcional/recomendado: script `test:simulide-importer`.

## Arquivos que NÃO devem ser alterados para essa feature

- Core C++ para entender `.sim1/.sim2`;
- `ProjectSerializer.ts` para interpretar XML;
- `ProjectSerializer.ts` NÃO deve interpretar SimulIDE; a única extensão de schema da v4 é opcional e específica de settings (`reactivePeriodSeconds`).
- extensão oficial `.lsproj`.


## Alterações adicionais obrigatórias da v4

### `extension/src/core/coreLifecycle.ts`

- não enviar `import.simulide.unresolved` ao Core;
- reconstruir pins do placeholder a partir de `__ui_simulidePinIds`.

### `extension/src/ui/webview/componentSymbols.ts` / render da Webview

- desenhar placeholder SimulIDE selecionável/movível;
- manter pins e fios visíveis;
- manter patches de fidelidade gráfica e variante `Small`.

### `extension/src/project/ProjectTypes.ts` / `ProjectSerializer.ts`

- adicionar/round-trip `simulationSettings.reactivePeriodSeconds?`.

### Core/Catalog

- `active.opamp`: gain/outImpedance/powerPins/switchPins/voltPos/voltNeg;
- `outputs.led`: grounded;
- packages `sources.fixed_volt` e `meters.probe`: variante `small`.

Veja patches `0004` e `0005`.
