# Validação com circuitos reais — v4

## Política de validação

A v4 não mede sucesso apenas por “zero erro”. Ela mede:

1. quantos componentes foram emitidos;
2. quantos foram convertidos integralmente;
3. quantos viraram placeholder;
4. quantos connectors foram preservados;
5. quais diferenças funcionais ainda dependem do Core/render.

## Fixtures

```text
devkitc_test.sim2
filto_aliasing0.sim2
filto_aliasing1.sim2
NTC_ApInst.sim1
```

## NTC_ApInst.sim1 — validação executada nesta v4

Resultado da camada parser/conversor:

```text
componentes no arquivo: 22
componentes emitidos: 22
nodes originais: 11
connectors no arquivo: 36
condutores emitidos: 36
placeholders: 1
fatal errors: 0
```

### Arduino Uno

Preservado como:

```text
typeId = import.simulide.unresolved
sourceType = Subcircuit
sourceId = Uno-63
pins = [A5, 1, 0]
Program = ../.pio/build/uno/firmware.hex
Frequency = 16 MHz (em mainCompProps/raw)
```

Todos os fios ligados a `A5/1/0` permanecem no `ProjectTopology`.

### Thermistor

Validado:

```text
Thermistor -> sensors.thermistor
lPin -> a
rPin -> b
Temp="152.4 ºC" -> temp=152.4
B="3455" -> b_coeff=3455
R25="10000 Ω" -> r25=10000
```

### Connector uid duplicado

O arquivo contém repetições de:

```text
Connector-302
Connector-303
```

A v4 mantém todos os fios e gera ids únicos:

```text
Connector-302
Connector-302.imported-2
Connector-303
Connector-303.imported-2
```

### Settings

Cabeçalho:

```text
stepSize=1000000
stepsPS=1000000
NLsteps=100000
reaStep=1000000
```

Conversão:

```text
initial/minimum/maximumStepSeconds = 1e-6
adaptiveTimeStep = false
timeScale = 1
maximumNewtonIterations = 100000
reactivePeriodSeconds = 1e-6
```

## Três fixtures `.sim2` anteriores

A v3 já havia confirmado preservação estrutural total na camada do conversor:

| arquivo | componentes | nodes | connectors |
|---|---:|---:|---:|
| devkitc_test.sim2 | 29/29 | 0 | 23/23 |
| filto_aliasing0.sim2 | 16/16 | 6 | 23/23 |
| filto_aliasing1.sim2 | 31/31 | 13 | 49/49 |

A v4 mantém os aliases/pins daquela revisão e muda apenas a política de falha: novos gaps passam a placeholder/warning em vez de cancelar o arquivo inteiro.

## Pendências de integração que devem ser testadas no checkout real

- OpAmp: clamp de alimentação e `outImpedance`;
- LED `grounded=true`;
- variante visual `Small` de Fixed Voltage/Probe;
- renderização e pins do placeholder;
- round-trip de `reactivePeriodSeconds` no `ProjectSerializer`;
- aviso de simulação parcial quando houver placeholders.
