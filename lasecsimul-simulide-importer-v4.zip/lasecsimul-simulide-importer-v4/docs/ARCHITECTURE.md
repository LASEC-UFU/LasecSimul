# Arquitetura — importação SimulIDE → LasecSimul

## Objetivo

Ao abrir `nome.sim1` ou `nome.sim2`, o LasecSimul deve:

1. reconhecer o formato legado;
2. ler o circuito sem modificar o arquivo original;
3. converter para `ProjectDocument` schema atual (`LS_PROJ_SCHEMA_VERSION`);
4. validar tipos, pinos e topologia;
5. gravar `nome.lsproj` no mesmo diretório;
6. abrir `nome.lsproj` pelo pipeline nativo `openProjectFile()`;
7. a partir daí, `Ctrl+S` trabalha somente no `.lsproj`.

A extensão oficial permanece **`.lsproj`**.

## Fluxo

```text
*.lsproj ────────────────────────────────┐
                                         ▼
                                  openProjectFile()
                                         ▲
                                         │
*.sim1 / *.sim2                         │
      │                                  │
      ▼                                  │
SimulideParser                           │
      │                                  │
      ▼                                  │
SimulideCircuitDocument (IR)             │
      │                                  │
      ▼                                  │
SimulideToLasecConverter                 │
      │                                  │
      ▼                                  │
ProjectDocument v2                       │
      │                                  │
      ▼                                  │
ProjectSerializer.save(nome.lsproj) ─────┘
```

## Separação de responsabilidades

- `SimulideParser.ts`: sintaxe do arquivo do SimulIDE.
- `SimulideComponentMapper.ts`: `itemtype` → `typeId` e alias de pino → pinId canônico.
- `SimulidePropertyMapper.ts`: propriedades e unidades.
- `SimulideGeometry.ts`: posição, rotação e flips.
- `SimulideToLasecConverter.ts`: IR → `ProjectDocument`.
- `SimulideImporter.ts`: I/O de arquivo e nome do `.lsproj`.
- `SimulideOpenWorkflow.ts`: interação VS Code, colisão de arquivo e abertura.
- `SimulideImportCustomEditorProvider.ts`: duplo clique em `.sim1/.sim2`.

`ProjectSerializer` não aprende nada sobre SimulIDE. O Core e a Webview também não precisam saber a origem do arquivo depois da conversão.

## Tipos

A resolução usa primeiro `package.simulidePaint.source.className` do catálogo atual. Isso reaproveita a informação já existente no LasecSimul. Há um mapa fallback para classes conhecidas quando o catálogo não declara `className`.

## Pinos

A conversão usa `package.pins[].aliases`. Exemplos já presentes no projeto:

- resistor: `lPin`/`p1` → `pin-1`, `rPin`/`p2` → `pin-2`;
- potenciômetro: `PinA`/`PinM`/`PinB` → `pin-1`/`pin-2`/`pin-3`;
- diodo/LED: aliases legados → `anode`/`cathode`.

## Nodes

`itemtype="Node"` não vira componente. Ele vira diretamente `topology.nodes[]`. Qualquer `Node-X-0`, `Node-X-1` ou `Node-X-2` do SimulIDE referencia o mesmo `nodeId` do LasecSimul.

## Connectors

`pointList` do SimulIDE inclui as extremidades. `ProjectTopology.conductors[].vertices` guarda apenas pontos intermediários. Portanto o conversor usa `points.slice(1, -1)`.

## Segurança

- `.sim1/.sim2` nunca é alterado.
- se `<nome>.lsproj` já existe, o usuário escolhe: abrir existente, substituir, criar cópia ou cancelar;
- componente sem equivalente ou com pino incompatível vira **placeholder + warning**; a conversão continua e os fios são preservados;
- propriedade desconhecida gera **aviso**, preservando defaults do LasecSimul;
- relatório completo vai para o Output Channel `LasecSimul: Importação SimulIDE`.
