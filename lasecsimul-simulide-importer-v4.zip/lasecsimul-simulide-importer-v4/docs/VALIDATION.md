# Validação técnica — v4

## Executado neste pacote

### TypeScript puro

Os módulos abaixo foram compilados com `strict=true` usando stubs compatíveis com os contratos relevantes do LasecSimul:

```text
SimulideTypes.ts
SimulideParser.ts
SimulideGeometry.ts
SimulideComponentMapper.ts
SimulidePropertyMapper.ts
SimulideToLasecConverter.ts
```

Resultado:

```text
PURE_COMPILE_OK
```

### Fixture real NTC_ApInst.sim1

O parser/conversor foi executado com catálogo compatível com os componentes usados no fixture.

Resultado:

```text
NTC_REAL_FIXTURE_OK
22 componentes emitidos
11 nodes originais
36 condutores preservados
1 placeholder Arduino Uno
Thermistor 152.4 ºC corretamente convertido
Connector ids duplicados normalizados
```

## Não executado neste pacote

O pacote não é um checkout completo do LasecSimul e não contém seus `node_modules`/Core build. Portanto ainda é obrigatório, após aplicar os patches:

```text
npm/tsc da Extension
unit tests da Extension
build do Core
CTest/testes do Core
E2E de abrir/salvar/reabrir os 4 fixtures reais
```

Não declarar equivalência total antes desses testes.
