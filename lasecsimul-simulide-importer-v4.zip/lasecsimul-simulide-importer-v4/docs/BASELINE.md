# Baseline consultada para preparar o pacote

Repositórios analisados:

- `josuemoraisgh/SimulIDE-dev`, branch `master`;
- `LASEC-UFU/LasecSimul`, branch `main`.

Pontos observados no LasecSimul:

- `ProjectTypes.ts`: `LS_PROJ_SCHEMA_VERSION = 2` na baseline consultada;
- `ProjectSerializer.ts`: lê/grava JSON `.lsproj`, com `topology` como fonte canônica;
- `projectCommands.ts`: contém `openProjectCommand()` e `openProjectFile()`;
- `ProjectCustomEditorProvider.ts`: custom editor gatilho para `*.lsproj`;
- `extension/package.json`: `*.lsproj` registrado em `customEditors`;
- catálogo: `geometryConvention = "simulide-terminal-v1"` e diversas entradas possuem `package.simulidePaint.source.className` + `package.pins[].aliases`.

Pontos observados no SimulIDE:

- `Circuit::loadCircuit()` chama `loadStrDoc()`;
- `loadStrDoc()` processa `<item itemtype="Connector">`, `<item itemtype="Node">` e componentes;
- connector usa `startpinid`, `endpinid`, `pointList`, `uid`;
- `Circuit::circuitToString()` grava componentes, nodes e connectors;
- `Connector::refreshPointList()` inclui início e fim na lista de pontos;
- `Component` persiste `Pos`, `rotation`, `hflip`, `vflip`, `label`, `Show_id`, `Show_Val`, `ShowProp`;
- `Node` possui três pinos no SimulIDE, mas isso é uma implementação local; no LasecSimul o nó canônico pode ter grau N.

O agente deve sempre reler a versão atual antes de aplicar, porque esses arquivos podem ter evoluído.
