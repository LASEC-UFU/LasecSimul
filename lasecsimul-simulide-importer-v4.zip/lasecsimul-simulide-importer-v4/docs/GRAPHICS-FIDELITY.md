# Fidelidade gráfica SimulIDE -> LasecSimul

A revisão v2 do importador cobre explicitamente os componentes gráficos persistidos pelo SimulIDE.

## Rectangle (frame/retângulo)

Converte:

- `Pos` -> posição;
- `rotation`/`Angle` -> rotação;
- `H_size` -> `width`;
- `V_size` -> `height`;
- `Color` -> `fill`;
- `Border` -> `strokeWidth`;
- borda preta original -> `stroke=#000000`;
- `Opacity` -> `fillOpacity`;
- `Z_Value` -> `zValue`.

O `zValue` é importante para frames/fundos: formas negativas ficam atrás dos componentes normais.

## Ellipse

Mesmos campos de `Shape`: tamanho, preenchimento, borda, opacidade, posição, rotação e z-order.

## Line

O SimulIDE não persiste uma simples `length`: ele desenha a linha usando `H_size` e `V_size`.
O importador grava:

- `deltaX = H_size`;
- `deltaY = -V_size`;
- `length = hypot(H_size,V_size)`;
- `Color` -> `stroke`;
- `Border` -> `strokeWidth`;
- `Opacity` -> `opacity`;
- `Z_Value` -> `zValue`.

Isso preserva inclusive linhas diagonais não-cardinais.

## TextComponent (caixa de texto)

Converte:

- conteúdo `Text`, inclusive múltiplas linhas e entidades numéricas XML;
- `Margin`;
- `Border`;
- `Color` (cor de fundo);
- `Opacity` (opacidade do fundo);
- `Font`;
- `Font_Color`;
- `Font_Size`;
- `Fixed_Width`;
- posição e rotação.

A dimensão da caixa de texto é reestimada a partir de texto, fonte, número de linhas e margem.
A métrica exata do Qt pode diferir alguns pixels do SVG/browser, mas nenhum desses dados é descartado.

## Image

Converte:

- `H_size`/`V_size`;
- `Border`;
- `Image_File`;
- `BckGndData` (hex do SimulIDE -> base64 `imageData` + `imageMime`);
- `Z_Value`.

Se não existir `BckGndData`, o importador tenta ler `Image_File` relativo ao diretório do `.sim1`/
`.sim2` e embute os bytes no `.lsproj`. Se o arquivo externo estiver ausente, gera warning no
relatório e mantém o caminho original.

## Limite deliberado

Fontes são motores diferentes (QFont/Qt no SimulIDE e SVG/CSS no LasecSimul). Família, tamanho,
cor, fixed-pitch, conteúdo e margem são preservados, mas a largura visual de glifos pode variar
ligeiramente entre plataformas. Não há perda silenciosa: o dado original permanece no `.lsproj`.
