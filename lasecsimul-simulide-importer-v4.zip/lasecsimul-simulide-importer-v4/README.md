# LasecSimul — Importador SimulIDE v4

Pacote de implementação para abrir circuitos SimulIDE (`.sim1` / `.sim2`) no LasecSimul e convertê-los para **`.lsproj`**.

## Mudança principal da v4

A conversão passa a ser **best-effort com fidelidade máxima**:

- componente suportado → conversão normal;
- componente parcialmente compatível → preservado como placeholder com sugestão do tipo-alvo;
- componente sem equivalente → placeholder `import.simulide.unresolved`;
- propriedades desconhecidas → preservadas como `__ui_simulideRaw_*`;
- pin desconhecido → não descarta o fio;
- endpoint impossível → fio preservado em nó sintético com warning;
- erro fatal só para arquivo realmente ilegível/corrompido ou falha de gravação.

Isso significa que um Arduino Uno ainda não suportado **não cancela** a conversão de todo o circuito.

## Arquivos reais usados como regressão

```text
extension/test/fixtures/simulide/real-user/devkitc_test.sim2
extension/test/fixtures/simulide/real-user/filto_aliasing0.sim2
extension/test/fixtures/simulide/real-user/filto_aliasing1.sim2
extension/test/fixtures/simulide/real-user/NTC_ApInst.sim1
```

O `NTC_ApInst.sim1` revelou e motivou estas correções adicionais:

- Arduino Uno preservado como placeholder, incluindo `A5`, `1`, `0`, firmware e frequência;
- `Thermistor -> sensors.thermistor`;
- `lPin/rPin -> a/b` no Thermistor;
- suporte a `152.4 ºC`;
- `B -> b_coeff` e `R25 -> r25`;
- OpAmp com `Out_Imped`, `Power_Pins`, `Volt_Pos/Volt_Neg` preservados;
- `Connector` com `uid` duplicado renomeado deterministicamente sem perda de fio;
- `stepSize/stepsPS/NLsteps/reaStep` convertidos/preservados.

## Fluxo esperado

```text
circuito.sim1/.sim2
      ↓
parse + mapeamento
      ↓
ProjectDocument
      ↓
circuito.lsproj
      ↓
pipeline normal do LasecSimul
```

O arquivo SimulIDE original não é alterado. `.lsproj` continua sendo a extensão oficial.

## Patches

```text
0001-integrate-simulide-importer.patch
0002-graphical-fidelity.patch
0003-real-circuit-compatibility.patch
0004-best-effort-placeholders-and-settings.patch
0005-electrical-and-visual-fidelity-real-fixtures.patch
```

Os patches são semânticos: aplique pelo estado atual do checkout do LasecSimul.

## Validação local deste pacote

- compilação TypeScript estrita dos módulos puros: OK;
- fixture real `NTC_ApInst.sim1`: OK na camada parser/conversor;
- 22 componentes emitidos;
- 11 nodes originais;
- 36/36 condutores preservados;
- 1 placeholder (`Arduino Uno`);
- Thermistor `Temp=152.4`, `B=3455`, `R25=10000`;
- ids repetidos de Connector foram normalizados sem perda.

A integração final ainda deve executar o build/test completo no checkout real do LasecSimul, especialmente para as alterações de Core/render do OpAmp, LED grounded, `Small` e placeholder UI.

## Instrução principal para o agente

Use [`AGENT_PROMPT.md`](AGENT_PROMPT.md).
