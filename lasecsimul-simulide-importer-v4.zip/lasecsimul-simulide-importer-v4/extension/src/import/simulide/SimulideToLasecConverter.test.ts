import * as assert from "assert";
import type { WebviewComponentCatalogEntry } from "../../ui/webview/model";
import { parseSimulideCircuit } from "./SimulideParser";
import { convertSimulideDocument } from "./SimulideToLasecConverter";
import { hasImportErrors } from "./SimulideTypes";

const catalog: WebviewComponentCatalogEntry[] = [
  {
    typeId: "passive.resistor",
    label: "Resistor",
    category: "Passivos",
    pinCount: 2,
    pinIds: ["pin-1", "pin-2"],
    defaultProperties: { resistance: 1000 },
    package: {
      width: 32,
      height: 16,
      pins: [
        { id: "pin-1", aliases: ["p1", "lPin"], x: 0, y: 8, angle: 180, length: 8, label: "" },
        { id: "pin-2", aliases: ["p2", "rPin"], x: 32, y: 8, angle: 0, length: 8, label: "" },
      ],
      simulidePaint: {
        version: 1,
        source: { className: "Resistor" },
        bounds: { x: -16, y: -8, w: 32, h: 16 },
        primitives: [],
      },
    },
  },
  {
    typeId: "graphics.rectangle", label: "Rectangle", category: "Graphical", pinCount: 0, pinIds: [],
    defaultProperties: { width: 60, height: 40, stroke: "#000000", fill: "none", strokeWidth: 1 },
  },
  {
    typeId: "graphics.ellipse", label: "Ellipse", category: "Graphical", pinCount: 0, pinIds: [],
    defaultProperties: { width: 40, height: 40, stroke: "#000000", fill: "none" },
  },
  {
    typeId: "graphics.line", label: "Line", category: "Graphical", pinCount: 0, pinIds: [],
    defaultProperties: { length: 40, stroke: "#000000" },
  },
  {
    typeId: "graphics.text", label: "Text", category: "Graphical", pinCount: 0, pinIds: [],
    defaultProperties: { text: "Texto", fontSize: 11, color: "#1f2937" },
  },
  {
    typeId: "graphics.image", label: "Image", category: "Graphical", pinCount: 0, pinIds: [],
    defaultProperties: { path: "", width: 80, height: 80 },
  },
  {
    typeId: "outputs.aip31068_i2c", label: "AIP31068", category: "Saídas", pinCount: 2,
    pinIds: ["scl", "sda"], defaultProperties: { rows: 2, columns: 16, i2cAddress: 62, frequency: 100 },
    package: { width: 100, height: 40, pins: [
      { id: "scl", x: 0, y: 0, angle: 0, length: 0 }, { id: "sda", x: 0, y: 8, angle: 0, length: 0 },
    ] },
  },
  {
    typeId: "peripherals.serialterm", label: "SerialTerm", category: "Micro", pinCount: 2,
    pinIds: ["tx", "rx"], defaultProperties: { baudrate: 115200, data_bits: 8, stop_bits: 1 },
    package: { width: 40, height: 40, pins: [
      { id: "tx", x: 0, y: 0, angle: 0, length: 0 }, { id: "rx", x: 0, y: 8, angle: 0, length: 0 },
    ] },
  },
  {
    typeId: "sources.fixed_volt", label: "Fixed Volt", category: "Fontes", pinCount: 1,
    pinIds: ["out"], defaultProperties: { voltage: 5, out: true },
    package: { width: 48, height: 16, pins: [{ id: "out", x: 48, y: 8, angle: 0, length: 0 }] },
  },
  {
    typeId: "sources.rail", label: "Rail", category: "Fontes", pinCount: 1,
    pinIds: ["pin-1"], defaultProperties: { voltage: 5 },
    package: { width: 24, height: 16, initialTransform: { rotateDeg: 90 }, pins: [{ id: "pin-1", aliases: ["out"], x: 20, y: 8, angle: 0, length: 0 }] },
  },
  {
    typeId: "meters.probe", label: "Probe", category: "Medidores", pinCount: 1,
    pinIds: ["pin-1"], defaultProperties: { threshold: 2.5, showVolt: true, pauseOnChange: false },
    package: { width: 44, height: 16, initialTransform: { rotateDeg: -45 }, pins: [{ id: "pin-1", aliases: ["inpin"], x: 0, y: 8, angle: 180, length: 14 }] },
  },
  {
    typeId: "sources.wave_gen", label: "WaveGen", category: "Fontes", pinCount: 2,
    pinIds: ["pin-1", "pin-2"], defaultProperties: {
      waveType: "Sine", freqHz: 1000, phaseShift: 0, duty: 50, alwaysOn: false,
      bipolar: false, floating: false, semiAmplitude: 2.5, midVoltage: 0,
    },
    package: { width: 40, height: 40, pins: [
      { id: "pin-1", aliases: ["out"], x: 40, y: 8, angle: 0, length: 0 },
      { id: "pin-2", aliases: ["gnd"], x: 20, y: 40, angle: 90, length: 0 },
    ] },
  },
  {
    typeId: "subcircuits.esp32_devkitc_v4", label: "ESP32 DevKitC", category: "Subcircuitos", pinCount: 3,
    pinIds: ["G34", "RX", "TX"], defaultProperties: {},
    package: { width: 80, height: 120, pins: [] },
  },
  {
    typeId: "sensors.thermistor", label: "Thermistor", category: "Sensores", pinCount: 2,
    pinIds: ["a", "b"], defaultProperties: { temp: 25, min_temp: -55, max_temp: 200, b_coeff: 3455, r25: 10000, dialStep: 0.5 },
    package: { width: 56, height: 48, pins: [
      { id: "a", x: 0, y: 16, angle: 180, length: 10 },
      { id: "b", x: 56, y: 16, angle: 0, length: 10 },
    ], simulidePaint: { version: 1, source: { className: "Thermistor" }, bounds: { x: 0, y: 0, w: 56, h: 48 }, primitives: [] } },
  },
  {
    typeId: "other.ground",
    label: "Ground",
    category: "Fontes",
    pinCount: 1,
    pinIds: ["pin"],
    defaultProperties: {},
    package: {
      width: 16,
      height: 16,
      pins: [{ id: "pin", aliases: ["pin-1"], x: 8, y: 0, angle: 90, length: 0, label: "" }],
      simulidePaint: {
        version: 1,
        source: { className: "Ground" },
        bounds: { x: -8, y: 0, w: 16, h: 16 },
        primitives: [],
      },
    },
  },
];

function test(name: string, body: () => void): void {
  try {
    body();
    process.stdout.write(`ok - ${name}\n`);
  } catch (err) {
    process.stderr.write(`not ok - ${name}\n`);
    throw err;
  }
}

test("converte tipo, unidade, alias de pino e vertices internos", () => {
  const source = parseSimulideCircuit(`
<circuit version="1.0" NLsteps="25">
<item itemtype="Resistor" CircId="Resistor-1" Pos="100,100" Resistance="1 kΩ" ShowProp="Resistance" />
<item itemtype="Ground" CircId="Ground-2" Pos="240,100" />
<item itemtype="Connector" uid="connector-1" startpinid="Resistor-1-rPin" endpinid="Ground-2-pin-1" pointList="132,108,180,108,180,100,248,100" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  assert.strictEqual(result.project.schemaVersion, 2);
  assert.strictEqual(result.project.components[0]?.typeId, "passive.resistor");
  assert.strictEqual(result.project.components[0]?.properties.resistance, 1000);
  assert.strictEqual(result.project.components[0]?.valueLabelPropertyKey, "resistance");
  const wire = result.project.topology.conductors[0];
  assert.deepStrictEqual(wire?.from, { kind: "port", componentId: "Resistor-1", pinId: "pin-2" });
  assert.deepStrictEqual(wire?.to, { kind: "port", componentId: "Ground-2", pinId: "pin" });
  assert.deepStrictEqual(wire?.vertices, [{ x: 180, y: 108 }, { x: 180, y: 100 }]);
  assert.strictEqual(result.project.simulationSettings.maximumNewtonIterations, 25);
});

test("componente desconhecido vira placeholder e não bloqueia a conversão", () => {
  const source = parseSimulideCircuit(`<circuit>
<item itemtype="NotExisting" CircId="X-1" Pos="0,0" Foo="bar" />
<item itemtype="Ground" CircId="G-1" Pos="100,0" />
<item itemtype="Connector" uid="c1" startpinid="X-1-PIN_A" endpinid="G-1-Gnd" pointList="0,0,100,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  assert.strictEqual(result.report.placeholderComponentCount, 1);
  assert.strictEqual(result.project.components[0]?.typeId, "import.simulide.unresolved");
  assert.strictEqual(result.project.components[0]?.properties.__ui_simulideSourceType, "NotExisting");
  assert.strictEqual(result.project.topology.conductors.length, 1);
  assert.deepStrictEqual(result.project.topology.conductors[0]?.from, { kind: "port", componentId: "X-1", pinId: "PIN_A" });
});


test("Node de três pinos do SimulIDE vira um único topology node", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Resistor" CircId="Resistor-1" Pos="0,0" Resistance="100" />
<item itemtype="Resistor" CircId="Resistor-2" Pos="100,0" Resistance="100" />
<item itemtype="Ground" CircId="Ground-3" Pos="50,100" />
<item itemtype="Node" CircId="Node-4" Pos="50,0" />
<item itemtype="Connector" uid="c1" startpinid="Resistor-1-rPin" endpinid="Node-4-0" pointList="1,1,50,0" />
<item itemtype="Connector" uid="c2" startpinid="Node-4-1" endpinid="Resistor-2-lPin" pointList="50,0,99,1" />
<item itemtype="Connector" uid="c3" startpinid="Node-4-2" endpinid="Ground-3-pin-1" pointList="50,0,50,100" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  assert.strictEqual(result.project.topology.nodes.length, 1);
  assert.strictEqual(result.project.topology.nodes[0]?.id, "Node-4");
  const nodeRefs = result.project.topology.conductors.flatMap((wire) => [wire.from, wire.to])
    .filter((endpoint) => endpoint.kind === "node");
  assert.strictEqual(nodeRefs.length, 3);
  assert.ok(nodeRefs.every((endpoint) => endpoint.kind === "node" && endpoint.nodeId === "Node-4"));
});

test("pino desconhecido rebaixa somente o componente para placeholder e preserva o fio", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Resistor" CircId="Resistor-1" Pos="0,0" Resistance="100" />
<item itemtype="Ground" CircId="Ground-2" Pos="100,0" />
<item itemtype="Connector" uid="c1" startpinid="Resistor-1-pin-that-does-not-exist" endpinid="Ground-2-pin-1" pointList="0,0,100,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  assert.strictEqual(result.project.components[0]?.typeId, "import.simulide.unresolved");
  assert.strictEqual(result.report.partiallyConvertedComponentCount, 1);
  assert.strictEqual(result.project.topology.conductors.length, 1);
  assert.deepStrictEqual(result.project.topology.conductors[0]?.from, { kind: "port", componentId: "Resistor-1", pinId: "pin-that-does-not-exist" });
});


test("preserva retângulo/frame: tamanho, cor, borda, opacidade e z-order", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Rectangle" CircId="Rectangle-1" Pos="120,80" H_size="320" V_size="180" Border="3" Color="#12ab34" Opacity="0.45" Z_Value="-7" Angle="90" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const c = result.project.components[0]!;
  assert.strictEqual(c.typeId, "graphics.rectangle");
  assert.strictEqual(c.properties.width, 320);
  assert.strictEqual(c.properties.height, 180);
  assert.strictEqual(c.properties.fill, "#12ab34");
  assert.strictEqual(c.properties.strokeWidth, 3);
  assert.strictEqual(c.properties.fillOpacity, 0.45);
  assert.strictEqual(c.properties.zValue, -7);
  assert.strictEqual(c.visual?.rotation, 90);
});

test("preserva caixa de texto: conteúdo multilinha, fonte, cores, margem, borda e opacidade", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="TextComponent" CircId="Text-1" Pos="10,20" Margin="9" Border="4" Color="#ffeeaa" Opacity="0.7" Font="Arial" Font_Color="#1122cc" Font_Size="18" Fixed_Width="1" Text="Linha 1&#xa;Linha 2&#x3D;X" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const c = result.project.components[0]!;
  assert.strictEqual(c.typeId, "graphics.text");
  assert.strictEqual(c.properties.text, "Linha 1\nLinha 2=X");
  assert.strictEqual(c.properties.margin, 9);
  assert.strictEqual(c.properties.borderWidth, 4);
  assert.strictEqual(c.properties.backgroundColor, "#ffeeaa");
  assert.strictEqual(c.properties.backgroundOpacity, 0.7);
  assert.strictEqual(c.properties.fontFamily, "Arial");
  assert.strictEqual(c.properties.color, "#1122cc");
  assert.strictEqual(c.properties.fontSize, 18);
  assert.strictEqual(c.properties.fixedWidth, true);
});

test("preserva linha não-cardinal com vetor H/V, cor, espessura e opacidade", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Line" CircId="Line-1" Pos="50,50" H_size="80" V_size="30" Border="5" Color="#aa00ff" Opacity="0.4" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const c = result.project.components[0]!;
  assert.strictEqual(c.typeId, "graphics.line");
  assert.strictEqual(c.properties.deltaX, 80);
  assert.strictEqual(c.properties.deltaY, -30);
  assert.strictEqual(c.properties.stroke, "#aa00ff");
  assert.strictEqual(c.properties.strokeWidth, 5);
  assert.strictEqual(c.properties.opacity, 0.4);
  assert.ok(Math.abs(Number(c.properties.length) - Math.hypot(80, 30)) < 1e-9);
});

test("preserva imagem embutida do SimulIDE como base64", () => {
  const pngHex = "89504e470d0a1a0a";
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Image" CircId="Image-1" Pos="0,0" H_size="123" V_size="45" Border="2" Image_File="figura.png" BckGndData="${pngHex}" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const c = result.project.components[0]!;
  assert.strictEqual(c.typeId, "graphics.image");
  assert.strictEqual(c.properties.width, 123);
  assert.strictEqual(c.properties.height, 45);
  assert.strictEqual(c.properties.path, "figura.png");
  assert.strictEqual(c.properties.imageMime, "image/png");
  assert.strictEqual(c.properties.imageData, Buffer.from(pngHex, "hex").toString("base64"));
});


test("AIP resolve endpoints sem hífen entre CircId e PinSDA/PinSCL", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Aip31068_i2c" CircId="Aip31068_i2c-13" Pos="0,0" Rows="2" Cols="16" Control_Code="62" Frequency="100 _kHz" />
<item itemtype="Ground" CircId="Ground-1" Pos="100,0" />
<item itemtype="Connector" uid="a" startpinid="Aip31068_i2c-13PinSDA" endpinid="Ground-1-Gnd" pointList="0,0,100,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  assert.deepStrictEqual(result.project.topology.conductors[0]?.from, { kind: "port", componentId: "Aip31068_i2c-13", pinId: "sda" });
  const aip = result.project.components[0]!;
  assert.strictEqual(aip.properties.frequency, 100);
  assert.strictEqual(aip.properties.i2cAddress, 62);
});

test("SerialTerm preserva semântica 0-based: pin0=tx e pin1=rx", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="SerialTerm" CircId="SerialTerm-1" Pos="0,0" Baudrate="115200 _Bd" DataBits="8 _bits" StopBits="1 _bits" />
<item itemtype="Ground" CircId="G-1" Pos="100,0" />
<item itemtype="Connector" uid="a" startpinid="SerialTerm-1-pin0" endpinid="G-1-Gnd" pointList="0,0,100,0" />
<item itemtype="Connector" uid="b" startpinid="SerialTerm-1-pin1" endpinid="G-1-Gnd" pointList="0,8,100,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  assert.strictEqual((result.project.topology.conductors[0]?.from as any)?.pinId, "tx");
  assert.strictEqual((result.project.topology.conductors[1]?.from as any)?.pinId, "rx");
});

test("retira initialTransform de Rail/Probe e converte label local para coordenada de cena", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Rail" CircId="Rail-1" Pos="100,100" rotation="90" hflip="1" vflip="1" Show_Val="true" valLabPos="-20,8" valLabRot="-90" Voltage="5 V" />
<item itemtype="Probe" CircId="Probe-1" Pos="200,100" rotation="-225" hflip="1" vflip="1" Show_id="true" idLabPos="12,34" labelrot="225" Threshold="2.5 V" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const rail = result.project.components.find((c) => c.id === "Rail-1")!;
  const probe = result.project.components.find((c) => c.id === "Probe-1")!;
  assert.strictEqual(rail.visual?.rotation, 0); // source 90 - package.initialTransform 90
  assert.strictEqual(rail.properties.__ui_valueLabelRotation, 0); // pai 90 + -90
  assert.strictEqual(probe.visual?.rotation, 180); // -225 - (-45) = -180
  assert.strictEqual(probe.properties.__ui_idLabelRotation, 0); // -225 + 225
  assert.strictEqual(probe.properties.__simulideQtOrigin, true);
});

test("WaveGen converte as propriedades funcionais usadas nos circuitos reais", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="WaveGen" CircId="WaveGen-1" Pos="0,0" Freq="110 Hz" Semi_Ampli="0.5 V" Mid_Volt="-1.65 V" Duty="50 _%" Phase="90 _º" Always_On="true" Bipolar="true" Floating="false" Wave_Type="Sine" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  const wave = result.project.components[0]!;
  assert.strictEqual(wave.properties.freqHz, 110);
  assert.strictEqual(wave.properties.semiAmplitude, 0.5);
  assert.strictEqual(wave.properties.midVoltage, -1.65);
  assert.strictEqual(wave.properties.duty, 50);
  assert.strictEqual(wave.properties.phaseShift, 90);
  assert.strictEqual(wave.properties.alwaysOn, true);
  assert.strictEqual(wave.properties.bipolar, true);
});

test("reconhece devkitC e preserva mainCompProps/Program", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Subcircuit" CircId="devkitC-155" Pos="0,0" label="devkitC-155">
<mainCompProps MainCompId="Esp32-2" Program="merged.bin" />
</item>
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const devkit = result.project.components[0]!;
  assert.strictEqual(devkit.typeId, "subcircuits.esp32_devkitc_v4");
  assert.strictEqual(devkit.properties.__ui_simulideProgram, "merged.bin");
  assert.strictEqual(devkit.properties.__ui_simulideMainCompId, "Esp32-2");
});


test("Thermistor real aceita lPin/rPin, ºC e B/R25", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Thermistor" CircId="Thermistor-301" Pos="0,0" Temp="152.4 ºC" Min_Temp="0 ºC" Max_Temp="200 ºC" Dial_Step="0.5 ºC" B="3455" R25="10000 Ω" />
<item itemtype="Ground" CircId="G-1" Pos="100,0" />
<item itemtype="Connector" uid="t1" startpinid="Thermistor-301-rPin" endpinid="G-1-Gnd" pointList="56,16,100,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const therm = result.project.components[0]!;
  assert.strictEqual(therm.typeId, "sensors.thermistor");
  assert.strictEqual(therm.properties.temp, 152.4);
  assert.strictEqual(therm.properties.min_temp, 0);
  assert.strictEqual(therm.properties.max_temp, 200);
  assert.strictEqual(therm.properties.dialStep, 0.5);
  assert.strictEqual(therm.properties.b_coeff, 3455);
  assert.strictEqual(therm.properties.r25, 10000);
  assert.deepStrictEqual(result.project.topology.conductors[0]?.from, { kind: "port", componentId: "Thermistor-301", pinId: "b" });
});

test("Arduino Uno sem backend é preservado como placeholder com firmware e pinos", () => {
  const source = parseSimulideCircuit(`
<circuit stepSize="1000000" stepsPS="1000000" NLsteps="100000" reaStep="1000000">
<item itemtype="Subcircuit" CircId="Uno-63" Pos="-328,-384" label="Arduino Uno-63">
<mainCompProps MainCompId="63_mega328-109" Frequency="16 MHz" Program="../.pio/build/uno/firmware.hex" />
</item>
<item itemtype="Ground" CircId="G-1" Pos="0,0" />
<item itemtype="Connector" uid="u1" startpinid="Uno-63-A5" endpinid="G-1-Gnd" pointList="-176,-368,0,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(hasImportErrors(result.report), false);
  const uno = result.project.components[0]!;
  assert.strictEqual(uno.typeId, "import.simulide.unresolved");
  assert.strictEqual(uno.properties.__ui_simulideProgram, "../.pio/build/uno/firmware.hex");
  assert.strictEqual(uno.properties.__ui_simulidePinIds, '["A5"]');
  assert.deepStrictEqual(result.project.topology.conductors[0]?.from, { kind: "port", componentId: "Uno-63", pinId: "A5" });
  assert.strictEqual(result.project.simulationSettings.initialStepSeconds, 1e-6);
  assert.strictEqual(result.project.simulationSettings.timeScale, 1);
  assert.strictEqual((result.project.simulationSettings as any).reactivePeriodSeconds, 1e-6);
});

test("uids duplicados de Connector são renomeados sem perder fios", () => {
  const source = parseSimulideCircuit(`
<circuit>
<item itemtype="Ground" CircId="G-1" Pos="0,0" />
<item itemtype="Ground" CircId="G-2" Pos="100,0" />
<item itemtype="Connector" uid="Connector-302" startpinid="G-1-Gnd" endpinid="G-2-Gnd" pointList="0,0,100,0" />
<item itemtype="Connector" uid="Connector-302" startpinid="G-1-Gnd" endpinid="G-2-Gnd" pointList="0,0,50,20,100,0" />
</circuit>`);
  const result = convertSimulideDocument(source, catalog);
  assert.strictEqual(result.project.topology.conductors.length, 2);
  assert.strictEqual(result.project.topology.conductors[0]?.id, "Connector-302");
  assert.strictEqual(result.project.topology.conductors[1]?.id, "Connector-302.imported-2");
  assert.ok(result.report.issues.some((issue) => issue.code === "duplicate-conductor-id"));
});
