import {
  SimulideAttributes,
  SimulideCircuitDocument,
  SimulideConnectorRecord,
} from "./SimulideTypes";

function decodeXmlEntities(value: string): string {
  return value
    // O TextComponent do SimulIDE usa referências numéricas, algumas historicamente sem ';'.
    .replace(/&#x([0-9a-fA-F]+);?/g, (_match, hex: string) => String.fromCodePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d+);?/g, (_match, decimal: string) => String.fromCodePoint(Number.parseInt(decimal, 10)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

/**
 * O SimulIDE persiste cada <circuit> / <item> em uma única linha e sempre grava atributos
 * entre aspas. Não usamos DOM/XML externo para manter o importador sem dependências adicionais.
 */
export function parseSimulideAttributes(line: string): SimulideAttributes {
  const attributes: SimulideAttributes = {};
  const expression = /([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"([^"]*)"/g;
  let match: RegExpExecArray | null;
  while ((match = expression.exec(line)) !== null) {
    const name = match[1];
    const value = match[2];
    if (name && value !== undefined) attributes[name] = decodeXmlEntities(value);
  }
  return attributes;
}

export function parseSimulidePointList(raw: string | undefined): Array<{ x: number; y: number }> {
  if (!raw) return [];
  const parts = raw.split(",").map((part) => Number(part.trim()));
  if (parts.length < 4 || parts.length % 2 !== 0 || parts.some((value) => !Number.isFinite(value))) {
    throw new Error(`pointList inválido: ${raw}`);
  }
  const points: Array<{ x: number; y: number }> = [];
  for (let index = 0; index < parts.length; index += 2) {
    points.push({ x: parts[index]!, y: parts[index + 1]! });
  }
  return points;
}

function optionalNumber(value: string | undefined): number | undefined {
  if (value === undefined || value.trim() === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function parseSimulideCircuit(text: string): SimulideCircuitDocument {
  const document: SimulideCircuitDocument = {
    settings: { raw: {} },
    components: [],
    nodes: [],
    connectors: [],
  };

  const seenIds = new Set<string>();
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  let foundCircuit = false;
  let openComponent: SimulideCircuitDocument["components"][number] | undefined;

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const rawLine = lines[lineIndex] ?? "";
    const line = rawLine.trim();
    if (!line) continue;
    const lineNumber = lineIndex + 1;

    if (line.startsWith("<circuit")) {
      const attributes = parseSimulideAttributes(line);
      document.settings = {
        version: attributes.version,
        revision: optionalNumber(attributes.rev),
        stepSize: optionalNumber(attributes.stepSize),
        stepsPerSecond: optionalNumber(attributes.stepsPS),
        maxNonLinearSteps: optionalNumber(attributes.NLsteps),
        reactiveStep: optionalNumber(attributes.reaStep),
        raw: attributes,
      };
      foundCircuit = true;
      continue;
    }

    if (line.startsWith("</circuit")) break;

    // Subcircuitos são os únicos itens observados que abrem uma tag não auto-fechada e carregam
    // propriedades do componente principal numa linha filha. Preservamos esse bloco no IR para
    // converter, por exemplo, devkitC + Program para o subcircuito ESP32 + firmware do LasecSimul.
    if (line.startsWith("<mainCompProps")) {
      if (!openComponent) throw new Error(`Linha ${lineNumber}: <mainCompProps> fora de <item>`);
      openComponent.mainCompProps = { attributes: parseSimulideAttributes(line), lineNumber };
      continue;
    }
    if (line.startsWith("</item")) {
      openComponent = undefined;
      continue;
    }
    if (!line.startsWith("<item")) continue;

    const attributes = parseSimulideAttributes(line);
    const itemType = attributes.itemtype;
    if (!itemType) throw new Error(`Linha ${lineNumber}: item sem itemtype`);

    if (itemType === "Connector") {
      const startPinId = attributes.startpinid;
      const endPinId = attributes.endpinid;
      if (!startPinId || !endPinId) {
        throw new Error(`Linha ${lineNumber}: Connector sem startpinid/endpinid`);
      }
      const uid = attributes.uid || `connector-line-${lineNumber}`;
      const connector: SimulideConnectorRecord = {
        kind: "connector",
        itemType: "Connector",
        uid,
        startPinId,
        endPinId,
        points: parseSimulidePointList(attributes.pointList),
        attributes,
        lineNumber,
      };
      document.connectors.push(connector);
      continue;
    }

    const circId = attributes.CircId;
    if (!circId) throw new Error(`Linha ${lineNumber}: ${itemType} sem CircId`);
    if (seenIds.has(circId)) throw new Error(`Linha ${lineNumber}: CircId duplicado (${circId})`);
    seenIds.add(circId);

    if (itemType === "Node") {
      document.nodes.push({ kind: "node", itemType: "Node", circId, attributes, lineNumber });
      openComponent = undefined;
    } else {
      const component = { kind: "component" as const, itemType, circId, attributes, lineNumber };
      document.components.push(component);
      openComponent = line.endsWith("/>") ? undefined : component;
    }
  }

  if (!foundCircuit) throw new Error("Arquivo não contém a tag <circuit> do SimulIDE");
  return document;
}
