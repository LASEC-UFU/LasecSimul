import * as assert from "assert";
import { parseSimulideCircuit, parseSimulidePointList } from "./SimulideParser";

function test(name: string, body: () => void): void {
  try {
    body();
    process.stdout.write(`ok - ${name}\n`);
  } catch (err) {
    process.stderr.write(`not ok - ${name}\n`);
    throw err;
  }
}

test("parseia componentes, nodes e connectors", () => {
  const doc = parseSimulideCircuit(`
<circuit version="1.0" rev="1">
<item itemtype="Resistor" CircId="Resistor-1" Pos="10,20" Resistance="1 kΩ" />
<item itemtype="Node" CircId="Node-2" Pos="30,20" />
<item itemtype="Connector" uid="connector-1" startpinid="Resistor-1-rPin" endpinid="Node-2-0" pointList="10,20,30,20" />
</circuit>`);
  assert.strictEqual(doc.components.length, 1);
  assert.strictEqual(doc.nodes.length, 1);
  assert.strictEqual(doc.connectors.length, 1);
  assert.strictEqual(doc.components[0]?.attributes.Resistance, "1 kΩ");
});

test("pointList vira pares x/y", () => {
  assert.deepStrictEqual(parseSimulidePointList("1,2,3,4,5,6"), [
    { x: 1, y: 2 },
    { x: 3, y: 4 },
    { x: 5, y: 6 },
  ]);
});

test("rejeita item sem CircId", () => {
  assert.throws(() => parseSimulideCircuit(`<circuit>
<item itemtype="Resistor" />
</circuit>`));
});


test("decodifica entidades numéricas usadas pelo TextComponent", () => {
  const doc = parseSimulideCircuit(`<circuit>
<item itemtype="TextComponent" CircId="Text-1" Text="A&#xa;B&#x3D;C&#x22;D" />
</circuit>`);
  assert.strictEqual(doc.components[0]?.attributes.Text, "A\nB=C\"D");
});

test("preserva mainCompProps de Subcircuit", () => {
  const parsed = parseSimulideCircuit(`<circuit>
<item itemtype="Subcircuit" CircId="devkitC-1" Pos="0,0">
<mainCompProps MainCompId="Esp32-2" Program="merged.bin" />
</item>
</circuit>`);
  assert.strictEqual(parsed.components[0]?.mainCompProps?.attributes.MainCompId, "Esp32-2");
  assert.strictEqual(parsed.components[0]?.mainCompProps?.attributes.Program, "merged.bin");
});
