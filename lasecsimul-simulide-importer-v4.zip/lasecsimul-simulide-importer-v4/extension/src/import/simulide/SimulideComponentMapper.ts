import type { PackagePin, WebviewComponentCatalogEntry } from "../../ui/webview/model";
import type { SimulideComponentRecord } from "./SimulideTypes";

const FALLBACK_TYPE_MAP: Record<string, string> = {
  push: "switches.push",
  switch: "switches.switch",
  switchdip: "switches.switch_dip",
  relay: "switches.relay",
  keypad: "switches.keypad",
  resistor: "passive.resistor",
  varresistor: "passive.variable_resistor",
  potentiometer: "passive.potentiometer",
  resistordip: "passive.resistor_dip",
  capacitor: "passive.capacitor",
  elcapacitor: "passive.electrolytic_capacitor",
  electrolyticcapacitor: "passive.electrolytic_capacitor",
  inductor: "passive.inductor",
  varcapacitor: "passive.variable_capacitor",
  varinductor: "passive.variable_inductor",
  thermistor: "sensors.thermistor",
  diode: "active.diode",
  zener: "active.zener",
  opamp: "active.opamp",
  comparator: "active.comparator",
  muxanalog: "active.analog_mux",
  voltreg: "active.volt_regulator",
  led: "outputs.led",
  ledrgb: "outputs.led_rgb",
  ledbar: "outputs.led_bar",
  ledmatrix: "outputs.led_matrix",
  sevensegment: "outputs.seven_segment",
  dcmotor: "outputs.dc_motor",
  stepper: "outputs.stepper",
  lamp: "outputs.incandescent_lamp",
  aip31068i2c: "outputs.aip31068_i2c",
  pcd8544: "outputs.pcd8544",
  bus: "connectors.bus",
  tunnel: "connectors.tunnel",
  socket: "connectors.socket",
  header: "connectors.header",
  probe: "meters.probe",
  ampmeter: "meters.ampmeter",
  voltimeter: "instruments.voltmeter",
  voltmeter: "instruments.voltmeter",
  freqmeter: "meters.freqmeter",
  oscope: "meters.oscope",
  oscilloscope: "meters.oscope",
  logicanalyzer: "meters.logic_analyzer",
  lanalizer: "meters.logic_analyzer",
  serialterm: "peripherals.serialterm",
  serialterminal: "peripherals.serialterm",
  serialport: "peripherals.serialport",
  dcvoltagesource: "sources.dc_voltage",
  fixedvolt: "sources.fixed_volt",
  fixedvoltage: "sources.fixed_volt",
  clock: "sources.clock",
  wavegen: "sources.wave_gen",
  voltsource: "sources.voltage_source",
  currsource: "sources.current_source",
  csource: "sources.controlled_source",
  battery: "sources.battery",
  rail: "sources.rail",
  ground: "other.ground",

  // Elementos gráficos do SimulIDE.
  textcomponent: "graphics.text",
  text: "graphics.text",
  rectangle: "graphics.rectangle",
  ellipse: "graphics.ellipse",
  line: "graphics.line",
  image: "graphics.image",
};

/** Aliases que são específicos do FORMATO de arquivo do SimulIDE, não do ABI nativo do LasecSimul. */
const IMPORT_PIN_ALIASES: Record<string, Record<string, string>> = {
  "sources.fixed_volt": { outnod: "out" },
  "sources.rail": { outnod: "pin-1" },
  "sources.wave_gen": { outnod: "pin-1", gnd: "pin-2" },
  "other.ground": { gnd: "pin" },
  "peripherals.serialterm": { pin0: "tx", pin1: "rx" },
  "peripherals.serialport": { pin0: "tx", pin1: "rx" },
  "outputs.aip31068_i2c": { pinsda: "sda", pinscl: "scl" },
  "outputs.pcd8544": { pinrst: "rst", pincs: "ce", pindc: "dc", pinsi: "din", pinscl: "clk" },
  "sensors.thermistor": { lpin: "a", rpin: "b" },
};

export function normalizeSimulideToken(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function sourceClassNames(entry: WebviewComponentCatalogEntry): string[] {
  const names = [
    entry.package?.simulidePaint?.source?.className,
    entry.logicSymbolPackage?.simulidePaint?.source?.className,
    entry.boardPackage?.simulidePaint?.source?.className,
  ].filter((name): name is string => Boolean(name));
  // Alguns manifests documentam classe + widgets auxiliares em "A/B/C". A primeira classe ainda
  // precisa casar com itemtype="A" sem obrigar o catálogo a duplicar metadados só para o importador.
  return names.flatMap((name) => [name, ...name.split(/[\/,+\s]+/g).filter(Boolean)]);
}

function recognizedSubcircuitTypeId(source: SimulideComponentRecord | undefined): string | undefined {
  if (!source || normalizeSimulideToken(source.itemType) !== "subcircuit") return undefined;
  const identity = normalizeSimulideToken(`${source.circId} ${source.attributes.label ?? ""}`);
  const mainComp = normalizeSimulideToken(source.mainCompProps?.attributes.MainCompId ?? "");
  if (identity.includes("devkitc") && mainComp.startsWith("esp32")) return "subcircuits.esp32_devkitc_v4";
  return undefined;
}

export function resolveSimulideCatalogEntry(
  itemType: string,
  catalog: readonly WebviewComponentCatalogEntry[],
  source?: SimulideComponentRecord
): WebviewComponentCatalogEntry | undefined {
  const normalized = normalizeSimulideToken(itemType);

  const subcircuitTypeId = recognizedSubcircuitTypeId(source);
  if (subcircuitTypeId) return catalog.find((entry) => entry.typeId === subcircuitTypeId);

  const bySourceClass = catalog.find((entry) =>
    sourceClassNames(entry).some((name) => normalizeSimulideToken(name) === normalized)
  );
  if (bySourceClass) return bySourceClass;

  const fallbackTypeId = FALLBACK_TYPE_MAP[normalized];
  if (fallbackTypeId) return catalog.find((entry) => entry.typeId === fallbackTypeId);

  // Último fallback conservador: typeId/label somente quando a normalização casa exatamente.
  return catalog.find((entry) =>
    normalizeSimulideToken(entry.typeId) === normalized || normalizeSimulideToken(entry.label) === normalized
  );
}

function staticPins(entry: WebviewComponentCatalogEntry): PackagePin[] {
  return entry.package?.pins ?? [];
}

export function resolveSimulidePinId(
  entry: WebviewComponentCatalogEntry,
  rawLocalPinId: string
): string | undefined {
  const wanted = normalizeSimulideToken(rawLocalPinId);

  const importAlias = IMPORT_PIN_ALIASES[entry.typeId]?.[wanted];
  if (importAlias) return importAlias;

  const packagePin = staticPins(entry).find((pin) => {
    if (normalizeSimulideToken(pin.id) === wanted) return true;
    return pin.aliases?.some((alias) => normalizeSimulideToken(alias) === wanted) ?? false;
  });
  if (packagePin) return packagePin.id;

  const direct = entry.pinIds?.find((pinId) => normalizeSimulideToken(pinId) === wanted);
  if (direct) return direct;

  // Fallback numérico SOMENTE para formatos 1-based inequívocos (pin-1/p1/1). Não aceitar pin0,
  // porque SerialTerm/SerialPort do SimulIDE usam pin0=TX e pin1=RX; tratar pin1 como índice 1
  // converteria RX incorretamente para TX.
  const numericMatch = rawLocalPinId.match(/^(?:pin[-_]?|p)?([1-9]\d*)$/i);
  if (numericMatch) {
    const oneBased = Number(numericMatch[1]);
    const canonical = entry.pinIds?.[oneBased - 1];
    if (canonical) return canonical;
  }

  return undefined;
}

export function splitSimulideEndpoint(
  fullPinId: string,
  ownerIds: readonly string[]
): { ownerId: string; localPinId: string } | undefined {
  // IDs do SimulIDE contêm hífens. O owner correto é sempre o maior prefixo conhecido. A maioria
  // usa owner + "-" + pin, mas alguns componentes reais (Aip31068_i2c) criam id + "PinSDA" sem
  // separador. Longest-prefix evita confundir Foo-1 com Foo-10 quando ambos existem.
  const sorted = [...ownerIds].sort((a, b) => b.length - a.length);
  for (const ownerId of sorted) {
    if (fullPinId === ownerId) return { ownerId, localPinId: "" };
    if (fullPinId.startsWith(`${ownerId}-`)) {
      return { ownerId, localPinId: fullPinId.slice(ownerId.length + 1) };
    }
    if (fullPinId.startsWith(ownerId) && fullPinId.length > ownerId.length) {
      return { ownerId, localPinId: fullPinId.slice(ownerId.length) };
    }
  }
  return undefined;
}
