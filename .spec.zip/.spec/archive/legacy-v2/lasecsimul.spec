<!-- Claude Code Spec Header v1 -->
## Claude Code Operating Contract (English)

Purpose: This file is a source-of-truth technical spec for LasecSimul architecture and implementation behavior.
Audience: coding agents and maintainers.
Mode: normative guidance before code changes.

Keywords: source-of-truth, architecture, extension-host, native-core, ipc, qemu, plugin-abi, mna-solver, scheduler, contracts, acceptance-criteria

Priority Rules:
1. MUST preserve architecture boundaries (Extension UI/orchestration vs Core simulation runtime).
2. MUST treat this spec as normative when task instructions are ambiguous.
3. MUST update this spec when introducing a new architectural decision.
4. SHOULD keep protocol and file-format decisions host-agnostic.
5. MUST NOT move simulation logic into the VS Code extension layer.

Agent Workflow:
1. Read this file first.
2. Validate whether requested changes fit existing requirements.
3. If a gap exists: compare alternatives, pick best option, and document the decision in this spec.
4. Implement only after contract clarity.

Decision Keywords:
- MUST: mandatory behavior.
- SHOULD: preferred unless a documented reason exists.
- MAY: optional behavior.
- OUT OF SCOPE: must not be implemented in the current phase.

---
# LasecSimul — Especificação Técnica (v0.2)

Status: rascunho | Tipo: extensão VSCode (UI) + núcleo nativo C++ (simulação) | Emulação de MCU: QEMU (processo externo)

> **Changelog v0.2**: o núcleo de simulação deixa de ser TypeScript/Node e passa a ser um **processo nativo
> C++ separado** (`LasecSimul Core`), para que dispositivos eletrônicos e adaptadores de MCU possam ser
> carregados como **plugins nativos (DLL/SO)** com custo de chamada equivalente a código compilado no próprio
> núcleo — sem IPC, sem serialização, sem sandbox no caminho crítico do solver. Isso substitui a abordagem
> WASM descrita em `lasecsimul-wasm-devices.spec` (agora superseded; ver `lasecsimul-native-devices.spec`).
> Motivação registrada na conversa de design: rodar **todo** componente (R, L, C, fontes, instrumentos) via
> um mecanismo de plugin com overhead de IPC/worker tornaria o simulador lento mesmo para circuitos triviais
> — confirmado comparando com `C:\SourceCode\simulide_2\src\simulator\elements\passive\e-resistor.cpp`, onde `stamp()`
> roda uma única vez (não a cada passo) e o dispatch é uma chamada de função direta em processo único.

---

## 1. Visão geral

LasecSimul recria as ferramentas do SimulIDE-dev (Qt/C++) como duas peças que se comunicam por IPC, não como
um monólito:

- **LasecSimul Extension** (`LasecSimul/extension/`, TypeScript) — única camada que conhece a API do VSCode:
  editor de esquemático (webview), painéis, comandos, propriedades. Não executa nenhum cálculo elétrico.
  Organização de UI baseada no SimulIDE real, exceto qualquer área de digitar/compilar código — não existe
  no LasecSimul, compilação é sempre externa (seção 13).
- **LasecSimul Core** (`LasecSimul/core/`, C++ nativo) — processo separado, dono do `MnaSolver`, do
  `Scheduler`, do registro de componentes/MCUs e do carregamento de plugins nativos. Não conhece VSCode.

Isso cumpre os dois requisitos originais do projeto simultaneamente: "a camada principal da extensão pode
ser em TypeScript" (a extensão é TS) e "a simulação pode ser separada em processos independentes" (o núcleo
é um processo nativo). Microcontroladores continuam **sempre** emulados via QEMU — nunca por interpretação de
instrução escrita à mão — e a integração QEMU agora mora no processo nativo, pelo mesmo motivo de desempenho
do solver (seção 8).

**Divergência deliberada do SimulIDE-dev, não descuido**: o SimulIDE trata ARM/ESP32/STM32 via QEMU mas
AVR (Arduino Uno) e PIC via interpretador de instrução escrito à mão (`microsim/cores/` — fora do escopo
deste projeto). No LasecSimul **toda** família de MCU passa por QEMU, sem exceção — inclusive as que o
SimulIDE simula manualmente. Isso é mais trabalho por família (precisa de CPU emulada no QEMU, não só um
interpretador simples), mas elimina a categoria inteira de bug "o interpretador não bate com o hardware
real" e mantém só um mecanismo de integração de MCU no projeto inteiro (seção 8.2 traz o estado real,
verificado, de cada família).

### 1.1 Fronteira de desacoplamento da UI — o protocolo IPC é o único contrato

Requisito adicional, registrado depois do MVP inicial: a Extension VSCode de hoje precisa continuar sendo
**uma** implementação de shell, nunca **a** UI — deve ser possível, no futuro, escrever um shell totalmente
diferente (ex: app Flutter, ou outra IDE) que fale com o mesmo `LasecSimul Core` sem reescrever nem reusar
nada do lado VSCode/webview. Isso já é parcialmente verdade por construção (RNF03/RNF06: o Core não conhece
Qt nem VSCode, só fala o protocolo de IPC da seção 7) — esta seção formaliza a regra e fecha as lacunas onde
algo VSCode-específico tinha vazado pra fora da Extension.

**Regra**: nada que cruze a fronteira Core↔shell pode depender de um mecanismo específico de um host. Dito de
outro modo, o **protocolo de IPC (named pipe/socket + JSON, seção 7) e os formatos de arquivo em disco
(`.lsproj`, `.lsdevice`, `.lssubcircuit`, `library.json`, ver
`lasecsimul-subcircuits.spec`) são o contrato inteiro.** Um shell Flutter implementaria seu próprio cliente
do protocolo (equivalente a `CoreClient.ts`, em Dart) e sua própria renderização (widgets Flutter, não
DOM/SVG) — **não existe nem se espera reuso de código de UI entre frameworks tão diferentes**; o que se
reaproveita é o protocolo e os formatos de arquivo, nunca TypeScript/webview.

**Correção aplicada**: a declaração de quais bibliotecas carregar saiu de `contributes` do VSCode e foi
consolidada em arquivo host-agnóstico de projeto: `LasecSimul/project/schema/component-catalog.json`.
Esse arquivo é a fonte única para: (a) itens da paleta (`items[]`, incluindo hierarquia de pastas por
`folderPath`), e (b) bibliotecas que a shell manda o Core carregar (`deviceLibraries[]`, tipicamente
`../devices/library.json`, `../mcu-adapters/library.json`, e `../subcircuits/library.json`).
Qualquer shell alternativo lê o mesmo arquivo e chama o mesmo verbo IPC (`loadDeviceLibrary`) sem conhecer
nada de VSCode.

**O que isso não muda**: a Extension continua sendo o único shell implementado nesta fase — não estamos
construindo um shell Flutter agora, só impedindo que decisões de protocolo/formato fiquem amarradas ao VSCode
de um jeito que tornaria um shell futuro mais caro do que precisa ser. Ver ADR 0007
(`docs/adr/0007-ui-desacoplada-protocolo-como-contrato.md`).

## 2. Objetivos

- Editor de esquemáticos e simulação de circuito analógico/digital dentro do VSCode (webview ↔ núcleo nativo).
- Suporte a múltiplos MCUs emulados via QEMU, com firmware real compilado pelo usuário.
- Extensibilidade: novos componentes eletrônicos e novos MCUs **sem recompilar o núcleo**, via plugins
  nativos (DLL/SO) carregados em runtime — ver `lasecsimul-native-devices.spec`.
- **Arquitetura-alvo de longo prazo**: o Core converge para um runtime genérico (solver, scheduler,
  registries, ABI, projeto, telemetria e ponte QEMU), **sem manter modelos elétricos específicos hardcoded
  como estratégia de crescimento do catálogo**. Built-ins que existirem durante o bootstrap/MVP são
  transitórios ou de compatibilidade; todo componente novo que exija comportamento próprio deve entrar pelo
  mesmo caminho de ABI/manifeste usado pelos dispositivos externos. Subcircuitos continuam sendo o caminho
  declarativo sem código.
- **Desempenho do núcleo equivalente ao SimulIDE**: chamada direta em processo único no caminho crítico do
  solver, sem IPC/serialização/sandbox por elemento e por passo.
- Instrumentos virtuais (osciloscópio, multímetro, gerador de função, analisador lógico) como **plugin
  nativo (DLL/SO)** via `device_abi.h`, igual a qualquer outro dispositivo de terceiros — decisão revertida
  por ADR 0006 (`docs/adr/0006-instrumentos-como-plugin-abi.md`); o texto anterior desta seção dizia "código
  nativo de primeira classe no núcleo, não como plugin", o que não vale mais.
- Depuração de firmware integrada (gdbserver do QEMU + Debug Adapter do VSCode).
- **Subcircuitos**: circuito desenhado no próprio editor, salvo como um terceiro tipo de componente
  reutilizável — **dado (JSON), não código** — com pinos de I/O e símbolo visual definidos pelo usuário, sem
  exigir DLL/SO nem recompilar o Core. Ver `lasecsimul-subcircuits.spec` e ADR 0008.
- **UI desacoplável do VSCode**: nenhuma decisão de protocolo/formato de arquivo pode depender de um
  mecanismo específico do VSCode (seção 1.1) — para que um shell alternativo (ex: Flutter) seja viável no
  futuro sem reescrever o Core nem o protocolo.

## 3. Requisitos

### 3.1 Funcionais
- RF01: Criar/abrir/salvar projetos de circuito (formato `.lsproj`), persistidos pela Extension, lidos/escritos pelo Core via IPC.
- RF02: Posicionar, conectar e configurar componentes eletrônicos em um esquemático.
- RF03: Executar simulação (start/pause/step/stop) com resolução de passo configurável.
- RF04: Instanciar um MCU como componente, associar um binário/firmware e executá-lo via QEMU.
- RF05: Mapear pinos do MCU emulado para nós do circuito (bidirecional, tempo real, dentro do Core).
- RF06: Exibir instrumentos virtuais conectados a nós/pinos arbitrários do circuito.
- RF07: Permitir que terceiros contribuam novos componentes e novos MCUs como **plugins nativos** (DLL/SO), sem recompilar o Core.
- RF08: Depurar firmware do MCU emulado (breakpoints, step, watch) a partir do VSCode.
- RF09: Carregar uma versão nova de um plugin já em uso não derruba instâncias existentes nem reinicia a
  simulação — via *versioned swap* (`GlobalPluginCache`, ver `lasecsimul-native-devices.spec` seção 3): v2
  carrega lado a lado de v1; só instâncias novas usam v2; v1 descarrega sozinha quando sua última instância
  for destruída. **Não existe** "descarregar e recarregar o mesmo `PluginModule`" com instâncias vivas — isso
  foi avaliado como inseguro (use-after-free de código) e descartado.
- RF10: Permitir que o usuário crie um **subcircuito** a partir de uma seleção no próprio editor de
  esquemático — circuito interno + pinos de I/O expostos + símbolo visual, salvo como arquivo `.lssubcircuit` (não
  C++, não DLL/SO) — e o reutilize como componente em outros projetos, na mesma paleta de built-ins e
  plugins. Especificação completa em `lasecsimul-subcircuits.spec`.

### 3.2 Não funcionais
- RNF01: O Core nunca bloqueia a UI do VSCode — toda comunicação Extension↔Core é assíncrona.
- RNF02: Caminho crítico do solver (stamp/solve/post-step de componentes nativos e plugins) roda inteiramente
  dentro do processo Core, sem cruzar IPC por elemento/por passo.
- RNF03: O Core não depende de Qt, VSCode API, nem de nenhum MCU concreto — testável isoladamente via CLI/headless.
- RNF04: Adicionar um componente ou um MCU não exige alterar arquivos do Core, apenas adicionar um plugin (DLL/SO) + manifesto.
- RNF05: O Core não depende de runtime gerenciado (CLR, JVM, Node, motor WASM) nem de Qt — Qt existe no
  SimulIDE-dev principalmente para a GUI (QPainter/QWidget), responsabilidade que aqui pertence ao webview da
  Extension, não ao Core; herdá-lo só para suprir as poucas lacunas da seção abaixo não se justifica (e
  evita carregar a obrigação de relinkagem da LGPLv3 num projeto que já tem complexidade de licenciamento
  própria com plugins de terceiros). Dependências mínimas do Core, quase todas MIT/Boost license, sem GUI:

  | Necessidade | Cobertura |
  |---|---|
  | Filesystem, threads, mutex | `std::filesystem`, `std::thread` (stdlib, sem dependência) |
  | Carregar plugin (DLL/SO) | `LoadLibrary`/`dlopen` direto, sem lib (ver `PluginLoader.cpp`) |
  | IPC (named pipe/unix socket) + spawn do processo QEMU | **libuv** (MIT) — mesma lib usada pelo Node por baixo; cobre os dois com uma dependência só |
  | Álgebra linear do `MnaSolver` (LU densa com pivoteamento + esparsa quando necessário) | **Eigen** (MPL2, header-only, sem GUI) — substitui fatoração à mão; ver seção 7.1. MPL2, não MIT, mas sem efeito copyleft viral (permite uso comercial/fechado sem obrigação de publicar fonte) |
  | Memória compartilhada (ring buffer de telemetria) | shim próprio (`CreateFileMapping`/`mmap`), mesmo padrão do `PluginLoader` — não justifica lib externa |
  | Parsing de JSON (manifests, `.lsproj`) | **nlohmann::json** (MIT, header-only) |
- RNF06: Extension e Core são processos distintos; a Extension nunca lê/escreve memória do Core diretamente — só via o protocolo de IPC da seção 7.
- RNF07: **Todo código C++ novo do Core é escrito para compilar em Windows, Linux e macOS — isso é verificado
  a cada PR/geração de código, não revisado só ao final.** Qualquer API específica de plataforma (carregar
  biblioteca dinâmica, memória compartilhada, captura de falha, IPC) fica isolada num shim `#ifdef`/arquivo
  por plataforma — nunca espalhada no código de domínio (`MnaSolver`, `Scheduler`, `registry/`, modelos de
  componente). Padrão já estabelecido em `PluginLoader.cpp` (LoadLibrary/dlopen) e `CrashGuard.cpp`
  (SEH/passthrough) — replicar essa estrutura para qualquer nova integração de SO, em vez de introduzir um
  novo estilo a cada arquivo. "Cross-platform" aqui significa **mesmo código-fonte compilando nos três
  alvos**, não um binário único — CI deve buildar nas três plataformas a cada mudança no Core.
- RNF08: O protocolo de IPC (canal de controle, seção 7) é versionado desde a primeira mensagem — handshake
  inicial troca `protocolVersion` antes de qualquer comando; Core/Extension recusam-se a operar contra uma
  versão incompatível em vez de assumir compatibilidade. Evita migração retroativa de mensagens já em uso.
- RNF09: O canal de telemetria (ring buffer, seção 7) tem política de descarte explícita: amostras contínuas
  (osciloscópio, traços de pino) descartam a mais antiga quando o consumidor não drena a tempo — perder uma
  amostra velha é aceitável, travar o solver esperando a Extension não é (RNF01). Eventos discretos (device
  entrou em `faulted`, fim de simulação) **não** usam esse canal lossy — vão pelo canal de controle
  (confiável), porque perder uma notificação de falha é um custo real, diferente de perder uma amostra.
- RNF10: Nenhuma configuração necessária para o Core operar (ex: quais bibliotecas de dispositivo/subcircuito
   carregar) pode depender de mecanismo específico de host. A fonte canônica é
   `LasecSimul/project/schema/component-catalog.json` (`deviceLibraries[]`) e qualquer shell deve ler esse
   arquivo para decidir quais caminhos enviar ao verbo IPC `loadDeviceLibrary`.
- RNF11: O modelo de metadados de componente e de propriedade MUST ser único para built-ins residuais,
  plugins ABI e subcircuitos. O host não pode manter contratos paralelos “mais ricos” para um tipo de
  componente e “mais pobres” para outro. Se um recurso de propriedade ou pacote visual existir para um, o
  contrato canônico precisa comportá-lo para todos.
- RNF12: Toda string declarativa visível na UI (nome de componente, rótulo/grupo de propriedade, rótulo de
  opção de enum, segmento de categoria/pasta da paleta) MUST suportar múltiplas línguas — quem declara o
  dispositivo/catálogo informa em que língua escreveu (`language`, obrigatório) e pode opcionalmente
  fornecer traduções (`translations`); a UI usa a língua ativa do VSCode quando disponível, senão cai pra
  língua declarada pelo autor — nunca string vazia. Especificação completa na seção 6.3; decisão em
  `docs/adr/0009-localizacao-de-strings-declarativas.md`. **Implementado** — Core
  (`resolvePropertySchemaForLanguage`/`getPropertySchemas`), Extension (`UnifiedCatalog.ts::
  resolveLocalizedItems`), fallback localizável pra fontes registradas (`extension.ts::
  localizedRegisteredFolder`/`localizedManifestName`), exemplo real de tradução em
  `devices/voltmeter/.lsdevice`, `devices/example-blinker/.lsdevice` e
  `project/schema/component-catalog.json` (pt-BR → en). Política de produto desta fase:
  todo dispositivo/componente novo MUST nascer com base `pt-BR` + tradução `en`, e a shell MUST
  expor chave runtime entre essas duas línguas nas configurações.

## 4. Arquitetura modular

```
┌──────────────────────────────────────────────────────────────────────┐
│ LasecSimul Extension (processo VSCode Extension Host, TypeScript)   │
│   extension.ts · webview (editor de esquemático, painéis)          │
│   ui/commands · ui/panels · ipc/CoreClient                          │
│   NÃO calcula nada elétrico — só edita, exibe, envia/recebe IPC     │
└───────────────────────────┬──────────────────────────────────────────┘
                            │ IPC local (named pipe / unix socket)
                            │  · canal de controle: comandos, netlist, propriedades
                            │  · canal de telemetria: shared memory ring buffer
┌───────────────────────────▼──────────────────────────────────────────┐
│ LasecSimul Core (processo nativo C++, independente do VSCode)       │
│                                                                      │
│  GlobalPluginCache (processo-wide, somente leitura após o load)    │
│   PluginLoader · PluginModule ativo por typeId/chipId · metadata    │
│                              │ shared_ptr<PluginModule>              │
│                              ▼                                      │
│  SimulationSession (uma por projeto aberto — hoje sempre 1 por      │
│  processo; o tipo existe para não exigir refactor de singleton se   │
│  múltiplas sessões forem necessárias no futuro, ver nota abaixo)    │
│  ┌────────────┐   stamp()/postStep() — chamada direta   ┌─────────┐ │
│  │ MnaSolver  │◄─────────────────────────────────────────┤Component │ │
│  │ Scheduler  │   (componente nativo OU PluginInstance)  │ Registry │ │
│  │ Netlist    │                                           └────┬────┘ │
│  └─────┬──────┘                                                │      │
│        │                                          PluginRuntime (desta sessão)
│  ┌─────▼─────────────┐  ┌──────────────┐  ┌──────────────────┐ │      │
│  │ Built-in components│  │  McuComponent │  │ NativeDeviceProxy│◄┘      │
│  │ (compilados no Core)│ │ (pinos reais, │  │ (= PluginInstance)│        │
│  │                     │ │  via QemuModule)│ └──────────────────┘        │
│  └────────────────────┘  └──────────────┘                              │
│  Detecção de borda (settleStep) despacha ComponentEvent{kPinChangeEventTag} │
│  pra todo componente/pino do nó — é assim que I2C/SPI/UART são decodificados │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ QEMU Integration: QemuProcessManager · QemuModule (por chip)  │  │
│  │ (arena de memória compartilhada + dispatch por endereço bruto,│  │
│  │  ver seção 8 — mecanismo validado contra o fork QEMU real)     │  │
│  └───────────────────────────────┬──────────────────────────────┘  │
└──────────────────────────────────┼─────────────────────────────────┘
                                    │ child process (spawn/exec)
                          ┌─────────▼─────────┐
                          │ qemu-system-xtensa  │
                          │ qemu-system-arm ...  │
                          └────────────────────┘
```

| Módulo (Core, C++) | Responsabilidade única (SRP) |
|---|---|
| `GlobalPluginCache` | Estado compartilhado entre sessões: `PluginModule` ativo por `typeId`/`chipId`, manifestos parseados, `ComponentMetadataRegistry`. Nunca mutado fora de um load/versioned-swap; sessões só leem. |
| `SimulationSession` | Unidade de isolamento lógico de um projeto aberto: dona de `Netlist`, `Scheduler`, `PluginRuntime`, `QemuProcessManager` dessa sessão. **Escopo atual: exatamente uma sessão por processo Core** — o tipo existe para que isso não seja um singleton implícito, não porque múltiplas sessões simultâneas sejam suportadas hoje. |
| `MnaSolver` | Monta e resolve a matriz (Modified Nodal Analysis + Newton-Raphson para não-lineares) |
| `Scheduler` | Avança o tempo de simulação, decide quando re-stampar (changed-list, ver seção 7) |
| `ComponentRegistry` / `McuRegistry` | Mapa `typeId`/`chipId` → fábrica de `IComponentModel`/`IMcuAdapter`, por sessão |
| `PluginLoader` / `PluginRuntime` | `PluginLoader` (em `GlobalPluginCache`) descobre/valida/carrega DLL/SO; `PluginRuntime` (por sessão) cria/destrói instâncias a partir do módulo ativo. Distinção completa em `lasecsimul-native-devices.spec`, seção 1. |
| `NativeDeviceProxy` / `NativeMcuAdapterProxy` | `PluginInstance` — adaptam a vtable C de um plugin (via `shared_ptr<PluginModule>`) para a interface C++ interna; solver não distingue plugin de built-in |
| `McuComponent` | `IComponentModel` que liga um `IMcuAdapter` ao circuito de verdade: polling da arena, despacho `SIM_READ`/`SIM_WRITE` pro `QemuModule` certo (por endereço), estampa elétrica real a partir de `isOutputEnabled`/`outputLevel` |
| `QemuModule`/`QemuModuleProxy` (por chip/periférico, ex: GPIO do ESP32 via plugin) | Decodifica registrador bruto (`regAddr`/`regData`) — CHIP-ESPECÍFICO de propósito, único lugar que conhece o mapa de registrador real. Sempre via plugin (`mcu_abi.h`/`LsdnQemuModuleVTable`) desde 2026-06-28 — não existe mais `QemuModule` built-in |
| Detecção de borda digital (`SimulationSession::settleStep()`) | Substitui o antigo `BusController`: ao cruzar `kDigitalLevelThreshold`, despacha `ComponentEvent{kPinChangeEventTag}` pra todo componente/pino do nó — quem decodifica I2C/SPI/UART é o próprio componente/device, bit a bit |
| `QemuProcessManager` | Ciclo de vida do processo QEMU + arena de memória compartilhada (88 bytes, seção 8.1) |
| `IpcServer` | Expõe o protocolo de controle + telemetria para a Extension |

Regra de dependência (DIP): `MnaSolver`/`Scheduler` dependem só de `IComponentModel`/`IMcuAdapter` (interfaces
C++ abstratas). Nunca importam um componente, plugin ou MCU concreto por nome.

## 5. Estrutura inicial de pastas

```
LasecSimul/
├── extension/                       # LasecSimul Extension — TypeScript, VSCode
│   ├── package.json                 # manifest da extensão (contributes, activationEvents, comandos/keybindings)
│   ├── tsconfig.json                # main (Node/Extension Host) -- compila separado do webview
│   ├── tsconfig.webview.json        # Webview (ambiente de browser, sem tipos Node) -- ver seção 13
│   └── src/
│       ├── extension.ts             # activate()/deactivate(), TODOS os comandos, handler central de
│       │                             # mensagens Webview↔Host, sanitização de manifesto, fila do Core
│       │                             # (arquivo único e grande de propósito histórico -- candidato a
│       │                             # modularização, ver plano de refatoração da auditoria de UI)
│       ├── language.ts              # locale ativo do VSCode -> pt-BR/en pra Webview e mensagens
│       ├── ipc/
│       │   ├── CoreClient.ts        # cliente do protocolo de controle (named pipe / unix socket)
│       │   ├── CoreProcess.ts       # spawn/lifecycle do processo Core nativo
│       │   ├── protocol.ts          # framing de linha (envelope de request/response/notification)
│       │   ├── types.ts             # DTOs do protocolo (PropertySchemaDto etc.), espelhados em model.ts
│       │   └── testSupport/MockCoreServer.ts  # servidor Core falso pra testes de CoreClient
│       ├── catalog/                 # lógica pura de catálogo/manifesto (testável, sem `vscode`)
│       │   ├── UnifiedCatalog.ts    # carrega/mescla component-catalog.json + registeredSources[]
│       │   ├── catalogMerge.ts      # normalização compartilhada (nextIndexedLabel etc.)
│       │   ├── simulideSceneTranslator.ts  # tradutor de cena `.sim2` real (import de subcircuito)
│       │   └── subcircuitInternals.ts # leitura de circuito interno/overlay de subcircuitos registrados
│       ├── project/
│       │   ├── ProjectTypes.ts      # schema do `.lsproj` (ProjectDocument/ProjectComponent/ProjectWire)
│       │   └── ProjectSerializer.ts # load/save com validação real de campo (não JSON.parse otimista)
│       ├── trust/
│       │   ├── TrustStore.ts        # decisão de confiar em publisher de plugin (sempre da Extension)
│       │   └── trustDecision.ts     # lógica pura de decisão, testável separado da UI de consentimento
│       └── ui/
│           ├── panels/
│           │   └── SchematicPanel.ts        # painel do canvas central (webview), sempre aberto
│           ├── views/
│           │   └── ComponentPaletteViewProvider.ts  # paleta -- Webview própria (`WebviewViewProvider`),
│           │       #  ver seção 13.1: NÃO é `TreeView` nativo (decisão final, revertida do plano original)
│           └── webview/             # código que RODA dentro da Webview (compila via tsconfig.webview.json)
│               ├── main.ts          # editor de esquemático inteiro: canvas, seleção, drag, fios, menus
│               │                     # de contexto, diálogo de propriedades (modal), undo/redo (arquivo
│               │                     # único e grande de propósito histórico, mesma nota de extension.ts)
│               ├── palette.ts       # script da Webview de paleta (busca/árvore/drag-to-place)
│               ├── paletteTree.ts   # construção da árvore a partir de `folderPath`/`category` (lógica pura)
│               ├── componentSymbols.ts  # renderer: PackageDescriptor -> SVG (ver seção 21 do native-devices.spec)
│               ├── simulidePaint.ts # tradutor SimulidePaintSpec -> PackageShape[] (primitivas declarativas)
│               ├── model.ts         # tipos da IR declarativa (PackageDescriptor, WebviewComponentModel...)
│               ├── messages.ts      # união discriminada HostToWebviewMessage/WebviewToHostMessage
│               ├── catalog.ts, instrumentTrigger.ts, valueFormatting.ts, wireGeometry.ts  # lógica pura auxiliar
│
├── core/                            # LasecSimul Core — C++ nativo, processo separado
│   ├── CMakeLists.txt
│   ├── include/lasecsimul/          # headers públicos (consumidos por plugins, ver native-devices.spec)
│   │   ├── IComponentModel.hpp      # interface C++ interna; addVoltageSource/addConductanceToGround reais, current()
│   │   ├── IMcuAdapter.hpp          # chipId/buildLaunchArgs/memoryRegions/pinMap/createModules()
│   │   ├── QemuModule.hpp           # base chip-específica: memStart/memEnd/writeRegister/readRegister/reset
│   │   ├── device_abi.h             # ABI C estável para plugins (ver lasecsimul-native-devices.spec), major 3
│   │   └── qemu_arena_abi.h         # protocolo real (regAddr/regData/SIM_READ/SIM_WRITE, 88 bytes, seção 8.1)
│   ├── test/
│   │   └── voltage_divider_test.cpp # fonte+2 resistores+terra, confere contra conta analítica (seção 7.3)
│   └── src/
│       ├── main.cpp                 # entry point do processo Core; cria GlobalPluginCache + 1 SimulationSession
│       ├── session/
│       │   └── SimulationSession.{h,cpp}     # dona de Netlist/Scheduler/PluginRuntime/Qemu desta sessão
│       ├── simulation/
│       │   ├── MnaSolver.hpp          # particiona em grupos, fatora/resolve via Eigen (seção 7.1)
│       │   ├── CircuitGroup.hpp       # 1 sistema linear (nós + variáveis extras, seção 7.3)
│       │   ├── UnionFind.hpp          # disjoint-set genérico — base das 2 passadas (seção 7.2)
│       │   ├── ComponentMatrixView.hpp # MnaMatrixView real, por componente (seção 7.2/7.3)
│       │   ├── SparseSet.hpp          # dirty-tracking O(1), array denso, cresce sob demanda (seção 7.4)
│       │   ├── Scheduler.{h,cpp}      # thread própria; fila de eventos = std::priority_queue + sequence (7.4)
│       │   └── Netlist.hpp            # 2 passadas de UnionFind + alocação de variável extra (seção 7.2/7.3)
│       ├── components/               # biblioteca padrão, compilada direto no Core (Tier nativo estático)
│       │   ├── passive/{Resistor,Capacitor,Inductor}.{h,cpp}
│       │   ├── active/{Diode,Bjt,Mosfet,OpAmp}.{h,cpp}        # candidatos a isNonlinear() (seção 7.4)
│       │   ├── logic/{AndGate,DFlipFlop,...}.{h,cpp}
│       │   ├── sources/{DcVoltageSource,AcVoltage,Battery}.{h,cpp} # DcVoltageSource já implementado
│       │   ├── connectors/Tunnel.hpp  # conecta por nome de túnel, não por fio (seção 7.2)
│       │   ├── other/Ground.hpp       # referência de 0V — todo grupo passivo precisa de uma (seção 7.3)
│       │   └── instruments/{Oscilloscope,Multimeter,FunctionGenerator,LogicAnalyzer}.{h,cpp}
│       ├── registry/
│       │   ├── ComponentRegistry.{h,cpp}         # factory, por sessão
│       │   ├── ComponentParams.hpp               # posição de pino + propriedades de uma instância
│       │   ├── ComponentMetadataRegistry.{h,cpp} # schema de pinos/propriedades/ícone, em GlobalPluginCache
│       │   └── McuRegistry.{h,cpp}
│       ├── plugins/
│       │   ├── PluginModule.{h,cpp}          # código carregado (refcount via shared_ptr), em GlobalPluginCache
│       │   ├── GlobalPluginCache.{h,cpp}     # PluginLoader + módulo ativo por typeId/chipId + metadata
│       │   ├── PluginLoader.{h,cpp}          # LoadLibrary/dlopen + validação de ABI — só descoberta/load
│       │   ├── PluginRuntime.{h,cpp}         # cria/destrói PluginInstance, por sessão
│       │   ├── NativeDeviceProxy.{h,cpp}     # PluginInstance de device
│       │   ├── NativeMcuAdapterProxy.{h,cpp} # PluginInstance de MCU adapter
│       │   └── QemuModuleProxy.hpp           # embrulha LsdnQemuModuleHandle (plugin) em QemuModule
│       ├── mcu/
│       │   ├── QemuProcessManager.{h,cpp}      # spawn/kill do processo qemu-system-* + arena (88 bytes, seção 8.1)
│       │   ├── McuComponent.{h,cpp}            # IComponentModel real: liga IMcuAdapter ao circuito via pinos
│       │   └── FirmwareWatcher.{h,cpp}         # poll de mtime na pasta configurada -> kill+respawn (seção 8.3)
│       # ESP32 não tem mais pasta aqui -- vive em mcu-adapters/espressif-esp32/ (plugin), não em core/src/mcu/
│       └── ipc/
│           ├── IpcServer.{h,cpp}
│           └── protocol/             # definição de mensagens do canal de controle
│
├── devices/                          # exemplos de plugins nativos de dispositivo (DLL/SO)
│   └── example-blinker/              # ver lasecsimul-native-devices.spec, seção 16
│
├── mcu-adapters/                     # exemplos de plugins nativos de MCU
│   └── espressif-esp32/              # ver lasecsimul-native-devices.spec, seção 10 (adaptado)
│
├── project/                          # gerenciamento de projetos (.lsproj) — schema compartilhado
│   └── schema/lsproj.schema.json
│
└── test/
    └── extension/                    # testes da camada TS (mock do IpcServer) — ainda não escrito
```

## 6. Interfaces principais

No **Core** (C++, `include/lasecsimul/`), únicas dependências que `MnaSolver`/`Scheduler` conhecem:

```cpp
// IComponentModel.hpp — implementada por componentes nativos E por NativeDeviceProxy (plugins)
class IComponentModel {
public:
    virtual ~IComponentModel() = default;
    virtual const char* typeId() const = 0;
    virtual std::span<Pin> pins() = 0;
    virtual uint32_t extraVariableCount() const { return 0; }   // fonte de tensão ideal, ver seção 7.3
    virtual void stamp(MnaMatrixView& matrix) = 0;       // só quando topologia/propriedade muda
    virtual bool isNonlinear() const { return false; }          // diodo/transistor, ver seção 7.4
    virtual bool hasConverged() const { return true; }
    virtual void postStep(uint64_t timeNs) = 0;          // hot path, opcional (ver Scheduler, seção 7)
    virtual size_t getState(uint8_t* out, size_t cap) const = 0;
    virtual void setState(const uint8_t* in, size_t len) = 0;
    virtual std::vector<PropertyDescriptor> propertyDescriptors() { return {}; } // edição em runtime, seção 6.1
    virtual std::optional<double> current() const { return std::nullopt; } // leitura de corrente, seção 6.1.4
};

// IMcuAdapter.hpp — chipId/buildLaunchArgs/memoryRegions/pinMap continuam declarativos;
// createModules() é a peça que faltava para o chip de fato afetar o circuito (ver McuComponent, seção 8).
class IMcuAdapter {
public:
    virtual ~IMcuAdapter() = default;
    virtual const char* chipId() const = 0;
    virtual QemuLaunchSpec buildLaunchArgs(std::string_view firmwarePath) const = 0;
    virtual std::span<const MemoryRegion> memoryRegions() const = 0; // faixa MMIO -> módulo concreto
    virtual std::span<const PinMapping> pinMap() const = 0;          // pino lógico -> bit/linha de um módulo
    virtual std::vector<std::unique_ptr<QemuModule>> createModules() const = 0; // módulos concretos do chip
};
```

`NativeDeviceProxy`/`NativeMcuAdapterProxy` implementam essas mesmas interfaces por dentro, delegando cada
método para a vtable C exportada por uma DLL/SO (`lsdn_device_abi.h`, detalhado em
`lasecsimul-native-devices.spec`). **O `MnaSolver` nunca sabe se está chamando um `Resistor` compilado no
Core ou um plugin carregado em runtime — o custo é o mesmo** (chamada virtual em processo único).

### 6.1 Modelo único de propriedade — compatível com o que o SimulIDE já permite hoje

Achado em auditoria do SimulIDE-dev: o sistema real de propriedades não é “um número editável e pronto”.
`gui/properties/` e `PropDialog` suportam, hoje, pelo menos estes formatos de edição:

- número com unidade/multiplicadores (`double`, `int`, `uint`, `numval.cpp`);
- enum com lista de valores e rótulos (`enum`, `enumval.cpp`);
- booleano (`bool`, `boolval.cpp`);
- texto curto (`string`, `strval.cpp`);
- texto longo/multilinha (`textEdit`, `textval.cpp`);
- caminho (`path`) e arquivo (`file`, ambos em `pathval.cpp`);
- cor (`color`, `colorval.cpp`);
- ponto/coordenada (`point`, usado em propriedades geométricas).

O LasecSimul **não** deve copiar essa taxonomia ao pé da letra na ABI, porque parte dela são detalhes de
widget e nomes históricos do código Qt. A regra aqui é: quando dois nomes do SimulIDE forem o mesmo conceito
com diferença só de apresentação, o contrato do LasecSimul deve unificar.

#### 6.1.1 Taxonomia canônica e simplificada

O contrato canônico do projeto passa a ter **4 tipos de valor** e metadados de UI por cima deles:

- `number` → cobre `double`, `int`, `uint` do SimulIDE.
  Metadados: `integerOnly`, `unsignedOnly`, `min`, `max`, `step`, `unit`, `siPrefixPolicy`.
- `string` → cobre `string`, `enum`, `color`, `path`, `file`, `textEdit`.
  Metadados: `editor` (`text`, `textarea`, `enum`, `color`, `path`), `options[]`, `pathKind`,
  `fileFilters[]`, `placeholder`.
- `bool` → cobre `bool`.
- `point` → cobre `point`.

Isso evita proliferar tipos quase-iguais na ABI sem perder capacidade:

- `enum` não vira um tipo de valor separado; é `string` com `editor="enum"` e `options[]`.
- `color` não vira um tipo de valor separado; é `string` com `editor="color"` (ex: `#RRGGBB`).
- `path` e `file` viram um conceito só (`editor="path"`), diferenciados por `pathKind`.
- `textEdit` e `string` viram o mesmo tipo de valor (`string`), diferenciados por `editor`.
- `double`/`int`/`uint` viram `number`, diferenciados por flags.

#### 6.1.2 `PropertySchema` substitui a visão minimalista antiga — implementado

O projeto deixou de tratar "propriedade editável" só como `name + unit + get/set`. O contrato canônico é um
schema reutilizável em manifesto, metadata registry, IPC e UI. Forma real implementada (`core/include/
lasecsimul/Types.hpp`, não a sketch original desta seção — ver nota abaixo):

```cpp
enum class PropertyValueKind : uint32_t { Number = 0, String = 1, Bool = 2, Point = 3 };

struct PropertyOption { std::string value; std::string label; };

enum PropertySchemaFlags : uint32_t {
    PropertySchemaNone = 0,
    PropertySchemaHidden = 1u << 0,
    PropertySchemaReadOnly = 1u << 1,
    PropertySchemaNoCopy = 1u << 2,
    PropertySchemaAffectsTopology = 1u << 3,
    PropertySchemaRequiresRestart = 1u << 4,
    PropertySchemaShowOnSymbol = 1u << 5,
};

struct PropertySchema {
    std::string id;             // chave estável em projeto/IPC/ABI
    std::string label;          // rótulo mostrado na UI
    std::string group;          // grupo/aba lógica, estilo PropDialog
    std::string unit;
    PropertyValueKind valueKind = PropertyValueKind::String;
    std::string editor = "text"; // "text" | "number" | "checkbox" | "switch" | "select"/"enum" | "display" | ...
    PropertyValue defaultValue = std::string{};
    std::optional<double> minValue;
    std::optional<double> maxValue;
    std::optional<double> step;
    std::vector<PropertyOption> options;
    uint32_t flags = PropertySchemaNone; // bitmask das 6 flags acima
};

using PropertyValue = std::variant<double, std::string, bool, PropertyPoint>; // PropertyPoint = {x, y}
```

Diferença da sketch original desta seção (corrigida agora pra não divergir do código real): `flags` é
bitmask (`uint32_t`), não `vector<std::string>`; `options` é `vector<PropertyOption>` (`{value, label}`
emparelhado), não dois arrays paralelos; `minValue`/`maxValue`/`step` são `optional<double>` dedicados, não
`optional<PropertyValue>` genérico (nenhuma propriedade hoje precisa de min/max não-numérico).

`PropertyDescriptor` (`core/include/lasecsimul/IComponentModel.hpp`) é o adaptador runtime — `get`/`set`
de UMA instância — e carrega o `PropertySchema` correspondente:

```cpp
struct PropertyDescriptor {
    std::string name;
    std::string unit;
    std::function<PropertyValue()> get;
    std::function<void(const PropertyValue&)> set;
    PropertySchema schema; // preenchido tanto por built-in quanto por plugin — ver abaixo
};
```

**Built-ins participam do mesmo contrato que plugins (lacuna fechada).** Cada componente built-in com
propriedade editável (`Resistor`, `Capacitor`, `Inductor`, `DcVoltageSource`, `Button`) declara um método
estático `propertySchema()` (mesmo arquivo `.hpp` do componente) que devolve o `PropertySchema` rico —
reusado em dois lugares: (a) `propertyDescriptors()` da instância preenche `PropertyDescriptor::schema` a
partir dele; (b) `CoreApplication::registerBuiltinComponents` registra o mesmo schema, por `typeId`, no
`ComponentMetadataRegistry` (`core/src/registry/ComponentMetadataRegistry.hpp`) — **o mesmo registry que
plugins já populavam via `loadDeviceLibraryFile`** (`.lsdevice`'s `properties[]`, parseado por
`parsePropertySchema`/`parsePropertySchemaList` em `CoreApplication.cpp`). Não existem dois registries
paralelos (um pra built-in, um pra plugin); a fonte é única, só o que a alimenta difere (C++ estático vs.
JSON de manifesto).

`SimulationSession::setProperty(component, id, value)` continua sendo o caminho genérico de edição em
runtime — localiza o `PropertyDescriptor` pelo nome e chama `set`. **Implementado** (estava listado como
pendente aqui até 2026-07-08, quando uma auditoria "pente fino" achou que já tinha sido feito sem a spec
ser atualizada — mesma classe de drift já documentada pro Newton-Raphson do diodo): validação de
tipo/faixa/opções contra o schema antes de chamar `set` (`SimulationSession.cpp:184-207`,
`propertyKindMatches`/`minValue`/`maxValue`/`options`, cada um com seu próprio código de erro) E reação
automática às duas flags — `affectsTopology`/`affectsPinCount` marcam `m_topologyDirty = true`
(`SimulationSession.cpp:211`); `requiresRestart` volta `{"requiresRestart": true}` na resposta IPC de
`setProperty` (`CoreApplication.cpp:1408-1409`), lido por `coreLifecycle.ts` que mostra
`vscode.window.showInformationMessage(...)` pro usuário — regressão coberta em
`core/test/core/CoreBootstrapTest.cpp` ("setProperty aplica mudanca em propriedade requiresRestart").

#### 6.1.3 IPC `getPropertySchemas` e fluxo até a Webview — implementado

A lacuna "6. IPC de metadata" (seção 6.2 original) está resolvida assim — **divergindo da sketch original
de `ComponentDisplayMeta.propertySchema` por instância**: schema é por **`typeId`** (catálogo), nunca por
instância, então viaja junto do catálogo, não de cada componente.

```
Core: handler "getPropertySchemas" (sem payload) → { schemasByTypeId: { "<typeId>": [<schema>, ...] } }
      -- itera ComponentMetadataRegistry::all() (novo método), serializa cada PropertySchema via
         propertySchemaToJson() (inverso de parsePropertySchema), CoreApplication.cpp
Extension: CoreClient.getPropertySchemas() → extension.ts::attachPropertySchemas(), chamado dentro de
      refreshUnifiedCatalogState() depois de loadConfiguredDeviceLibraries() -- anexa
      WebviewComponentCatalogEntry.propertySchema (PropertySchemaEntry[], cópia webview-safe do DTO,
      ver extension/src/ui/webview/model.ts) por entrada do catálogo, casando por typeId
Webview: main.ts::resolvePropertyFields(component) -- acha a entrada do catálogo pelo typeId do
      componente, monta PropertyField[] na ORDEM do array do schema (isso já dá ordem de campo E ordem
      de grupo/aba); cai pra heurística antiga (inferPropertyFields, por typeof do valor JS) só se o
      Core não tiver schema pra aquele typeId ainda (ex: registrado porém desabilitado)
```

`listComponents()`/`ComponentDisplayMeta` (a sketch original desta seção) **permanecem um gap separado,
ainda não implementado** — declarado em `CoreClient.ts`, sem handler no Core (ver `docs/mvp-limitacoes.md`).
Não foi reaproveitado pra schema porque seu DTO é por instância; `getPropertySchemas` resolveu a
necessidade real (UI de propriedades) sem depender dele.

Teste de regressão: `core_bootstrap` (`testGetPropertySchemasOverIpc` — built-in aparece sem nenhum
`loadDeviceLibrary`, plugin aparece só depois); `passive_components`/`logic_components` (cada
`propertyDescriptors()[0].schema` não-vazio).

#### 6.1.3.1 ABI v2 (2026-06-30) — `readoutFormatByTypeId`/`interactionKindByTypeId`, mesmo payload

A mesma resposta de `getPropertySchemas` ganhou 2 mapas irmãos ADITIVOS (`readoutFormatByTypeId`/
`interactionKindByTypeId`, por typeId) — como a UI decodifica `getComponentState()`/interage com um
componente sem checar typeId em código nenhum. Especificação completa, desenho, justificativa (por que
LasecSimul precisa disso onde o SimulIDE usa despacho virtual C++) e migração dos devices reais em
`.spec/lasecsimul-native-devices.spec` seção 22. Teste de regressão: `core_bootstrap`
(`testGetPropertySchemasOverIpc`, mesma função, asserções novas pra oscope/logic_analyzer/ampmeter/
freqmeter/probe/push/switch).

#### 6.1.3.2 `setSubcircuitChildProperty`/`getSubcircuitChildInstanceId` (2026-06-29)

Variante de `setProperty` endereçando por `{instanceId do subcircuito, localId do componente interno}`
em vez de um `componentIndex` de topo (a Extension não tem como conhecer o índice Core de um
componente DENTRO de um subcircuito sem perguntar) — usado pelo overlay de Modo Placa e pelo diálogo
de propriedades de componente exposto no esquemático principal. Especificação completa em
`.spec/lasecsimul-subcircuits.spec` seção 6.1 (handler em `CoreApplication.cpp`,
`SimulationSession::findSubcircuitChildByLocalId`).

### 6.1.4 Leitura de corrente (`current()`) — implementado 2026-06-28

Opção de baixo custo, sem incógnita nova na matriz: `IComponentModel::current()` lê estado já cacheado na
última `stamp()` (`std::nullopt` se o componente não implementa). `MnaMatrixView::getBranchCurrent()` dá
leitura gratuita da corrente de ramo de fontes de tensão ideal (variável extra já resolvida).
`SimulationSession::componentCurrent(componentIndex)` nunca dispara solve novo — `std::nullopt` se o
componente não implementa ou já foi removido (mesmo princípio de `nodeVoltageOfPin`). Exposto via IPC
`getComponentCurrent` (`CoreApplication.cpp`) e `CoreClient.getComponentCurrent` na Extension.

**Convenção de sinal, validada empiricamente, não só derivada**: convenção passiva — positiva entrando no
primeiro pino/saindo no segundo (ou na terra implícita pra componente de 1 pino); fonte fornecendo energia
aparece **negativa**. Implementado em: `Resistor`, `Inductor`, `Capacitor` (sempre 0.0 — modelo atual não
contribui nada pra matriz), `Diode`, `DcVoltageSource`, `Battery`, `Rail`, `FixedVolt`, `VoltSource`,
`CurrSource`, `Csource`, `Clock`, `WaveGen`, `Ampmeter`.

Lição de um bug real corrigido neste caminho: qualquer componente com pino "decorativo" (ex: `gnd` de um modo
de operação) precisa de alguma contribuição na matriz — nunca zero absoluto, ou a linha fica inteiramente
zerada (matriz singular). `WaveGen` no modo não-bipolar tinha esse bug, corrigido fixando o pino em 0V via
`addConductanceToGround`.

### 6.1.5 `PropertyDefinition` — schema + get/set num só lugar (implementado 2026-07-09)

Achado de auditoria arquitetural (`docs/25-auditoria-arquitetural-core-2026-07-09.md`; ver também
ADR 0010): até esta correção, cada built-in implementava **dois** métodos separados —
`static propertySchema()` (metadado) e `propertyDescriptors()` de instância (get/set) — sempre
redigitando o `id` de cada propriedade duas vezes, sem vínculo verificado pelo compilador. Isso já
causou um bug real em `Probe.hpp`: o descriptor pegava schema por ÍNDICE numérico do vetor, então
reordenar `propertySchema()` quebraria o descriptor errado em silêncio.

`core/include/lasecsimul/PropertyDefinition.hpp` (novo) declara:

```cpp
struct PropertyDefinition { PropertySchema schema; std::function<PropertyValue()> get;
                             std::function<PropertyBindResult(const PropertyValue&)> set; };

std::vector<PropertyDescriptor> toPropertyDescriptors(std::vector<PropertyDefinition>);
std::optional<std::string> validatePropertyValue(const PropertySchema&, const PropertyValue&);
PropertyValue propertyOrDefault(const std::unordered_map<std::string, PropertyValue>& properties,
                                 const PropertySchema& schema);
PropertySchema schemaById(const std::vector<PropertySchema>& schemas, const std::string& id);
```

Uma classe migrada declara `properties()` (não-estático, schema+get+set casados por `schemaById`,
nunca por posição) e `propertyDescriptors()` vira `return toPropertyDescriptors(properties());`.
`propertySchema()` estático continua existindo (usado por `registerBuiltinMetadata`, sem instância
disponível ainda) — agora é a ÚNICA fonte de schema, `properties()` busca nele por id.

`propertyOrDefault` fecha uma segunda lacuna, mais séria: `ComponentParams::property(name, default)`
(usado na CRIAÇÃO de um componente, a partir de um `.lsproj` salvo) nunca validava nada contra o
schema — caía no default do chamador em qualquer mismatch de tipo/faixa, em silêncio total. Já
causou 2 bugs reais confirmados (`SimulidePassiveState`, `Probe` — `pauseOnChange`/`showVolt`
perdidos ao reabrir um projeto). `propertyOrDefault` valida o valor salvo contra o schema
(`validatePropertyValue`, mesma regra que `SimulationSession::setProperty` já usa em runtime) antes
de aceitar; se inválido, cai no default do SCHEMA (não do chamador) com log em stderr.

**Migração completa (2026-07-09)**: todos os built-ins do Core (`core/src/components/**/*.hpp`,
incluindo as 8 classes-molde de `SimulideBuiltins.hpp`) foram migrados pro padrão `properties()` --
não sobra nenhum `descriptor.schema = schemas[N]` (acoplamento posicional) no projeto. Detalhe
completo por arquivo em `docs/25-auditoria-arquitetural-core-2026-07-09.md` §17.1 e ADR 0010.
`Probe`/`Resistor`, as duas classes com bug real já confirmado, também tiveram suas fábricas em
`registerBuiltinComponents` (`CoreApplication.cpp`) convertidas pra `propertyOrDefault` em vez de
`p.property()` direto -- as demais ~23 fábricas continuam usando `p.property()` (o lado de EDIÇÃO já
valida via `PropertyDescriptor::set` migrado; só o lado de CRIAÇÃO ainda não converteu pra
`propertyOrDefault` em todo lugar, gap menor que o original já que o schema agora existe e é
consistente em toda classe).

Teste dedicado: `core/test/property_definition_test.cpp` (`property_definition` no `ctest`) —
prova `validatePropertyValue`/`propertyOrDefault` isoladamente e que editar UMA propriedade de
`Probe`/`Resistor` nunca afeta as outras (a exata classe de bug que o acoplamento posicional antigo
permitia); `inert_components_fix_test.cpp` cobre o comportamento elétrico de `OpAmp`/`AnalogMux`/
`ResistorArray`/`DiodeLegArray` (também migrados, junto com `leakagePinIndices()` -- ver seção sobre
LeakageGuard em `.spec/lasecsimul.spec` §7.3 e ADR 0011).

### 6.2 Lacunas obrigatórias antes da expansão do catálogo estilo SimulIDE

Para que o catálogo atual do SimulIDE (ver `itemlibrary.cpp` e `gui/properties/`) possa migrar para o
LasecSimul sem reabrir arquitetura a cada família de componente, os seguintes pontos foram identificados.
Status atualizado depois da seção 6.1.2/6.1.3:

1. ~~**ABI de propriedade genérica**: substituir o bootstrap limitado a `get_property_f32` por
   `config_get` + `set_property/get_property` tipados.~~ **Feito** — `device_abi.h`, vtable de plugin tem
   `get_property`/`set_property` (10 funções, ABI 1.1); `config_get` existe em `LsdnHostApi`.
2. ~~**Schema único de componente**: `.lsdevice`/catálogo/IPC/Core precisam falar o mesmo idioma para
   `pins`/`properties`.~~ **Feito pra `properties`** (seção 6.1.2/6.1.3, built-in e plugin no mesmo
   `ComponentMetadataRegistry`). **Ainda não feito pra `package`/`pins`** de built-in — ver item 3.
3. **Package data-driven**: a renderização de símbolo/corpo/pinos de built-in ainda depende de
   `componentSymbols.ts` (switch hardcoded por `typeId`) — plugins/subcircuitos já usam `package.json`
   data-driven (`lasecsimul-native-devices.spec` seção 21), built-ins não. **Parcialmente mitigado pela seção
   13.5** (2026-06-28): os componentes que precisavam de renderização gráfica rica/protocolada (displays,
   TFTs, MAX72xx, WS2812, servo, DIAC/SCR/TRIAC, BJT/MOSFET/JFET, transformer) foram movidos de built-in
   incompleto pra plugin ABI — esses já ganham `package.json` data-driven de graça. O que resta como built-in
   C++ de fato (resistivos, potenciômetro, chaves, relé simples, regulador, LED simples) não precisa de
   renderização rica hoje; o gap descrito aqui só volta a importar se um built-in novo precisar de corpo
   gráfico custom — não bloqueia o catálogo atual.
4. **Semântica declarada de propriedade**: flags `affectsTopology`/`requiresRestart`/`readOnly`/
   `showOnSymbol`/`noCopy`/`hidden` **existem no schema e viajam até a UI** (`readOnly`/`hidden`/
   `showOnSymbol` já têm efeito real na Webview — campo desabilitado, oculto, ou ligado à telemetria).
   `affectsTopology`/`requiresRestart` **ainda não têm efeito no Core** (são metadata exibida, não
   comportamento) — aberto, ver nota no fim da seção 6.1.2.
5. **Core como runtime genérico**: built-ins continuam classes C++ dedicadas (não migraram pra
   manifesto+ABI) — decisão consciente desta rodada: deram ao built-in o MESMO schema rico que plugin já
   tinha, sem removê-los como C++. Migrar built-in pra plugin "de fábrica" continua um item separado, não
   decidido. Aberto.
6. ~~**IPC de metadata**: a UI deve poder pedir ao Core/registry o schema completo do componente sem
   inferir comportamento por `typeId`.~~ **Feito** — `getPropertySchemas` (seção 6.1.3).

Itens 3 e 5 continuam abertos; sem eles, built-in nunca atinge paridade total de extensibilidade com
plugin/subcircuito (que já são 100% manifesto), mas isso não bloqueia o catálogo atual de crescer com novas
propriedades — só limita acrescentar built-in NOVO sem tocar C++.

### 6.3 Internacionalização de strings declarativas (labels, grupos, taxonomia) — implementado

**Requisito**: toda string visível de UI que vem de uma declaração estática (não de telemetria/estado de
simulação) — nome de componente, rótulo/grupo de propriedade, rótulo de opção de enum, segmento de
`folderPath`/categoria da paleta — precisa suportar múltiplas línguas. Quem constrói um dispositivo (plugin
nativo ou, no futuro, um subcircuito publicado) declara em qual língua (ou línguas) escreveu essas strings;
a UI mostra na língua ativa do VSCode quando disponível, senão cai pra língua que o autor de fato forneceu
— nunca string vazia, nunca erro. Built-in segue o mesmo contrato (hoje só declara `pt-BR`).

Precedente real, não suposição: o próprio SimulIDE-dev já resolve exatamente isto — `itemlibrary.cpp`
declara os nomes/categorias em inglês e `resources/translations/simulide_pt_BR.ts` (Qt Linguist, mecanismo
`tr()`) fornece a tradução pt_BR carregada em runtime (já referenciado na seção 13.1). O LasecSimul não
reusa Qt Linguist (não há Qt no projeto), mas adota o mesmo princípio — string base + mapa de traduções —
num formato JSON simples, coerente com o resto do manifesto.

#### 6.3.1 `LocalizedString` — tipo canônico

```typescript
// Conceitual — mesmo formato em JSON (.lsdevice, component-catalog.json) nos dois lados (Core e
// Extension), implementado duas vezes (C++ e TypeScript) com o MESMO algoritmo de resolução, não
// uma dependência cruzada entre os dois processos.
type LocalizedString = string | Record<string, string>;
// string simples = string já na língua-base declarada pelo manifesto (ver 6.3.2) -- forma mínima,
// sem exigir mapa de quem só escreve numa língua.
// Record<string,string> = mapa BCP-47 (ex: "pt-BR", "en", "en-US") -> string traduzida.
```

**Implementado** (`devices/voltmeter/.lsdevice`, `project/schema/component-catalog.json`): o tipo é o
conceito; a codificação JSON real NÃO faz o campo em si virar union — `properties[].label`/`items[].label`
continuam sempre string simples (a língua-base, exatamente como já eram antes desta seção existir), e o
"mapa" mora num bloco `translations.<lang>` paralelo, separado, no mesmo arquivo (ver 6.3.2). Mantém o
arquivo-base 100% legível como já era (puro pt-BR), em vez de toda string virar `{"pt-BR": "...", "en":
"..."}` inline — o `LocalizedString` acima é o modelo mental, não o JSON literal.

Todo campo hoje declarado como `string` solto e VISÍVEL ao usuário final passa a aceitar
`LocalizedString` em vez de só `string` — não troca de tipo nos campos que são identificador estável
(`id`, `typeId`, `editor`, `valueKind`, `unit` continuam `string` puro: `unit` é símbolo técnico ("Ω", "V"),
não texto traduzível). Campos afetados:

- `.lsdevice`: `name` (nome do dispositivo), `properties[].label`, `properties[].group`,
  `properties[].options[].label`, `pins[].label`, `package.shapes[].value` (texto desenhado no símbolo).
- `component-catalog.json`/`library.json`/fontes registradas: `items[].label`, cada segmento de
  `items[].folderPath` (categoria/pasta da paleta).
- Schema de built-in (C++, `PropertySchema::label`/`group`, `PropertyOption::label`, `displayName` de
  `ComponentMetadata`): mesma forma conceitual, representada em C++ como
  `std::variant<std::string, std::unordered_map<std::string, std::string>>` (ou `std::string` continua
  válido — caso de língua única — e um mapa só existe quando há tradução de fato).

#### 6.3.2 Língua-base declarada — nunca string vazia

Todo manifesto (`.lsdevice`) e toda declaração de built-in passam a ter uma língua-base obrigatória:

```json
{
  "language": "pt-BR",
  "translations": {
    "en": {
      "name": "DC Voltmeter (two-point measurement)",
      "properties": { "displayVoltage": { "label": "Measured voltage", "group": "Reading" } }
    }
  }
}
```

- `language` (string, BCP-47, **obrigatório**): a língua em que o autor escreveu os campos `string`
  simples do resto do manifesto (`name`, `properties[].label`, etc.) — declarar isto é o que permite ao
  host saber "essa string que não é um mapa, em que língua está" sem adivinhar.
- `translations` (objeto, **opcional**): por língua adicional, um subconjunto dos MESMOS campos
  (`name`/`properties.<id>.label`/`.group`/opções/`pins.<id>.label`) — só o que o autor efetivamente
  traduziu; campo ausente em `translations.<lang>` cai pra língua-base, não pra string vazia.
- Regra de catálogo desta fase: para componentes/dispositivos mantidos pelo projeto, `translations.en`
  deixa de ser opcional na prática e passa a ser obrigatória; a língua-base continua `pt-BR`.
- A mesma regra vale pros segmentos de pasta/categoria (`folderPath`) e para nomes derivados de fontes
  registradas/subcircuitos: a UI nunca deve ficar presa a um nome de pasta em uma língua só quando o
  usuário alternar a configuração do editor entre `pt-BR` e `en`.
- Um dispositivo com `language` só (sem `translations`) é 100% válido — equivalente ao "se não tiver a
  primeira [tradução], usa a que tem" pedido: a língua-base SEMPRE existe e é sempre o fallback final.
- `folderPath`/`label` no catálogo seguem a mesma idéia: cada fonte (catálogo base, `library.json` de
  plugin, fonte registrada) declara seu `language`; quando o autor não traduziu o `folderPath` pra outra
  língua, a pasta na paleta aparece na língua-base mesmo com a UI em outro idioma — preferível a uma
  pasta com nome técnico/typeId.

#### 6.3.3 Resolução — mesmo algoritmo nos dois processos

```
resolve(localized, requestedLang, baseLang):
  se localized é string simples  → devolve localized (já é a língua-base, por definição de 6.3.2)
  se localized é mapa:
      se mapa[requestedLang] existe        → devolve mapa[requestedLang]
      senão se mapa[baseLang] existe         → devolve mapa[baseLang]
      senão                                  → devolve o primeiro valor do mapa (alguma língua existe,
                                                 nunca um mapa vazio é um LocalizedString válido)
```

- **Core** resolve isso ao responder `getPropertySchemas` (e, no futuro, qualquer verbo de metadata):
  request ganha um campo opcional `language` (BCP-47); Core devolve string já resolvida, não o mapa
  inteiro — Extension/Webview nunca precisam saber que tradução existe, só o resultado.
- **Extension** resolve isso pro `component-catalog.json`/fontes registradas (que ela lê direto do disco,
  sem o Core no meio) com o MESMO algoritmo, implementado em TS — `vscode.env.language` é a `requestedLang`
  passada pros dois lados (pro Core, vai dentro do payload de `getPropertySchemas`; pro catálogo local, é
  só uma chamada de função).
- Webview nunca resolve idioma — sempre recebe string já resolvida tanto do catálogo (Extension) quanto
  do schema (Core via Extension) — consistente com a Webview não ter acesso a `vscode.*` (decisão de
  desacoplamento, seção 1.1/ADR 0007).

#### 6.3.4 Fora de escopo desta seção

- Strings de erro/log do Core e da Extension (não são declarativas de dispositivo, não fazem parte do
  manifesto) — fora de escopo; tratamento de l10n da própria Extension (`vscode-nls`/`package.nls.json`,
  textos de comando/menu) é mecanismo nativo do VSCode, decisão independente, não decidida aqui.
- Subcircuitos (`.lssubcircuit`) ganham o mesmo contrato (`language`/`translations`) quando a seção 5 de
  `lasecsimul-subcircuits.spec` for revisada — não duplicado aqui, só referenciado.
- Decisão completa, alternativas descartadas e justificativa em
  `docs/adr/0009-localizacao-de-strings-declarativas.md`.

## 7. Fluxo de simulação

0. **Handshake de versão, antes de qualquer comando**: ao conectar, `CoreClient` envia `{ protocolVersion }`;
   `IpcServer` responde aceitando ou recusando. Versão incompatível encerra a conexão com erro explícito —
   nunca segue assumindo compatibilidade. Isso é o que permite evoluir mensagens do canal de controle sem
   migração retroativa (ver RNF08); o payload de cada mensagem é versionado dentro do mesmo esquema.
   **Framing de transporte** (2026-06-30): cada mensagem é uma linha JSON terminada em `\n`
   (newline-delimited), igual desde sempre — o que mudou foi `IpcServer::readLine()` (Windows e
   POSIX): lia 1 byte por `ReadFile`/`read()` (N syscalls pra uma mensagem de N bytes, clássico
   gargalo de I/O); passou a ler em blocos de 4096 bytes num `m_readBuffer` interno, extraindo linhas
   por `\n` e guardando sobra parcial pro próximo `readLine()` — mesmo protocolo/formato de mensagem,
   só troca de ESTRATÉGIA de leitura. `sendLine()` não mudou (já escrevia a linha inteira de uma vez).
1. Webview edita o esquemático → `CoreClient` envia o diff (componente adicionado/removido, propriedade
   alterada, conexão alterada) pelo canal de controle ao `IpcServer` do Core.
2. Core atualiza a `Netlist` e marca os componentes afetados como "dirty".
3. `Scheduler` roda em **thread própria, separada da thread do `IpcServer`** — espelha o padrão GUI-thread +
   worker-thread do SimulIDE (`Simulator::timerEvent`/`QtConcurrent::run`, ver decisão da seção 7.1): um
   macropasso pesado nunca atrasa a resposta a um comando `pause`/`addComponent` chegando por IPC.
   **Correção sobre o SimulIDE**: lista de "dirty" não é lista ligada intrusiva — é um *sparse set* (seção
   7.1) por ser mais amigável a cache em hardware atual; mesmo efeito (push/remove O(1), sem alocação por
   item), iteração contígua em vez de perseguir ponteiros.
4. A cada macropasso `Δt`, dentro de um laço que **assenta antes de avançar o tempo** (não é stamp-once/
   solve-once — ver seção 7.1, "settle loop"):
   a. Componentes "dirty" são stampados (lineares direto; não-lineares entram na iteração de
      `NewtonRaphson`) — cada um escreve só no grupo (componente conectado) a que pertence (seção 7.1).
   b. `MnaSolver` resolve **só os grupos que mudaram** — refatora (LU) só se a admitância/topologia daquele
      grupo mudou; se só a fonte/corrente mudou, reaproveita a fatoração e só resolve (seção 7.1) — e resolve
      múltiplos grupos dirty **em paralelo** no thread-pool do Core, já que grupos não compartilham estado.
   c. Se o solve de algum grupo dirtyficou outro componente (ex: saída de um comparador muda, derruba a
      entrada de outro), volta ao passo (a) para esse(s) componente(s) **antes** de avançar `Δt` — o laço só
      sai quando não há mais "dirty" pendente e a iteração não-linear convergiu.
   d. `postStep()` roda **só** para componentes que se registraram como "dinâmicos" (capacitores/indutores
      com estado, fontes variáveis no tempo, instrumentos amostrando, plugins com comportamento temporal,
      pinos de MCU) — um resistor estático nunca tem `postStep()` chamado.
   e. Detecção de borda digital: quando a tensão de um nó cruza `kDigitalLevelThreshold` (2.5V,
      `core/include/lasecsimul/Types.hpp`), dispara `ComponentEvent{kPinChangeEventTag, localPinIndex,
      nivel, nsDesdeABordaAnterior}` para todo componente/pino presente naquele nó (`Netlist::Topology::
      pinRefsByNode`) — built-in ou plugin, sem distinção. **Substitui por completo** o antigo
      `BusController`/I2C/SPI/UART por byte: protocolo agora é decodificado bit a bit pelo próprio
      componente/device do outro lado do fio, nunca por um módulo de barramento intermediário.
   f. `McuComponent` (MCU emulado) processa eventos pendentes da arena QEMU no seu próprio `stamp()`
      (`SIM_READ`/`SIM_WRITE` despachado pro `QemuModule` certo por endereço) e injeta no `Netlist` os
      níveis elétricos resultantes — tudo dentro do mesmo processo Core, sem cosimulação assíncrona
      (diferente do que era necessário com WASM/workers). Agendamento é por evento detectado, não pelo
      timestamp exato (`qemuTime`) reportado pelo QEMU — simplificação aceitável para GPIO digital simples,
      revisitar se/quando precisão de timing fino for necessária (ver `docs/17-pendencias-pos-sessao-qemu-abi.md`,
      seção 3.6).
5. Telemetria (amostras de instrumentos, traços de pino) é publicada num ring buffer de memória compartilhada;
   a Extension lê e renderiza no webview sem round-trip de IPC por amostra. Política de descarte sob
   saturação é a da RNF09 (descarta amostra mais antiga; eventos discretos como `faulted` vão pelo canal de
   controle, não por aqui).
6. `pause()/step()/stop()` controlam o `Scheduler`; o Core não distingue se a pausa veio de um comando do
   usuário ou de um breakpoint de firmware via QMP. Como o `Scheduler` está em thread própria (item 3), esses
   comandos chegam e são honrados mesmo com um macropasso pesado em andamento.

**Auditoria de performance (2026-06-30)**: revisão dedicada do solver/scheduler (dirty-tracking em 2
níveis, item 7.1 abaixo) e do carregamento de DLL/projeto (`LoadLibrary`/`dlopen` nativo do SO) não
achou gargalo real sem evidência de profiling — ambos documentados como já adequados nesta rodada, sem
mudança especulativa. Os 2 gargalos REAIS confirmados e corrigidos foram: leitura de IPC byte a byte
(item 0 desta seção) e reconstrução total do DOM da Webview a cada render (`extension/src/ui/webview/
main.ts::createComponentElement`/`updateComponentElement`, reconciliação incremental por id —
implementada, pendente validação manual interativa do usuário antes de considerar fechada).

### 7.1 `MnaSolver` — decisões de algoritmo (auditoria do SimulIDE-dev, com correções)

Mecanismo de partida validado lendo `C:\SourceCode\simulide_2\src\simulator\{circmatrix,e-node,simulator}.{h,cpp}` — mas
**não copiado às cegas**: SimulIDE é um projeto solo de 2012+, e nem toda escolha dele resiste ao escrutínio
em hardware/bibliotecas de hoje. Decisão por item, com o porquê:

| Item | Decisão | Origem |
|---|---|---|
| Particionar por componente conectado (DFS sobre adjacência de nós, cada grupo galvanicamente isolado vira um sistema linear independente) | **Adotado como está** | `CircMatrix::analyze()`/`addConnections` — técnica atemporal de teoria de grafos, sem contra real |
| Dirty em 2 níveis por grupo: admitância (precisa refatorar) vs corrente (só resolver) | **Adotado como está** | `CircMatrix::solveMatrix()` — técnica numérica padrão (SPICE moderno faz igual), não é "coisa de 2012" |
| Nó isolado (1 conexão) resolve por Lei de Ohm direta, com acumulador próprio, nunca entra em matriz | **Substituído**: vira `CircuitGroup` 1×1 normal, mesmo pipeline Eigen de qualquer outro grupo | `eNode::solveSingle()`/`m_totalCurr`/`m_totalAdmit` — útil pra evitar montar matriz em 2012; com Eigen, 1×1 já é trivial, manter um acumulador paralelo só pra esse caso é complexidade que não se paga aqui. Único cuidado: nó sem nenhuma conexão real dá matriz singular — detectar (`!voltages.allFinite()`) e cair pra 0V com aviso, nunca propagar NaN |
| Hierarquia (subcircuitos/dispositivos aninhados) achatada num `Netlist` único antes do solver rodar | **Adotado como está** | `Simulator::createNodes()` — sem matriz-dentro-de-matriz |
| LU densa, sem pivoteamento, escrita à mão (método de Crout) | **Substituído**: `Eigen::PartialPivLU` (denso, com pivoteamento parcial) por grupo; `Eigen::SparseLU` como caminho alternativo quando um grupo crescer além de um limiar configurável | A versão do SimulIDE não pivota (`if (div==0) continue`, sem mais) — risco de imprecisão numérica em matrizes mal-condicionadas; vetorização/cache de uma lib madura supera loop manual |
| Lista de "dirty"/changed via ponteiro intrusivo (`nextChanged`) | **Substituído**: sparse set (array denso + índice esparso, swap-and-pop na remoção) — mesma O(1) de push/remove, sem perseguir ponteiro | Pointer-chasing é hostil ao cache em CPUs atuais; array contíguo favorece prefetch e (eventual) vetorização ao iterar "tudo que está dirty" |
| Fila de eventos agendados (timers) via ponteiro ordenado por tempo | **Substituído**: `std::priority_queue` (heap binário sobre array) | Mesmo raciocínio do item anterior — stdlib já dá isso de graça, sem reinventar |
| Resolver matriz inteira numa única worker thread (nunca paralelo entre núcleos) | **Divergência deliberada**: grupos dirty são resolvidos em paralelo no thread-pool do Core quando há mais de um grupo grande o bastante para compensar o overhead | SimulIDE nunca paraleliza o solve; isso parece limitação de projeto solo, não escolha de escala — paralelizar **entre grupos** é seguro porque grupos não compartilham estado mutável por construção (não é o mesmo risco de paralelizar dentro de uma única matriz grande) |

Sem solver esparso desde o v1 — `Eigen::SparseLU` fica especificado como caminho de upgrade (mesma interface,
trocar a implementação por grupo quando o nó count justificar), não implementado às pressas antes de medir se
algum grupo real chega a ficar grande o suficiente para precisar. Gatilho concreto, não "algum dia": acima de
`kLargeGroupNodeThreshold` (200 nós num único grupo, ajustável por medição real) o Core registra um aviso —
isso dá um sinal mensurável de quando vale revisitar, em vez de decidir por intuição.

**Equilibração diagonal (Jacobi), adicionada 2026-06-29** — `CircuitGroup::factor()`/`solve()`: antes de
checar posto/`rcond()` e de fatorar, cada linha/coluna `i` é escalada por `1/sqrt(|A_ii|)` (variável extra
com diagonal 0 por construção MNA fica com escala 1, intocada). Achado real, não preventivo: um grupo
misturando condutância "ideal" Norton-pra-terra (`Ground`/`FixedVolt`/`Clock`/`VoltSource`/`WaveGen`, todas
`1e9`) com um componente de muitos pinos simultaneamente flutuantes (`McuComponent`, `1e-6` — ajustado pra
ficar seguro sozinho, nunca testado em conjunto) fazia `FullPivLU::rank()` cair bem abaixo de `cols()` —
nenhuma linha literalmente zerada, só o threshold do Eigen (`maxPivot·tamanho·epsilon`) sepultando as linhas
fracas por spread de magnitude, não por falta de conexão real. `CircuitGroup::singular()` rejeitava o grupo
inteiro (caso real: pull-up + botão de um GPIO do ESP32 ligado a GND/3V3, `subcircuits/
esp32_devkitc_v4.lssubcircuit`, EN/BOOT). Equilibração é transformação de similaridade (`x = S·y`, resolve-se
`S·A·S·y = S·b`) — preserva a solução exata a menos de erro de ponto flutuante, não muda comportamento de
grupo já bem-condicionado, e resolve a causa raiz pra qualquer combinação futura de magnitudes, não só este
caso (ver `.spec/lasecsimul-native-devices.spec` seção 8.1 para o relato completo do bug original).

### 7.2 Resolução de topologia — `Netlist` (pino → nó → grupo)

Validado contra um caso real do SimulIDE que expõe uma fonte de "conexão" diferente de fio:
**`Tunnel`** (`C:\SourceCode\simulide_2\src\components\connectors\tunnel.{h,cpp}`) une pinos por **nome
compartilhado**, não por desenho gráfico — `Tunnel::registerEnode()` propaga o mesmo `eNode` para
todo outro `Tunnel` com o mesmo nome via um registro estático (`m_tunnels`). A resolução abaixo
generaliza isso sem caso especial: união por nome é só outra fonte de aresta para a mesma primitiva
de união usada para fio.

**Duas passadas de `UnionFind` (`core/src/simulation/UnionFind.hpp`), sempre recalculadas do
zero quando a topologia muda — nunca incrementais.** Motivo de não serem incrementais: união não é
desfazível (renomear um túnel pode separar nós que estavam fundidos), e recalcular do zero é barato
porque topologia só muda em edição do usuário, nunca no caminho crítico de simulação — mesmo
princípio do `Simulator::createNodes()` do SimulIDE, que também deleta tudo e reconstrói.

1. **Passada 1 (pino → nó)**: cada pino de cada componente recebe um *slot* na criação
   (`Netlist::registerComponent`). Dois slots se unem por **fio** (`connectWire`) ou por
   **grupo de túnel** — todo slot com o mesmo nome de túnel é unido entre si
   (`setTunnelName`, ver abaixo). Resultado: `slot -> nó global` (id denso).
2. **Passada 2 (nó → grupo)**: cada componente une os nós dos seus **próprios** pinos entre si —
   é isso que faz um resistor de dois nós diferentes virar um `CircuitGroup` só (eles estão
   eletricamente diferentes, mas pertencem ao mesmo sistema linear a resolver). Resultado:
   `nó -> grupo` (id denso), que constrói os `CircuitGroup` (seção 7.1).

Diferente do SimulIDE: o registro de nomes de túnel vive no **`Netlist` de cada `SimulationSession`**,
nunca num `static QMap` de processo inteiro — dois projetos abertos nunca compartilham nomes de
túnel por acidente (isolamento que o SimulIDE, sendo single-document, não precisava resolver).

**Listener por nó**: junto com a passada 1, `Netlist` monta `listenersByNode[nó] -> [componentIndex]`
— quem tem um pino naquele nó. Depois de cada `MnaSolver::solve()`, `SimulationSession` compara a
tensão nova contra a anterior por nó; só os nós que **de fato mudaram** (epsilon, não bit-exato)
marcam seus listeners como dirty — isso é o que fecha o settle-loop da seção 7 sem reprocessar o
circuito inteiro a cada round.

**`ComponentMatrixView`** (`core/src/simulation/ComponentMatrixView.hpp`) é a implementação real de
`MnaMatrixView`: criada por componente por round de stamp, resolve `Pin.id -> índice local` dentro
do **único** `CircuitGroup` a que aquele componente pertence (garantido pela passada 2).

### 7.3 Fonte de tensão ideal — variável extra e referência de terra

`addVoltageSource` e `addConductanceToGround` (seção 6) já estão implementados — fecha a lacuna que
ficava aberta antes (resolvia rede resistiva, não circuito com fonte de ponta a ponta).

**Variável extra (corrente de ramo)**: dimensão da matriz de um `CircuitGroup` passa a ser
`nós + variáveis extras` — MNA não distingue tensão de nó de corrente de ramo, são só incógnitas
resolvidas juntas pelo mesmo `Eigen::PartialPivLU`. Alocação acontece **uma vez, no rebuild de
topologia** (`Netlist::rebuildTopology`, recebendo `extraVariableCount()` de cada componente),
nunca durante `stamp()` — alocar lá faria a matriz crescer a cada round do settle-loop.
`IComponentModel::extraVariableCount()` tem default 0; só fonte de tensão ideal (e futuramente
dependente/op-amp ideal) retorna > 0. Capacitor e indutor **não precisam disso**: usando modelo de
companhia Norton (condutância + fonte de corrente, não Thevenin) o estado deles entra só via
`rhs()`, igual a uma fonte de corrente — por isso `addCurrentSource`/equivalente em `RHS`-only é o
método que falta pra eles, não a máquina de variável extra.

**Terra (`Ground`, `core/src/components/other/Ground.hpp`)**: convenção deliberadamente simples —
puxa o pino pra 0V com admitância alta (`1e9` S) em vez de eliminar linha/coluna como MNA "de
livro" faria. Sem isso, **qualquer** grupo resolvido só com elementos passivos é singular por
construção (KCL somada em todos os nós sempre dá zero — é redundância estrutural, não bug) — não é
só o nó isolado que precisa de tratamento, é qualquer grupo sem referência. Erro residual ~1/1e9,
desprezível na prática, não bit-exato. Eliminação de linha/coluna "de livro" fica como refinamento
futuro, não bloqueando nada hoje.

Teste de integração (`core/test/voltage_divider_test.cpp`): fonte 10V + 2 resistores 1kΩ + terra,
roda `settleStep()` manualmente até estabilizar, confere `V_B = 5V` contra a conta analítica. Sem
framework de teste — só `assert`/código de saída, registrado via `add_test()` no CMake.

### 7.4 Correções de robustez no Scheduler + contrato de não-linear

Dois bugs reais (não hipotéticos) achados em auditoria do que já existia, corrigidos:

- **`SparseSet` não crescia.** Capacidade era fixa no construtor; inserir um índice acima dela era
  acesso fora dos limites sem checagem (UB, não exceção). `insert()` agora chama `grow()` sozinho
  quando precisa — nunca mais UB por excesso de capacidade.
- **`ScheduledEvent` sem desempate.** `std::priority_queue` não garante ordem estável entre
  elementos "iguais" pelo comparador; dois eventos no mesmo `timeNs` podiam processar em ordem
  não-determinística entre execuções. Adicionado `sequence` (ordem de `scheduleEvent()`) como
  critério secundário — necessário pra replay/teste reprodutível, não só estética.

**Contrato de componente não-linear** (`IComponentModel::isNonlinear()`/`hasConverged()`,
`device_abi.h`/ABI de plugin **não** tocado ainda — isto é só o lado C++ interno): depois de cada
solve(), todo componente que estampou no round e está marcado não-linear é consultado; se não
convergiu, volta pro dirty set pra outra iteração de linearização — mesmo que nenhum vizinho tenha
mudado tensão o bastante pra disparar isso via listener (seção 7, passo 3). Limite de iterações
(`kMaxNonlinearIterations = 50`, contador global por enquanto, mesmo papel do
`Simulator::m_maxNlstp` do SimulIDE) evita girar pra sempre se algo nunca convergir.

**O que isto define**: o Scheduler só fornece o laço de repetição e o limite — toda a matemática de
Newton-Raphson (linearização, tolerância de convergência) é responsabilidade de cada componente
concreto que implementa `stamp()`. `stamp()` lê o ponto de operação via `getNodeVoltage()` (mesmo
mecanismo de qualquer componente, sem API especial) e decide por conta própria, em
`hasConverged()`, se a estimativa estabilizou.

**Estado real (2026-07-08), primeiro componente não-linear implementado com Newton-Raphson
genuíno** (`core/src/components/active/Diode.hpp`, classe `Diode`): diodo Shockley
(`Id = Is*(exp(Vd/Vt)-1)`) com companion model (condutância + fonte de corrente equivalente)
linearizado no ponto de operação da última `stamp()`, amortecimento de Newton ("limiting" padrão de
SPICE — passo de `Vd` entre iterações limitado a `2*Vt` uma vez passado `vCrit`, evita que
`exp()` divirja antes do laço convergir) e `hasConverged()` genuíno (compara `Vd` entre iterações
consecutivas contra uma tolerância, não hardcoded). Parâmetro opcional `breakdownVoltage`
(0 = desativado) adiciona um segundo ramo exponencial espelhado pra ruptura reversa tipo zener,
com o mesmo amortecimento espelhado. A mesma classe é reaproveitada por três typeIds com parâmetros
diferentes:
- `active.diode`: `saturationCurrent` editável, sem ruptura (`supportsBreakdown=false`).
- `active.zener`: idem + `breakdownVoltage` editável (`supportsBreakdown=true`, default 5.1V).
- `outputs.led`: `saturationCurrent`/`thermalVoltage` fixados nos valores do preset real "RGY
  Default" do SimulIDE (`e-diode.cpp::getModels()`, `satCurr=0.0932nA`, `thermalVoltage` efetivo =
  `emCoef*Vt = 3.73*0.025865 ≈ 0.0965V`, sem `emCoef` como parâmetro separado — já embutido no
  `thermalVoltage` desta classe), sem ruptura. Testes: `core/test/diode_test.cpp` (diodo comum),
  `core/test/zener_led_test.cpp` (regulador zener + LED, ambos validando KCL no ponto convergido,
  não só que o laço parou de iterar).

**Achado documentado, não corrigido nesta tarefa**: `active.diac`/`active.scr`/`active.triac`/
`active.bjt`/`active.mosfet`/`active.jfet` têm registro built-in (`CoreApplication.cpp`) mas são
CONFIRMADAMENTE código morto em produção — `devices/simulide-complex` (plugin ABI) registra os
MESMOS typeIds via `SimulationSession::registerKnownPluginTypes()`, chamado depois de
`registerBuiltinComponents()`, e sempre vence via `ComponentRegistry::replaceFactory`. O modelo do
plugin (`lib.c`) é um limiar on/off simplificado, não Newton-Raphson real — portar Shockley/Ebers-Moll
pra estes exigiria mexer no `lib.c` do plugin (fora do escopo desta tarefa), não só no built-in
inerte.

### 7.5 Auditoria "pente fino" 2026-07-08 — componentes eletricamente inertes corrigidos

Auditoria completa pedida pelo usuário achou que 11 typeIds built-in usavam `SimulidePassiveState`
(`stamp()` no-op puro, `SimulideBuiltins.hpp:355`) apesar de terem física real e conhecida no
SimulIDE — ou seja, existiam no catálogo/UI mas eram eletricamente **inertes** (nenhuma corrente
fluía, nenhuma tensão real era produzida), o bug mais grave possível pra um simulador de circuitos.
Todos os 11 ganharam `stamp()` real:

- **`active.opamp`/`active.comparator`** — `components::OpAmp` (`core/src/components/active/
  OpAmp.hpp`), amplificador nullor simplificado: entrada de impedância infinita (nada estampado em
  in+/in-), saída Norton-pra-terra (`addConductanceToGround`/`addCurrentToGround`, mesma técnica de
  `Rail`) com valor alvo `clamp(gain*(V+-V-), ±1e6V)`. **Amortecimento por sub-relaxação obrigatório**
  (`alpha = 1/(1+gain)`) — sem isto, um opamp em realimentação negativa (a config mais comum:
  buffer/inversor/não-inversor) diverge geometricamente na iteração ingênua (`|derivada| = gain >>
  1`). Prova algébrica no comentário da classe: com essa escolha de `alpha`, um buffer de ganho
  unitário converge em UMA iteração, de qualquer ponto de partida. `active.comparator` reaproveita a
  MESMA classe com ganho default bem mais alto (1e7 vs 1e5), sem typeId nem classe separados.
  Pinos `powerPos`/`powerNeg` continuam sem física de trilho (simplificação documentada), mas
  precisam de uma condutância de fuga mínima até a terra (`kLeakageConductance=1e-9`) mesmo assim —
  ver achado de arquitetura abaixo.
- **`active.analog_mux`** — `components::AnalogMux` (`core/src/components/active/AnalogMux.hpp`):
  chaveamento resistivo real por canal (`kOnConductance=1000S` no canal endereçado + habilitado,
  `kOffConductance=1e-7S` nos demais, mesma ordem de grandeza do `low_imp` real do SimulIDE),
  endereço decodificado em binário dos pinos `addr-*`, `en` ativo em nível baixo (`voltage<2.5V`),
  mesma convenção do `mux_analog.cpp` real. Interpreta o MESMO `ComponentPinSpec`/
  `resolveDynamicPins` já usado pra contagem de pinos, agora também pra semântica elétrica.
- **`outputs.led_rgb`/`outputs.led_bar`/`outputs.led_matrix`/`outputs.seven_segment`** —
  `components::DiodeLegArray` (`core/src/components/active/DiodeLegArray.hpp`): N pernas de diodo
  independentes dentro de UM componente multi-pino (mesma física/amortecimento de `Diode`, sem
  ruptura reversa, duplicada em vez de reaproveitada pois `Diode` é hardcoded pra 2 pinos), preset
  "RGY Default" igual a `outputs.led`. `led_rgb`: 3 pernas (R/G/B) pro catodo comum. `led_bar`: pares
  P_i/N_i independentes (`size` pinos dinâmicos). `led_matrix`: `rows*columns` pernas (uma por
  interseção linha×coluna, linha=anodo/coluna=catodo, mesma convenção de `ledmatrix.cpp`).
  `seven_segment`: 8 pernas (a-g+ponto) para um pino comum por display, igual a
  `SevenSegment::createDisplay()` do SimulIDE. `shortedPairs` continua disponível como recurso
  genérico do modelo, mas não é usado para inventar um segundo comum no display padrão.
- **`outputs.dc_motor`/`outputs.incandescent_lamp`** — `components::Resistor` direto (2 pinos,
  reaproveitado sem mudança). **`outputs.stepper`** — `components::StepperWindings` (quatro
  meias-bobinas resistivas ligadas ao terminal comum `Co`, preservando os cinco pinos do Stepper
  unipolar real). Nenhum modela torque/rotação/back-EMF/resistência variável com
  temperatura (simplificação documentada) — só a carga resistiva real, elétrica de verdade em vez de
  circuito aberto.
- **`switches.keypad`** — `components::Keypad` (`core/src/components/switches/Keypad.hpp`): matriz
  linha×coluna real (`kClosedConductance`/`kOpenConductance` sem diodo; física de `Diode` em série
  quando `diodes=true`, direção controlada por `diodesDirection`, mesma topologia do `keypad.cpp`
  real). Nova propriedade `pressedMask` (bitmask, bit `row*columns+col`) representa o estado de
  tecla pressionada — substitui o clique interativo do mouse por tecla que o SimulIDE real tem
  (UI/IPC novos, fora de escopo aqui); a matriz elétrica em si é real, só a FONTE do estado é uma
  propriedade em vez de um evento de clique.

**`passive.resistor_dip`** (achado relacionado, mesma classe de bug): registrava só os 2 primeiros
dos 16 pinos declarados no `package` (via `SimulideTwoPinResistor`), os outros 14 ficavam
eletricamente flutuando — não uma simplificação, uma topologia ERRADA (o símbolo desenhava 8
resistores independentes, só 1 existia de verdade). Corrigido com `components::ResistorArray`
(`core/src/components/passive/ResistorArray.hpp`): 8 pares reais, MESMA resistência compartilhada
entre todos (igual ao `resistordip.cpp` real). Redimensionamento dinâmico e modo "Pullup" (barramento
com pino direito oculto) do original NÃO implementados — o catálogo atual já declara os 16 pinos como
fixos, sem `dynamicLayout`, então essa parte do gap nem existia.

**Achado de arquitetura descoberto durante os testes** (não é um bug do `Netlist`, é uma
característica existente que qualquer componente multi-pino novo precisa respeitar):
`Netlist::rebuildTopology` funde TODOS os pinos do MESMO componente no MESMO grupo topológico,
sempre — "Passada 2: nó -> grupo (mesmo componente => mesmo grupo)" (`Netlist.hpp`). Pra um
componente com sub-redes eletricamente INDEPENDENTES entre si (pares de `ResistorArray`, pernas de
`DiodeLegArray` sem hub comum, pinos só-lidos-nunca-estampados como `en`/`addr-*` do `AnalogMux` ou
`powerPos`/`powerNeg` do `OpAmp`), se o usuário só fiar PARTE dessas sub-redes (uso normal — ninguém
fia os 16 pinos de um DIP sempre), as sub-redes não-fiadas ficam sem NENHUMA equação dentro do MESMO
grupo das sub-redes que ESTÃO fiadas — isso torna o grupo INTEIRO singular, e o fallback do
`MnaSolver` zera TODAS as tensões do grupo, inclusive as sub-redes que tinham referência real.

**LeakageGuard centralizado (2026-07-09, substitui o padrão manual descrito acima)**: em vez de cada
componente chamar `matrix.addConductanceToGround(pin, kLeakageConductance)` dentro do próprio
`stamp()` (como `OpAmp`/`AnalogMux`/`ResistorArray`/`DiodeLegArray` faziam até esta correção),
`IComponentModel::leakagePinIndices()` (novo método virtual, default vazio) declara quais índices
locais de `pins()` precisam da rede de segurança; `SimulationSession::settleStep()` aplica
`kLeakageGuardConductance=1e-9` (`IComponentModel.hpp`) a eles logo depois de `stamp()` retornar,
sempre, sem o componente precisar lembrar disso no meio da própria física. Deliberadamente OPT-IN
(não detecção automática de "diagonal zero após stamp", que mascararia erro de fiação real do
usuário em qualquer componente, não só nos que precisam): um pino sem estampa que o componente não
declarou continua produzindo "sistema singular" de verdade. Qualquer novo componente multi-pino com
sub-redes independentes deve sobrescrever `leakagePinIndices()`, não reimplementar o padrão manual.

**Sensores resistivos falsos removidos** (achado de duplicação, não de física ausente):
`passive.ldr`/`passive.thermistor`/`passive.rtd`/`passive.force_strain_gauge` eram resistores
estáticos disfarçados (`SimulideTwoPinResistor`, ZERO resposta a luz/temperatura/força — eletricamente
indistinguíveis de um `passive.resistor` comum), catalogados em "Passivos > Resistive Sensors",
DUPLICANDO os sensores REAIS (`sensors.ldr`/`thermistor`/`rtd`/`strain`, física de verdade —
`devices/simulide-sensors/src/lib.c`, curva gamma real pro LDR — catalogados em "Sensores"). Um
usuário pegando "LDR" pela pasta óbvia ("Passivos") ganhava o componente ERRADO. Removidos os 4
builtins falsos e suas entradas de catálogo — `sensors.*` é agora a única fonte pra sensores
resistivos.

**NAND/NOR/NOT/XNOR** (achado de paridade SimulIDE, não elétrico): `devices/simulide-logic/src/
lib.c` só tinha AND/OR/XOR/Buffer fixos em 2 entradas, sem flag de inversão — tornando NAND/NOR/
NOT/XNOR inconstruíveis, apesar de serem portas mais fundamentais em projeto digital real que XOR.
Mesma solução do SimulIDE real (`gate.cpp`: propriedade booleana "Inverted Outs" na MESMA porta
AND/OR/XOR/Buffer, não um typeId separado por porta): `stamp_gate()` agora lê `cfg_bool(s,
"inverted", 0)` e inverte a saída antes de estampar; os 4 `.lsdevice` (`and_gate`/`or_gate`/
`xor_gate`/`buffer`) ganharam a propriedade `inverted` (checkbox). `logic.buffer` com
`inverted=true` É o NOT. Testado via DLL real (`core/test/logic_gate_plugin_test.cpp`, mesmo padrão
`esp32_devkitc_subcircuit_test.cpp`). **Atualização 2026-07-09**: a paridade visual foi implementada
— os 4 `.lsdevice` ganharam um `partId: "invertBubble"` no `package.viewSpec.paint` com
`stateProjection: {invertBubble: [{kind:"visible", prop:"inverted"}]}` (mecanismo `ViewSpecProjection`
já existente, reaproveitado), então o símbolo agora mostra a bolha quando `inverted=true` (ver
`docs/24-itens-menor-prioridade-2026-07-09.md`). **Atualização final 2026-07-09**: a contagem de
entradas variável também foi implementada para AND/OR, sem helper interno por `typeId`: o manifesto
declara `inputs`, `pinSpec.dynamicGroups`, `package.dynamicLayout` e `viewSpec.paint[].statePath`;
`stamp_gate()` lê N entradas reais no DLL. XOR/Buffer seguem fixos porque a referência SimulIDE 2 não
expõe `Num_Inputs` nesses dois.

**Verificação editorial (documentação estava desatualizada, achado à parte)**: `.spec/lasecsimul.spec`
seção 6.1.2 (validação de propriedade + `affectsTopology`/`requiresRestart`), `README.md`, `docs/
mvp-limitacoes.md` (subcircuitos, Newton-Raphson) e `docs/16-roadmap-pendencias-spec.md` (undo/redo/
copiar-colar/flip) descreviam funcionalidades JÁ implementadas em rodadas anteriores como pendentes
ou inexistentes — mesma classe de drift já corrigida uma vez pro diodo (ver nota em 7.4). Todos
corrigidos nesta auditoria.

## 8. Fluxo de integração com QEMU

> Mecanismo validado pelo próprio `simulide_2` (não é suposição de design) — ver
> `C:\SourceCode\simulide_2\src\microsim\cores\qemu\{qemudevice,qemumodule}.{h,cpp}` e, por chip,
> `C:\SourceCode\simulide_2\src\microsim\cores\qemu\esp32\esp32{,iomux,twi,spi,usart}.{h,cpp}`. O LasecSimul
> Core porta essa mesma arquitetura para o processo nativo descrito neste `.spec`, sem Qt (RNF05) e sem QMP —
> o controle do processo é mais simples do que QMP sugere. **Achado crítico confirmado lendo
> `hw/gpio/esp32_gpio.c` do fork real (`C:\SourceCode\qemu_simulide`)**: o QEMU manda registrador bruto
> (endereço + valor) sem decodificar nada — quem decodifica é o módulo do lado do Core, e esse módulo É
> chip-específico de propósito (só `Scheduler`/`Netlist`/IPC/UI precisam ser neutros quanto a chip). Não
> existe mais "módulo de barramento genérico reusado por qualquer chip" — ver seção 8.1.

1. Usuário insere um componente MCU no esquemático e associa uma **pasta** (não um arquivo fixo) onde o
   firmware (`.bin`/`.elf`/`.hex`) é gerado pela toolchain externa do usuário (Arduino IDE/PlatformIO/ESP-IDF
   — o LasecSimul nunca compila nada, ver seção 13) — caminho da pasta enviado pela Extension ao Core via
   IPC. `FirmwareWatcher` (seção 8.3) passa a vigiar essa pasta a partir daqui, sem ação manual nenhuma.
2. `McuRegistry` resolve `chipId` → instancia o `IMcuAdapter`, sempre via plugin nativo
   (`mcu_abi.h`/`NativeMcuAdapterProxy`) — **não existe caminho built-in para adaptador de MCU**, decisão
   tomada em 2026-06-28 ao migrar o ESP32 (ver seção 8.1).
3. **QEMU usado é um build modificado por chip** (espelhando o fork da Espressif para ESP32, ou um patch
   equivalente para STM32/outros) — os modelos de periférico (I2C/SPI/USART/Timer/GPIO) desse chip, dentro do
   QEMU, não emulam o hardware sozinhos: a cada acesso da CPU emulada a um registrador desses periféricos,
   eles escrevem o evento (endereço, valor, tipo de ação) numa **arena de memória compartilhada** e
   sinalizam o host — em vez de manter o protocolo inteiro só dentro da QEMU. Isso é uma dependência externa
   por chip (qual build de QEMU expõe essa arena), documentada no manifesto do adaptador, não algo o Core
   implementa.
4. `QemuProcessManager` cria a memória compartilhada (`CreateFileMapping`/`mmap`, chave única por instância —
   mesmo padrão de `shm_open`+`mmap`/`CreateFileMapping`+`MapViewOfFile` do SimulIDE) **antes** de iniciar o
   processo QEMU (`-machine <chip>`, `-kernel/-drive <firmware>` etc., via `buildLaunchArgs()`), e espera a
   arena reportar `running` para confirmar que o processo subiu.
5. Sincronização é por **espera ativa num campo da arena** (`simuTime`), não por socket/QMP — o `Scheduler`
   despacha a thread dedicada à instância de MCU para essa espera; o custo de uma syscall por evento é
   trocado por uma thread ocupando um núcleo enquanto o firmware roda. Isso é deliberado (mesma troca já
   validada pelo SimulIDE) e está coberto pelo orçamento de threads do Core (`std::thread`/pool).
6. Cada evento da arena traz `regAddr`/`regData`; `McuComponent` (`core/src/mcu/McuComponent.{hpp,cpp}`) —
   a peça que liga o `IMcuAdapter` ao circuito de verdade — despacha pro `QemuModule` concreto (`SIM_READ`/
   `SIM_WRITE`, por faixa de endereço, `IMcuAdapter::createModules()`) que é dono daquele endereço. O
   `QemuModule` decodifica o registrador (ex: `Esp32GpioModule` sabe que offset `0x04` é `GPIO_OUT_REG`) —
   o `McuComponent`/`Scheduler`/`Netlist` nunca sabem que registrador é esse.
7. A cada `stamp()`, `McuComponent` traduz `isOutputEnabled`/`outputLevel` do módulo em estampa elétrica real
   (Norton de baixa impedância) nos `Pin`s de circuito reais (`IMcuAdapter::pinMap()`), ou lê a tensão do nó
   de volta pro módulo (`setInputLevel`). Protocolo (I2C/SPI/UART) não é decodificado por um "módulo de
   barramento" intermediário — é decodificado bit a bit pelo componente/device do outro lado do fio via
   `ComponentEvent{kPinChangeEventTag}` (mesmo mecanismo de qualquer detecção de borda no `Netlist`, seção
   0.4 do handoff `docs/17-pendencias-pos-sessao-qemu-abi.md`). Um dispositivo nativo do outro lado nunca
   sabe se quem está do outro lado do fio é um MCU emulado ou outro componente.
8. UART/SPI/I2C reais do ESP32 (`Esp32TwiModule`/`Esp32SpiModule`/`Esp32UsartModule`) ainda não existem —
   só GPIO puro (`Esp32GpioModule`) está implementado hoje (ver pendência 3.1 do handoff). Quando existirem,
   seguem o mesmo padrão do item 6/7: `QemuModule` concreto por periférico, nunca módulo genérico.
9. Depuração: `gdbserver` da QEMU exposto em porta TCP; Debug Adapter do VSCode conecta diretamente nele
   (não passa pelo Core).
10. **Reset e parada não usam QMP**: o pino de reset do componente, ao ser ativado, zera `arena->running` e
    **mata o processo QEMU** (kill direto, sem handshake); ao ser liberado, um novo processo QEMU é
    iniciado do zero (boot é rápido o suficiente para isso ser aceitável — mesma escolha do SimulIDE). Parar
    a simulação segue a mesma rota: kill + timeout, nunca um comando de protocolo esperando resposta. Isso
    elimina a necessidade de um `QmpClient`/protocolo QMP no Core.

### 8.1 `qemu_arena_abi.h` — reescrito nesta sessão (2026-06-28), confirmado contra o binário real

`core/include/lasecsimul/qemu_arena_abi.h` foi **reescrito por completo** depois de auditar o protocolo real
contra três fontes confirmadas acessíveis nesta máquina: `C:\SourceCode\qemu_simulide`
(`softmmu/simuliface.{h,c}`, fork QEMU atual), `C:\SourceCode\simulide_2` (fonte C++ do SimulIDE atual — o
antigo `SimulIDE-dev` não existe mais neste disco) e o binário oficial vendorizado de
`SimulIDE_2-R260501_Win64\data\bin\qemu-system-xtensa.exe`. O protocolo anterior descrito aqui (tag
`simuAction` com payload já decodificado, sem endereço) **estava errado** — substituído pelo protocolo real:
`regAddr`/`regData`/`irqNumber`/`irqLevel`/`SIM_READ`/`SIM_WRITE`/`loop_timeout_ns`/`ps_per_inst`, **88 bytes
total** (confirmado batendo com o log do próprio binário real: "Qemu: arena mapped 88 bytes"). Duas decisões
de versionamento/sincronização seguem valendo, e ambas são correções confirmadas, não polimento:

- **Sem cabeçalho de versão dentro da struct.** O binário já compilado (`qemu-system-xtensa.exe`) e os
  patches já existentes (`hw/gpio/esp32_gpio.c`, `hw/arm/stm32.c`) dependem do layout exato, campo a campo,
  na ordem atual — inserir `abiMajor`/`abiMinor` na frente deslocaria tudo e exigiria recompilar o QEMU.
  Versionamento fica fora da struct: o manifesto do adaptador (`.lsdevice`, campo `qemuBuild`) é quem declara
  qual build de QEMU é esperado pra aquele chip. Isso é uma troca deliberada — usar o binário que já existe
  sem precisar mantê-lo (recompilar QEMU é um projeto de build próprio) — não um esquecimento.
- **Protocolo é ping-pong síncrono por construção, não seqlock.** O protocolo real (`doAction()` em
  `simuliface.c`) bloqueia em espera ativa em ambos os sentidos — QEMU escreve o evento e espera o Core
  confirmar antes de seguir; não executa a próxima instrução emulada enquanto isso não acontece. Isso garante
  zero perda de evento sem precisar de sequence number: o produtor não consegue avançar antes da confirmação,
  por construção. Para semântica de acesso a registrador de hardware (a CPU pode ler de volta o que escreveu
  na instrução seguinte) isso é o modelo correto, não só mais simples.

Campos reais do contrato (88 bytes), QEMU **nunca pré-decodifica**:

1. **QEMU → Core** (evento de periférico): escreve `regAddr` (endereço bruto do registrador acessado pela
   CPU emulada, sem decodificação — quem decodifica "offset 0x04 = GPIO_OUT_REG" é o `QemuModule` do lado do
   Core, nunca o QEMU) + `regData` + `SIM_READ`/`SIM_WRITE` (qual operação foi feita). Despacho por endereço
   dentro do QEMU usa `MemoryRegionOps` nativo só para decidir que aquele endereço pertence à arena — não
   decodifica o significado do registrador.
2. **IRQ**: `irqNumber`/`irqLevel` — sinalização de interrupção, independente do par `regAddr`/`regData`.
3. **Timing**: `loop_timeout_ns`/`ps_per_inst` — orçamento de tempo virtual por rodada de espera ativa e
   picosegundos por instrução emulada (usado pelo Core para converter tempo de CPU emulada em `timeNs` real
   do `Scheduler`).

Não existe mais um enum de ação chip-específico trocado pela arena (`simuAction`/`qemuAction` da versão
anterior desta seção) — o endereço bruto já basta, e quem dá significado a ele é o `QemuModule` concreto,
sempre vindo de um plugin (`mcu_abi.h`/`LsdnQemuModuleVTable`, via `QemuModuleProxy`) desde 2026-06-28 — ver
GPIO do ESP32 (`mcu-adapters/espressif-esp32/`) hoje; `IMcuAdapter::createModules()` decide quais módulos um
chip usa.

**Por que isso não vira o mesmo padrão na ABI de plugin nativo (`device_abi.h`)**: ping-pong por memória
compartilhada existe pra evitar o custo de uma syscall **entre processos diferentes**. Plugin roda no mesmo
processo do Core — `vtable->stamp()` já é uma chamada de função direta, mais barata que qualquer protocolo
de espera ativa em memória compartilhada, porque não há fronteira de processo a economizar ali. E o problema
que o ping-pong resolve (perda de evento por sobrescrita) **não existe** na ABI de plugin por construção: lá
cada evento é uma chamada de função com parâmetro próprio (`on_event(dev, &ev)`), nunca um campo único
reaproveitado — não tem nada a corrigir. Avaliado e descartado deliberadamente, não esquecido.

**Estado atual (não mais "formato sem pipeline")**: o pipeline mínimo já funciona de ponta a ponta —
`McuController`/`buildLaunchArgs` (no adaptador ESP32, hoje um plugin, `mcu-adapters/espressif-esp32/`)
prependam a chave da shared memory como `argv[1]`
(confirmado lendo `simuMain()` real em `simuliface.c`: `shMemKey = argv[1]; argv = &argv[2];`), e o resto dos
args bate com `Esp32::createArgs()` real: `-M esp32-simul -L <romdir> -drive file=...,if=mtd,format=raw
-icount shift=4,align=off,sleep=off` — não mais o placeholder antigo `-machine esp32 -kernel ...`. O binário
real
(`devices/qemu-esp32/bin/qemu-system-xtensa.exe` + DLLs + ROMs do ESP32, vendorizado nesta sessão a partir de
`SimulIDE_2-R260501_Win64\data\bin\`) é de fato lançado pelo teste
`core/test/core/mcu/McuControllerRealQemuTest.cpp` (`mcu_controller_real_qemu` no ctest) — abre a arena,
inicia o processo, só falha no firmware porque ainda não existe um `.bin` real (falta toolchain ESP-IDF, ver
`docs/mvp-limitacoes.md`). `McuComponent` (`core/src/mcu/McuComponent.{hpp,cpp}`) já liga isso a um circuito
de verdade, sem precisar do processo QEMU real — `core/test/core/mcu/McuComponentTest.cpp` prova
`GPIO_ENABLE_REG`+`GPIO_OUT_REG` subindo um pino do circuito pra 3.3V com arena sintética.

### 8.2 Estado real do fork QEMU — verificado, não suposto

Dependência concreta, não hipotética: `G:\...\qemu-simulide` (binário compilado, `qemu-system-xtensa.exe` +
DLLs MSYS2, confirmado executável) e `G:\...\qemu-simulide-1` (fonte completo, git em
`LASEC-UFU/qemu-simulide`, upstream `Arcachofo/qemu-simulide`, base QEMU 9.2.2). Histórico git local
corrompido (objects incompletos, provavelmente sync do Google Drive) — arquivos atuais intactos, só o
`git log` não funciona; não tentar `fsck`/reclone sem necessidade real.

A ponte com a arena (`system/simuliface.{h,c}`) já está formalizada na seção 8.1 (struct exata + protocolo
ping-pong). Detalhe operacional que vale registrar aqui: `argv[1]` do processo QEMU é sempre a chave da
memória compartilhada — convenção fixa de posição, não uma flag — e o resto de `argv` segue direto pro
`qemu_init()` normal do QEMU (machine/kernel/etc., sem nada de SimulIDE no meio).

Estado por família de MCU, verificado lendo o fork (não suposto):

| Família | CPU no QEMU | Bridge com a arena hoje |
|---|---|---|
| ESP32 (Xtensa) | Pronta (`target/xtensa`, fork Espressif) | GPIO output (chip→Core) e GPIO input por poll (`hw/gpio/esp32_gpio.c`) ok; UART/SPI/I2C **zero** |
| STM32 (ARM) | Pronta (`target/arm`, upstream maduro) | GPIO input **push** (Core→chip) e UART RX push ok (`hw/arm/stm32.c`) — mais adiantado que o ESP32 nisso |
| Arduino Uno/Mega (AVR) | Pronta (`target/avr`, `hw/avr/arduino.c`, upstream) | Zero — nenhuma referência à arena ainda; mesmo padrão de patch do GPIO do ESP32 se aplicaria |
| PIC | **Não existe** — nenhum target de CPU PIC no QEMU, neste fork ou em qualquer outro conhecido | Fora de escopo (ver RF/decisão abaixo) |

**PIC fica fora do escopo do LasecSimul** até (e a menos que) exista um target de CPU PIC no QEMU — decisão
explícita, não esquecimento: escrever um target de CPU do zero é projeto separado, de meses, de escala
maior que o resto do LasecSimul somado. Não é uma lacuna a fechar nesta fase; é uma dependência externa que
simplesmente não existe ainda.

### 8.3 `FirmwareWatcher` — recarga automática, sem ação manual (diferença deliberada do SimulIDE)

Confirmado lendo o SimulIDE-dev de verdade (não suposição): `QemuDevice` só tem `slotLoad()`/`slotReload()`
acionados por item de menu de contexto ("Load firmware"/"Reload firmware") — **nenhum** `QFileSystemWatcher`
existe em lugar nenhum do projeto (busca confirmada, zero ocorrências). Recompilar o firmware fora do
SimulIDE nunca atualiza a simulação até o usuário clicar manualmente. O LasecSimul resolve isso:

1. **Configuração é uma pasta, não um arquivo fixo.** Toolchains externas (Arduino IDE, PlatformIO,
   ESP-IDF) escrevem o artefato compilado num caminho de build muitas vezes gerado/variável — o usuário
   aponta a PASTA de saída, não um nome de arquivo específico. `FirmwareWatcher` resolve, dentro dela, o
   `.bin`/`.elf`/`.hex` de maior `mtime` (se houver mais de um, vence o mais recente — caso comum de pastas
   de build com artefatos antigos não limpos).
2. **Detecção por polling do `mtime`, não API nativa de evento de filesystem por SO.** Decisão deliberada de
   simplicidade: `inotify`/`ReadDirectoryChangesW`/`FSEvents` são três implementações por SO pra economizar
   uma latência que não importa aqui (o usuário acabou de compilar manualmente fora do LasecSimul; esperar
   1-2s pra simulação notar é imperceptível nesse fluxo). `FirmwareWatcher::poll()` roda no mesmo timer que
   já dispara `qemuTime` (seção 8, item 5) — sem thread nem timer dedicado novo.
3. **Reaproveita o mecanismo de kill+respawn já especificado (seção 8, item 10), não um caminho novo.** Mudança
   detectada = exatamente o mesmo efeito de pino de reset sendo ativado: mata o processo QEMU atual, sobe um
   novo com `-kernel/-drive` apontando pro arquivo novo. **Recarregar firmware nunca foi um caso especial —
   é "reset" com um gatilho diferente** (arquivo mudou, em vez de pino mudou). Nenhuma lógica de "hot-swap de
   firmware num processo QEMU vivo" é necessária nem cogitada.
4. **Sem debounce explícito além do próprio polling.** Uma toolchain grava o artefato final de uma vez
   (rename atômico ou escrita seguida de close) — o intervalo de poll já absorve qualquer escrita parcial
   sem necessidade de detectar "arquivo parou de crescer".

```
core/src/mcu/qemu/FirmwareWatcher.{hpp,cpp}   // poll(folder) -> optional<caminho mais recente>
```

**Status real (corrigido 2026-07-09, ver seção 19)**: implementado e testado
(`core/test/core/mcu/FirmwareWatcherTest.cpp`), mas **nunca foi ligado** a `QemuProcessManager`/
`McuComponent` nem a nenhum outro chamador -- `poll()` nunca roda em produção. A UI seguiu exigindo
clique manual em "Recarregar Firmware" até 2026-07-09, quando a recarga automática foi implementada
de outra forma (Extension, arquivo único verificado só antes de "Run" -- não pasta, não polling
contínuo). Este design (itens 1-4 acima) permanece só como REFERÊNCIA/intenção original, não descreve
o comportamento atual -- ver seção 19 pro que de fato roda hoje.

## 9. Estratégia para adicionar novos componentes eletrônicos

Três caminhos, sem nunca editar `MnaSolver`/`Scheduler`:

- **Biblioteca padrão** (mantida pelo projeto): nova classe C++ em `core/src/components/<categoria>/`,
  compilada direto no binário do Core, implementa `IComponentModel`. Caminho mais rápido possível (mesma
  unidade de compilação), reservado para componentes de primeira parte.
- **Plugin de terceiros** (usuário/comunidade, código): DLL/SO carregada em runtime pelo `PluginLoader`
  (descoberta + ABI) para o `GlobalPluginCache`; instâncias são criadas pelo `PluginRuntime` de cada sessão,
  exportando a vtable C de `device_abi.h`, que o Core envolve num `NativeDeviceProxy` (`IComponentModel`).
  Especificação completa — manifesto, ABI, ciclo de vida, build, testes — em **`lasecsimul-native-devices.spec`**.
- **Subcircuito** (usuário, sem código): circuito desenhado no editor, salvo como `.lssubcircuit` — pinos internos
  expostos via `Tunnel` com nome reaproveitando o mesmo mecanismo da seção 7.2, símbolo visual reaproveitando
  o mesmo bloco `package` de `.lsdevice` (seção 21 do `lasecsimul-native-devices.spec`). **Não implementa
  `IComponentModel`** — ao instanciar, o Core expande os componentes internos diretamente na mesma
  `SimulationSession` (sem flattening prévio pela Extension, sem sandbox/consentimento porque é dado, não
  código executável). Especificação completa em **`lasecsimul-subcircuits.spec`**.

O `ComponentRegistry` registra os dois primeiros caminhos da mesma forma; o solver não diferencia built-in de
plugin. Subcircuito é deliberadamente diferente — não é uma terceira variante de `IComponentModel`, é uma
composição de instâncias já existentes (ver `lasecsimul-subcircuits.spec`, seção 5).

Critério de quando usar qual: biblioteca padrão para tudo que o projeto distribui e mantém; plugin pra
comportamento novo que só código resolve (lógica, protocolo, estado complexo); subcircuito pra reaproveitar
uma combinação de componentes já existentes sem escrever nada — não existe um quarto caminho "mais lento, mas
mais seguro" neste momento — essa troca foi avaliada e descartada deliberadamente (ver nota de isolamento na
seção 12 do `lasecsimul-native-devices.spec`).

## 10. Estratégia para adicionar novos microcontroladores

Mesmo princípio, espelhando o ESP32 — mas **o protocolo de registrador (GPIO/I2C/SPI/USART) é CHIP-ESPECÍFICO
de propósito, não genérico** (achado crítico confirmado lendo `hw/gpio/esp32_gpio.c` do fork real, seção 8):

1. Implementar `IMcuAdapter` como plugin nativo (`mcu-adapters/<chip>/`, `mcu_abi.h`/`LsdnMcuVTable`,
   carregado via `NativeMcuAdapterProxy`) — não existe mais caminho built-in (removido ao migrar o ESP32 em
   2026-06-28, mesmo desempenho dos dois): (a) `build_launch_args` para o binário QEMU daquele chip, (b)
   `get_memory_regions`/`get_pin_map` declarativos, (c) `create_modules` — devolve um
   `LsdnQemuModuleHandle` (`mcu_abi.h`) concreto por periférico que o chip de fato usa (ex: GPIO do ESP32);
   `QemuModuleProxy` (`core/src/plugins/QemuModuleProxy.hpp`) embrulha isso num `QemuModule` C++ do lado do
   Core, mesmo custo de chamada que um `QemuModule` built-in teria.
2. Implementar um módulo (`LsdnQemuModuleVTable`) por periférico, do lado do plugin — **é aqui que vive o
   conhecimento do mapa de registrador real daquele chip** (ex: offset `0x04` = `GPIO_OUT_REG` no ESP32);
   copiar fielmente do código de referência real
   (`C:\SourceCode\simulide_2\src\microsim\cores\qemu\<chip>\`), nunca inventar offset. Não existe módulo
   genérico reusado entre chips — cada `QemuModule` concreto é específico de um periférico de um chip.
3. Pré-requisito por chip: precisa existir um build de QEMU modificado para esse chip que escreva os eventos
   de registrador na arena de memória compartilhada (seção 8.1) — documentar isso como dependência externa no
   manifesto do adaptador (campo `qemuBuild`), não como limitação do Core.
4. `McuComponent`/`McuRegistry`/`Scheduler`/`Netlist`/IPC/UI são neutros por design — não conhecem "ESP32" nem
   "STM32", só `IMcuAdapter`/`QemuModule`/`MemoryRegion`/`PinMapping`. Protocolo de barramento real (I2C/SPI)
   entre o MCU e outro componente do circuito é decodificado bit a bit pelo componente do outro lado do fio
   via `ComponentEvent{kPinChangeEventTag}` (seção 7, passo "3e"), nunca por um módulo de barramento.

## 11. SOLID aplicado

| Princípio | Aplicação concreta |
|---|---|
| **S**RP | `MnaSolver` resolve circuito; `QemuProcessManager` gerencia processo QEMU; `McuComponent` só despacha registrador da arena pro `QemuModule` certo e traduz pra estampa elétrica; cada `QemuModule` só decodifica o registrador de um periférico; `IpcServer` só serializa/desserializa; `PluginLoader` só descobre/valida/carrega código, `PluginRuntime` só cria/destrói instâncias — nenhuma classe acumula mais de uma responsabilidade. **Esclarecimento (2026-06-30)**: SRP aqui é "uma responsabilidade", não "uma classe por arquivo" — agrupar múltiplos devices RELACIONADOS num mesmo módulo (`SimulideBuiltins.hpp` com 8+ classes; `simulide-complex`/`simulide-logic`, 18+25 tipos cada num único `lib.c`) é permitido e intencional, tanto built-in quanto plugin ABI/DLL. O que de fato violaria SRP/DIP: lógica específica de UM typeId vazando pra fora do código daquele device E/OU duplicada em vários lugares (ex: a mesma classificação por typeId repetida em 4 funções da Extension) — ver `.spec/lasecsimul-native-devices.spec` seção 22.8 pro critério completo e o exemplo formal (`ReadoutFormat`/`InteractionKind`, seção 22) de centralizar em vez de duplicar. |
| **O**CP | Novo componente/MCU = nova classe compilada no Core **ou** novo plugin DLL/SO — nunca uma edição em `MnaSolver`/`Scheduler`. Novo periférico de chip = novo `QemuModule` concreto, nunca edição em `McuComponent`/`Scheduler`/`Netlist` (item 10.2). |
| **L**SP | Qualquer `IComponentModel` (built-in, `NativeDeviceProxy` envolvendo um plugin, ou `McuComponent`) é intercambiável no `stamp()` do solver sem checagem de tipo concreto. Idem para `IMcuAdapter`/`QemuModule` no `McuComponent`. |
| **I**SP | `IComponentModel` e `IMcuAdapter` são interfaces separadas — um MCU adapter não implementa métodos de pino de componente passivo. `ComponentMetadataRegistry` separado de `ComponentRegistry` — consultar o catálogo para UI não exige uma factory instanciável. |
| **D**IP | `simulation/` depende só de `include/lasecsimul/*.hpp`. `components/`, `plugins/`, `mcu/` dependem do Core, nunca o contrário. `GlobalPluginCache` + `ComponentRegistry`/`McuRegistry` por sessão são o único ponto de inversão de controle. |

## 12. Exemplos práticos

### 12.1 Resistor nativo (biblioteca padrão, compilado no Core)

`core/src/components/passive/Resistor.hpp`
```cpp
class Resistor final : public IComponentModel {
public:
    Resistor(std::array<Pin,2> pins, double resistanceOhm) : m_pins(pins), m_r(resistanceOhm) {}

    const char* typeId() const override { return "passive.resistor"; }
    std::span<Pin> pins() override { return m_pins; }

    void stamp(MnaMatrixView& matrix) override {
        const double g = 1.0 / m_r;
        matrix.addConductance(m_pins[0], m_pins[1], g); // idêntico em custo ao eResistor::stampAdmit()
    }
    void postStep(uint64_t) override { /* resistor é puramente algébrico — nunca é chamado */ }
    size_t getState(uint8_t*, size_t) const override { return 0; }
    void setState(const uint8_t*, size_t) override {}

private:
    std::array<Pin,2> m_pins;
    double m_r;
};
```

### 12.2 Registro (Core, `main.cpp`)

```cpp
GlobalPluginCache pluginCache;             // processo-wide — carrega código, nunca instâncias
pluginCache.loader().scanDirectory("./devices");
pluginCache.loader().scanDirectory("./mcu-adapters");

SimulationSession session(pluginCache);    // hoje sempre 1 por processo
session.components().registerFactory("passive.resistor", [](const ComponentParams& p) {
    return std::make_unique<Resistor>(p.pins<2>(), p.property("resistance", 1000.0));
});
session.registerKnownPluginTypes();        // delega ao PluginRuntime para cada typeId/chipId do cache
```

### 12.3 Protocolo de IPC (visão da Extension)

```typescript
// extension/src/ipc/CoreClient.ts (esqueleto conceitual)
export class CoreClient {
  async addComponent(typeId: string, properties: Record<string, unknown>): Promise<string /* instanceId */> { /* envia pelo named pipe */ return ""; }
  async setProperty(instanceId: string, name: string, value: unknown): Promise<void> {}
  onTelemetry(cb: (sample: TelemetrySample) => void): void { /* assina o ring buffer */ }
}
```

Esse mesmo `CoreClient` é o único ponto onde a Extension "sabe" que existe um processo nativo — todo o resto
da UI fala com `CoreClient`, nunca com sockets/buffers diretamente (SRP também no lado TypeScript).

## 13. UI da Extension — baseada no SimulIDE, exceto edição/compilação de código

Princípio: a organização de painéis/fluxo de trabalho segue o SimulIDE real (`C:\SourceCode\simulide_2\src\gui\`,
`mainwindow.{h,cpp}`), lido agora, não suposto — **com exceção de qualquer área de digitar/compilar
firmware**, que não existe no LasecSimul (compilação é sempre externa; o Core só lê o artefato já
compilado, seção 8.3). Onde o equivalente nativo do VSCode já cobre algo que o SimulIDE precisou construir
do zero (Qt não tem), o nativo do VSCode vence — "baseado no SimulIDE" não é cópia pixel a pixel.

`MainWindow` real é `QSplitter` com `CircuitWidget` (canvas) + `QTabWidget` lateral (`m_sidepanel`) contendo
abas de Componentes/Arquivos/Editor; instrumentos (`dataplotwidget/`), monitor serial (`serial/`) e monitor
de MCU (`memory/mcumonitor.h`) são janelas **abertas sob demanda**, nunca fixas no layout principal.

| SimulIDE (real) | Papel | Equivalente no LasecSimul (real, auditado 2026-07-07) | Nota |
|---|---|---|---|
| `CircuitWidget`/`CircuitView` (canvas central) | Área principal, sempre visível | `SchematicPanel.ts` (`vscode.WebviewPanel`) + `ui/webview/main.ts` | Mesmo conceito; renderização própria (SVG/DOM), não `QGraphicsScene`. |
| `ComponentList` + busca (aba do `m_sidepanel`) | Paleta de componentes, filtro por texto | `ComponentPaletteViewProvider.ts` (`vscode.WebviewView`) + `ui/webview/palette.ts`/`paletteTree.ts` | **Decisão final, revertida do plano original** (esta linha dizia "`TreeView` nativo do VSCode, não webview"): uma implementação em `TreeDataProvider` chegou a existir (`ui/tree/ComponentPaletteProvider.ts`) mas nunca foi registrada/ligada, e foi removida como código morto na auditoria de 2026-07-07 — a Webview de paleta é a que está de fato em produção, com busca/árvore construídas a partir de `folderPath`/`category` do catálogo (seção 13.1, sem hardcode de typeId→pasta). Migrar de volta pra `TreeView` nativo é decisão de produto nova, não retomada do código morto. |
| `FileWidget` (aba do `m_sidepanel`) | Navegador de arquivos do projeto | **Nenhum** | Redundante com o Explorer nativo do VSCode — não replicar. |
| `EditorWindow` (aba do `m_sidepanel`) | Editor + compilador de firmware embutido | **Nenhum — excluído** | Pedido explícito: não compilamos firmware. Se o usuário quiser ver a fonte, abre um arquivo normal no próprio VSCode — sem necessidade de editor dedicado. |
| Diálogo de propriedades (`gui/properties/`, `QDialog` modal) | Editar propriedade do componente selecionado | `<dialog>` modal DENTRO do mesmo `SchematicPanel`/`main.ts`, aberto com duplo-clique no componente | **Decisão revertida** (esta linha dizia "painel persistente, não modal" — avaliado na prática e descartado): um painel lateral fixo ocupava espaço permanente e duplicava a paleta; o diálogo sob demanda, igual ao SimulIDE, manteve o canvas inteiro livre. Já alimentável via `IComponentModel::propertyDescriptors()` (seção 6.1), só a apresentação na Extension mudou. Não é um `vscode.WebviewPanel` separado -- é um `<dialog>` HTML dentro da MESMA Webview do canvas. |
| `dataplotwidget/` (osciloscópio/plotter) | Instrumento aberto a partir de um componente | Popup flutuante DENTRO do mesmo `SchematicPanel`/`main.ts` (`renderInstrumentPopups`), não um `vscode.WebviewPanel` separado | Mesmo conceito (sob demanda, não fixo na tela), implementação mais leve que o previsto originalmente -- nunca existiu `InstrumentPanel.ts` como painel próprio; um popup por instrumento aberto, todos dentro da mesma Webview do canvas. |
| `serial/` (terminal serial) | Console de UART | `vscode.Terminal` (já decidido na seção 8, item 8) | Sem painel novo — UART já roteia pro terminal nativo. |
| `memory/mcumonitor.h` (`MCUMonitor`, RAM/Flash/registrador/PC, `QDialog` sob demanda) | Inspeção de memória/registrador do MCU emulado | Ainda não implementado como UI dedicada (`McuMonitorPanel.ts` planejado aqui nunca foi construído) | QEMU já expõe isso via `gdbserver` (seção 8, item 9), usável direto do VSCode; um painel amigável por cima continua como trabalho futuro genuíno, não uma nomenclatura desatualizada como os itens acima. |
| Toolbar: `powerCircAct`/`pauseSimAct` | Play/pause da simulação | `lasecsimul.run`/`lasecsimul.pause`, registrados direto em `extension.ts` | Confirma o que já existia — sem mudança. Não existe `ui/commands/` como diretório separado (todo comando é registrado em `extension.ts`, ver seção 5). |
| Toolbar: `newCircAct`/`openCircAct`/`saveCircAct` | Novo/abrir/salvar projeto | API nativa de arquivo do VSCode (`workspace.fs`, diálogos nativos) | Não construir diálogo de arquivo próprio — o VSCode já oferece. |
| Toolbar: `zoomFitAct`/`zoomSelAct`/`zoomOneAct` | Zoom do canvas | Interno a `ui/webview/main.ts` | Estado de zoom é da webview, não um comando da Extension. |

### 13.1 Taxonomia da paleta de componentes — categorias do SimulIDE, não inventadas

A paleta (`ui/webview/paletteTree.ts::buildPaletteTree`) replica a árvore derivada do catálogo unificado
`LasecSimul/project/schema/component-catalog.json` (`items[]`). A taxonomia continua seguindo o
SimulIDE (`src/gui/componentlist/itemlibrary.cpp`, `loadItems()`, com tradução pt_BR de
`resources/translations/simulide_pt_BR.ts`) — não uma taxonomia própria. **Regra**: todo `typeId`
novo no catálogo usa nome/caminho de pasta equivalente ao SimulIDE; nunca inventar categoria nova se
já houver equivalente. Tabela completa (12 categorias de topo, 17 subcategorias, ~140 itens — o que
o LasecSimul implementa hoje é fração disso) em **`docs/15-taxonomia-paleta.md`**.

Cada item de paleta declara `folderPath` (array de segmentos) e a árvore é construída por caminho
hierárquico completo, sem limite fixo de profundidade (não só categoria/subcategoria). `category`/
`subcategory` existem como compatibilidade para entradas legadas; quando `folderPath` estiver presente,
ele é soberano.

Mesmo princípio visual do SimulIDE: pasta/categoria de topo nunca exige ícone próprio; item de
componente pode declarar ícone de Webview (`iconLightUri`/`iconDarkUri`, derivados de
`extension/media/components/{light,dark}/<icone>.svg` — par claro/escuro porque ícone de arquivo
custom não é retematizado automaticamente pelo VSCode, diferente de `ThemeIcon`/codicon). Árvore é
derivada do catálogo (sem lista hardcoded no provider) — pasta sem item descendente não aparece.

### 13.1.1 Contrato canônico do catálogo unificado (anti-corrupção)

Arquivo canônico: `LasecSimul/project/schema/component-catalog.json`.

Campos mínimos:

```json
{
  "schemaVersion": 1,
  "deviceLibraries": ["../devices/library.json", "../mcu-adapters/library.json"],
  "items": [
    {
      "typeId": "passive.resistor",
      "label": "Resistor",
      "pinCount": 2,
      "icon": "resistor",
      "folderPath": ["Passivos", "Resistores"],
      "defaultProperties": { "resistance": 1000 }
    }
  ]
}
```

Regras normativas (MUST/NEVER):

1. `project/schema/component-catalog.json` é a única fonte de verdade para catálogo de UI e para
   descoberta de bibliotecas a carregar no Core.
2. A shell (VSCode Extension hoje, qualquer outra no futuro) MUST ler `deviceLibraries[]` desse
   arquivo e chamar `loadDeviceLibrary` para cada entrada.
3. Código de UI MUST montar árvore/paleta a partir de `items[]`; listas hardcoded de componentes ou
   categorias são proibidas.
4. `folderPath` MUST ser tratado como caminho hierárquico completo e soberano quando presente.
5. `category`/`subcategory` (quando existirem) são fallback de compatibilidade; novos itens SHOULD
   declarar `folderPath`.
6. `typeId` é a chave estável entre UI, IPC e Core; mudar `typeId` exige migração explícita de
   projetos/fixtures e revisão de compatibilidade.
7. `pinCount` e `defaultProperties` definidos no catálogo MUST ser o contrato inicial da UI para
   criação de instância (requestAddComponent/addComponent).
8. Subcircuitos, plugins e built-ins seguem o mesmo catálogo (`items[]`) — a origem de execução muda,
   o mecanismo de catalogação não.
9. `extension/src/ui/webview/catalog.ts` pode existir somente como fallback de boot; nunca como fonte
   primária em produção.
10. `contributes["lasecsimul.deviceLibraries"]` (VSCode `package.json`) NÃO existe mais (removido em
    2026-07-07, auditoria de UI -- confirmado que nada no código lia esse bloco; a única fonte real
    já era `component-catalog.json::deviceLibraries[]`, item 1 acima). Não reintroduzir.
11. `language` (string, BCP-47) MUST estar declarado na raiz de `component-catalog.json` — é a língua
    em que `items[].label`/`items[].folderPath` estão escritos. `translations.<lang>.items.<typeId>`
    MAY sobrescrever `label`/`folderPath` por item, pra outra língua (seção 6.3.1/6.3.2 — modelo
    conceitual `LocalizedString`, codificado como bloco `translations` paralelo, não union inline).
    Para o catálogo first-party do projeto, `translations.en` é obrigatória para todo item novo.
    **Implementado**: `UnifiedCatalog.ts::resolveLocalizedItems`, exemplo real em
    `project/schema/component-catalog.json`, e fontes registradas/subcircuitos com fallback de pasta

12. A UI MUST traduzir `authoringScene`/`package` por um parser/tradutor genérico compatível com a
  construção do SimulIDE (mesmos primitivos, mesmas transformações e mesma semântica de pinos/fios).
13. A UI MUST NOT depender de helper ad-hoc por dispositivo (`if/switch` por `typeId`) para montar
  geometria, pinos, placement ou wire routes quando essa informação existir no payload declarativo
  (`authoringScene`/`package`/metadata).
14. Mapeamento hardcoded por dispositivo para rendering/placement é OUT OF SCOPE; a única exceção
   permitida é infraestrutura genérica do próprio parser/tradutor (normalização, validação, fallback
   sintático), sem regra de negócio acoplada a `typeId` específico.
    localizável em `extension.ts`.
15. `registeredSources[]` (opcional, não mostrado no bloco de campos mínimos acima) MUST apontar só pra
    arquivos/diretórios — bibliotecas inteiras ou um registro avulso feito pelo usuário via "Registrar
    arquivo..." — NUNCA enumerar manualmente cada dispositivo já coberto por uma entrada de
    `deviceLibraries[]`. A Extension deriva as entradas de paleta automaticamente expandindo cada
    `library.json` de `deviceLibraries[]` (`registeredSources.ts::expandLibraryJsonToSources`,
    `catalogCommands.ts::refreshUnifiedCatalogState`) — um `library.json` já é, sozinho, o "arquivo
    canônico que declara 1 ou vários dispositivos" (`lasecsimul-native-devices.spec` seção 14, "Unicidade
    global de device ID"). Achado real corrigido 2026-07-15: os ~69 dispositivos de
    `devices/library.json`/`mcu-adapters/library.json`/`subcircuits/library.json` estavam TAMBÉM
    hand-authored em `registeredSources[]`, mascarando um bug de empacotamento (`package-release.js`
    zerava esse array antes de gerar o VSIX) que fazia NENHUM deles aparecer numa instalação real.
16. Cada `typeId`/`chipId` MUST pertencer a exatamente um arquivo canônico (`.lsdevice`/`.lssubcircuit`),
    descoberto uma única vez pelo sistema inteiro. Duplicidade entre `items[]` estático,
    `deviceLibraries[]` expandido e `registeredSources[]` avulso é erro arquitetural, nunca
    first-wins/last-wins/overwrite silencioso — reportado por `deviceUniqueness.ts::checkDeviceIdUniqueness`
    (Extension, `vscode.window.showErrorMessage` nomeando as duas definições) e rejeitado por
    `GlobalPluginCache::loadLibrary` (Core, lança `std::runtime_error`). Recarregar o MESMO arquivo de
    novo (mesmo caminho canônico) é reload idempotente, não conflito.

### 13.1.1 Contrato normativo único de geometria (`simulide-terminal-v1`)

Este contrato é a fonte normativa para geometria de componentes e substitui qualquer descrição
histórica conflitante nesta especificação. O relatório
`docs/28-geometria-simulide-terminal-unico-2026-07-13.md` contém evidências, referências de linha e
resultados da investigação; ele não cria uma segunda definição do contrato.

1. `PackagePin.x`/`y` MUST representar sempre, em coordenadas locais do componente, o **terminal
   elétrico externo**: o mesmo ponto onde começa visualmente o lead e onde o wire se conecta.
   Corpo, renderer e topologia MUST NOT manter coordenadas independentes para esse ponto.
2. O contato interno com o corpo MUST ser derivado exclusivamente do terminal, de `angle` e de
   `length`, seguindo a semântica do SimulIDE (`Pin::setRotation(180-angle)`). `leadOrigin` é legado e
   MUST NOT existir no catálogo canônico, em `PackagePin` ou no modelo interno. O sanitizador de
   entrada MAY aceitar somente payload legado explicitamente marcado como origem no corpo, convertê-lo
   imediatamente para terminal e descartar a marca.
   Packages portados do `paint()` real SHOULD declarar `coordinateSpace: "simulide-local"`: nesse
   modo, `pins`, labels e primitivas usam diretamente os `QPoint` locais da fonte e
   `simulidePaint.bounds`/`m_area` fornece a única origem de normalização para corpo e terminais.
3. Flip local, rotação em torno da origem local, translação para a cena, transformação inversa,
   cálculo dos cantos transformados e snap MUST usar a infraestrutura comum
   `extension/src/ui/webview/componentGeometry.ts`. Renderer, wire topology, hit-test, seleção e
   dispositivos MUST NOT reimplementar fórmulas próprias equivalentes.
4. A ordem normativa é: geometria local -> espelhamento local -> rotação local -> translação de cena.
   A conversão cena->local MUST ser a inversa exata dessa composição. Arredondamento ou snap MUST
   ocorrer somente em eventos de placement/edição no espaço da cena, nunca durante `paint`/SVG nem
   durante a transformação dos pinos.
5. `boundingRect`/bounds resolvidos MUST ser derivados do corpo, shapes e extremos visuais dos leads,
   com margem de stroke explícita e mínima. Labels só integram os limites quando a política declarada
   assim determinar. Área de seleção/`shape` MAY ser mais tolerante, mas MUST NOT alterar a geometria,
   a origem, o snap ou o endpoint elétrico.
6. Rotação e espelhamento MUST usar a mesma origem local declarada para corpo e pinos. Escala/zoom da
   view MUST NOT mudar coordenadas lógicas, comprimentos de terminais ou endpoints elétricos.
7. Componentes repetitivos MUST derivar corpo, células e pinagem de uma única descrição paramétrica
   (`dynamicLayout`/`pinGroups` e `simulidePaint.repeat`, ou sucessor genérico equivalente): linhas,
   colunas, célula, espaçamento, margens, ordem e orientação. Coordenadas especiais por célula ou por
   dispositivo são proibidas quando puderem ser obtidas desses parâmetros.
   Quando `dynamicLayout.replacePins` for `true`, `package.pins` MUST estar vazio; manter uma cópia
   estática do mesmo layout é erro de catálogo e MUST ser rejeitado pelo check de migração.
   O `fallback` interno de uma `PackageNumberExpression` é uma base bruta que ainda recebe
   `multiplier/offset`. Já o fallback fornecido pelo campo (`package.width`/`height` ou bounds
   declarado) é o resultado final e MUST NOT passar novamente pela expressão. Previews de inserção
   MUST materializar as mesmas `defaultProperties` usadas para criar a instância antes de calcular
   `componentBox`.
8. Esquemático e Modo Placa MAY ter desenhos e bounds visuais diferentes, mas MUST compartilhar
   identidade dos pinos, endpoint elétrico, transformação, rotação/flip, serialização e estado de
   simulação. Uma variante visual não cria uma segunda implementação elétrica.
9. O catálogo canônico MUST declarar `geometryConvention: "simulide-terminal-v1"`. A migração/check
   `scripts/migrate-package-pin-terminals.mjs --check` MUST rejeitar coordenadas legadas ou ambíguas.
10. A aceitação MUST cobrir, no mínimo: quatro rotações, ambos os flips, round-trip local/cena,
    coincidência entre extremo visual e wire endpoint, bounds sem corte/margem excessiva, layout
    repetitivo uniforme, snap, zoom e persistência após salvar/reabrir. Novos dispositivos entram na
    auditoria geral; não recebem offset corretivo por `typeId`.

Referência arquitetural confirmada no SimulIDE: `Component : QGraphicsItem` e `m_area` em
`src/components/component.h`; `Component::boundingRect`, flip com `QTransform::fromScale` e rotação
do item em `src/components/component.cpp`; `Pin` como item filho, `setPos`, `setRotation(180-angle)`,
`scenePos` como conexão elétrica e lead desenhado a partir de `(0,0)` em
`src/components/connector/pin.cpp`; snap/grid em `src/utils.cpp` e `src/gui/circuitwidget/circuit.cpp`;
zoom via `QGraphicsView::scale` em `src/gui/circuitwidget/circuitview.cpp`. O commit de referência é
`ed253d6612b1293a320d68d6e27968cd7e6523c4`; linhas exatas ficam registradas no relatório citado.

### 13.2 Achado fora do mapeamento de painel: `BatchTest` — regressão headless de circuitos

`gui/testing/batchtest.h` roda N arquivos de circuito de uma pasta sem UI, contra "unidades de teste"
(componentes especiais colocados no próprio circuito que reportam pass/fail), acumulando falhas. Não é um
painel — é uma capacidade de **testar circuitos salvos automaticamente, sem abrir o VSCode**. Não implementar
agora, mas vale registrar: nosso Core já é headless por construção (`core/test/voltage_divider_test.cpp`
prova isso), então replicar essa capacidade depois é rodar o Core contra N `.lsproj` salvos — não exige
nenhuma peça nova de arquitetura, só um executável pequeno que itera arquivos e chama `SimulationSession`.
Candidato natural a feature futura de CI/regressão, não a UI.

### 13.3 Rótulo de identificação e de valor no esquemático — implementado

Achado em auditoria do SimulIDE-dev (`components/component.{h,cpp}`): todo componente tem dois rótulos de
texto desenhados perto do símbolo — `m_idLabel` (nome com índice, ex: `"Resistor-1"`) e `m_valLabel`
(valor formatado da propriedade principal, ex: `"1 kΩ"`) — cada um com checkbox próprio de visibilidade
(`Show_id`/`Show_Val`), modelados como `ComProperty` comuns do próprio componente (mesmo mecanismo
genérico de propriedade, sem caso especial). O LasecSimul replica o conceito com duas diferenças
deliberadas (decididas com o usuário, não suposição):

1. **Contador por `typeId`**, não global de sessão — SimulIDE usa `Circuit::m_seqNumber` único pra todos
   os tipos (gera furos ao misturar tipos: "Resistor-1", "Capacitor-2", "Resistor-3"); o LasecSimul conta
   por tipo (`nextIndexedLabel` em `extension.ts` e em `main.ts`, duplicado — dois pontos de criação de
   componente independentes), igual ao padrão de ferramentas EDA (KiCad/Eagle) — `Resistor-1`,
   `Resistor-2` sempre sequenciais entre si. Nunca persistido como contador separado: recalculado a
   cada criação a partir de `WebviewComponentModel.label` de quem já existe (mesmo princípio do
   `Circuit::loadStrDoc` do SimulIDE — "se number > m_seqNumber, ajusta", só que aqui é recalculado toda
   vez, não cacheado).
2. **Reaproveita a flag `PropertySchemaShowOnSymbol`** (seção 6.1.2) em vez de um ponteiro `m_showProperty`
   separado por componente — o rótulo de valor é, por definição, a propriedade do schema marcada
   `showOnSymbol` (no máximo uma por typeId hoje); `Resistor`/`Capacitor`/`Inductor`/`DcVoltageSource`
   marcam sua única propriedade elétrica com essa flag, `Button` não marca nenhuma (estado já visível
   pelo símbolo aberto/fechado). O mesmo flag já alimentava a leitura ao vivo do voltímetro
   (`displayVoltage`, `editor: "display"`) — `valueLabelText` (`main.ts`) generaliza os dois casos
   (estático formatado vs. telemetria ao vivo) por um único caminho, sem checar `typeId`.

Visibilidade (`WebviewComponentModel.showId`/`showValue`) é propriedade **de sistema** — aplica-se a
QUALQUER typeId igual, nunca vem do `propertySchema` do Core (não é elétrica); 2 checkboxes sintéticos
("Mostrar nome"/"Mostrar valor") são injetados direto pelo diálogo de propriedades (`renderPropertySheet`
em `main.ts`), num grupo "Visual" sempre presente, fora do mecanismo `resolvePropertyFields`. Mudar um
envia `requestUpdateLabelVisibility` (`WebviewToHostMessage`) — handler em `extension.ts` só atualiza
`schematicState`, nunca toca o Core (puramente visual). Persistido em `ProjectComponent.label`/`showId`/
`showValue` (`.lsproj`) — sem isso, o nome indexado se perderia a cada save/reload, igual o
`label`/`Show_id`/`Show_Val` que o SimulIDE também persiste (`CompBase::toString()`).

**Corrigido (2026-07-18)**: o checkbox "Mostrar valor" descrito acima não existia de fato — só havia
um RÁDIO por propriedade numérica ("mostrar no símbolo", dentro de `renderPropertyField`, visível só
com 2+ candidatas) que LIGAVA `showValue`, nunca desligava. Resistor/Capacitor/Inductor (1 candidata
só) não tinham candidato nenhum a rádio, então `effectiveShowValue` ficava sempre `true` por padrão
sem NENHUM controle pra desmarcar — reportado como "não consigo mostrar só o nome, ou só esconder o
valor". `componentHasToggleableValueLabel` (`main.ts`, ao lado de `effectiveShowValue`) decide quando
faz sentido oferecer o checkbox (exclui Probe, mecanismo próprio via `showVolt`, e typeIds com
mostrador embutido no símbolo via `usesEmbeddedValueLabel`, onde o rótulo externo nunca aparece de
qualquer forma); o checkbox em si reusa a mesma mensagem/persistência de sempre, sem tocar
`valueLabelPropertyKey` (preserva qual propriedade fica escolhida pra quando o rótulo for reexibido).
Com isso as 4 combinações (nome+valor, só nome, só valor, nenhum) ficam possíveis por instância, como
pedido — cada rótulo posicionado independentemente (`defaultExternalLabelOffset` por `kind`, nunca um
cálculo conjunto), então ocultar um nunca desloca nem deixa vão no outro.

Formatação do rótulo de valor (`formatEngineeringValue` em `main.ts`) porta o `valToUnit` do SimulIDE
(`utils.h`): escolhe o prefixo SI (p/n/µ/m/—/k/M/G) que mantém a mantissa abaixo de 1000.

**Atualizado (2026-07-18, revisão global de labels)**: o parágrafo acima ("fora de escopo: arrastar
o rótulo independentemente do símbolo, posição fixa") está desatualizado — o sistema completo já
está implementado. `extension/src/ui/webview/componentLabels.ts` (módulo puro, sem DOM, importável
tanto pela Webview quanto pelo host em `catalog/*` e por testes em Node) é a fonte única de:
posição PADRÃO do rótulo (`resolveDefaultExternalLabelOffset`, centralizada na largura real do
corpo via `componentBox`), tamanho de fonte (`genericExternalLabelFontSize`, propriedade
`__ui_idLabelSize`/`__ui_valueLabelSize`), cor (`resolveExternalLabelColor`, `__ui_idLabelColor`/
`__ui_valueLabelColor`) e nomenclatura das chaves de propriedade (`labelPropertyKey`). `main.ts`
usa esses resolvers em `renderExternalLabel` (o `<div class="component-floating-label--id|value">`
arrastável, com clique/ctrl+clique pra seleção múltipla, menu de contexto com "Propriedades"/girar/
alinhar/distribuir, e persistência via `requestUpdateProperty`) pra QUALQUER `typeId` do catálogo
sem exceção — inclusive Switches, onde o problema original era mais visível (rótulo ancorado na
borda esquerda de corpos estreitos como `switches.switch_dip`/`switches.relay`, texto mais longo que
o corpo invadindo componentes vizinhos). Válido tanto no esquemático principal quanto no circuito
interno de um subcircuito (`subcircuitEditorMode==="circuit"`) — é o MESMO código, sem sistema
paralelo (ver seção 30).

Únicas 2 exceções, ambas estritamente `kind==="id" && component.typeId===SYMBOL_PIN_TYPE_ID &&
subcircuitEditorMode==="symbol"` (`main.ts::renderExternalLabel`/`externalLabelWorldBox`): o pino do
Modo Símbolo renderiza seu texto pelo SVG consolidado do símbolo (`compileLiveSymbolPins` →
`packagePinLeadSvg`, ver `.spec/lasecsimul-subcircuits.spec` seção 23), não pelo `<div>` HTML — o
`<div>` vira só uma hit-box transparente pra clicar/arrastar; e `connectors.tunnel`, que embute seu
próprio nome no símbolo, sem rótulo id externo.

### 13.4 Seleção múltipla, atalhos de teclado e zoom — implementado

Achado em auditoria do SimulIDE-dev: **o SimulIDE não distingue arrastar pra direita vs. pra esquerda**
ao selecionar por retângulo — `CircuitView` usa só `QGraphicsView::setDragMode(RubberBandDrag)` puro do
Qt (`circuitview.cpp` linha 52), seleção por **interseção simples** (`IntersectsItemShape`, padrão do
Qt), sem lógica de direção alguma. Essa distinção (direita = "contém", esquerda = "intersecta") é
convenção de outras ferramentas (AutoCAD/Eagle), não do SimulIDE — o LasecSimul implementa a versão
real do SimulIDE (interseção simples), não a variante direcional.

**Modelo de seleção múltipla**: `WebviewProjectState.selectedComponentId?: string`/`selectedWireId?:
string` (singulares) tornaram-se `selectedComponentIds: string[]`/`selectedWireIds: string[]` — array
vazio é "nada selecionado", nunca `undefined`. Migração de estado persistido pré-existente
(`vscode.getState()`) feita em `normalizeProjectState` (`main.ts`), unidirecional (seleção não precisa
sobreviver a uma atualização da extensão).

**Marquee** (`main.ts`, `pointerdown` no `.canvas` em área vazia — componente/fio/pino já chamam
`stopPropagation()` nos próprios listeners, então nunca disparam o marquee por engano): overlay visual
em coordenadas de tela (`.marquee-rect`); confirmado como arrasto (não clique simples) só após um
limiar de ~4px; no `pointerup`, `applyMarqueeSelection` testa interseção de caixa
(`component.x/y` + `componentBox(typeId)`) contra os 2 cantos convertidos pra coordenada local
(`eventToCanvasPoint`) — fio entra se algum ponto da polilinha cair dentro do retângulo (simplificação
documentada de "toca"). Shift+click individual alterna um item dentro/fora da seleção (convenção comum
de desktop, não verificada item-a-item contra o SimulIDE).

**Atalhos** (`circuit.cpp::keyPressEvent` do SimulIDE, replicados em `window.addEventListener("keydown")`
de `main.ts`): `Ctrl+R` rotaciona CW todos os componentes selecionados; `Ctrl+Shift+R` rotaciona CCW;
`Ctrl+A` seleciona todo componente/fio não oculto; `Delete`/`Backspace` remove toda a seleção (estendido
de 1 item pra N — uma mensagem IPC por item, nenhum verbo em lote novo). Atalho solto `r` (sem Ctrl,
pré-existente) continua rotacionando só o primeiro selecionado, sem conflito com `Ctrl+R`.

**Zoom por scroll** (`CircuitView::wheelEvent` do SimulIDE): fator `2^(-deltaY/700)` (mesma fórmula),
zoom centralizado no cursor (ponto canvas-local sob o cursor recalculado e mantido fixo após a mudança
de escala — técnica padrão de "zoom under cursor"), limitado a `[0.2, 4]` (**decisão do LasecSimul, não
do SimulIDE** — o SimulIDE real não tem limite codificado). Implementação exigiu introduzir
`viewport.{x,y,zoom}` de fato (existia no schema, mas estava morto — nenhum código lia/escrevia):
conteúdo do esquemático (fios+componentes) passou a viver num wrapper `.canvas-content` com
`transform: translate(x,y) scale(zoom)`, enquanto `.canvas` (onde ficam os listeners de
pointerdown/wheel/contextmenu) continua um viewport fixo, nunca se move — `eventToCanvasPoint` inverte
a transformação (`(client - rect - pan) / zoom`) em todo cálculo de coordenada tela→canvas. O drag de
componente (que somava delta de `clientX`/`clientY` cru) precisou dividir o delta por `zoom` — sem isso,
mover um componente com zoom ≠100% ficaria mais rápido/lento que o cursor.

**Menu de contexto** (`Component::contextMenu` do SimulIDE): completo com Rotacionar CW/CCW/180°,
Excluir, Propriedades (só quando exatamente 1 item selecionado) — right-click num item que já faz parte
de uma seleção múltipla atual opera sobre TODOS os selecionados; right-click num item FORA da seleção
atual troca a seleção pra só ele primeiro. Fundo vazio ganhou "Selecionar tudo".

**Cursor `grabbing`**: classe `.dragging` aplicada via JS no início do arraste de componente, removida
no fim — `cursor: grabbing` (CSS) enquanto arrasta, `grab` em repouso (já existia).

**Implementado após esta rodada inicial**: copiar/colar (`Ctrl+C/X/V`), flip horizontal/vertical
(`H`/`V`) e undo/redo (`Ctrl+Z/Y`/`Ctrl+Shift+Z`) já existem. Ver seção 17 para o desenho atual do
histórico de undo/redo e os keybindings finais.

**Correção pós-validação — `Ctrl+R`/`Ctrl+Shift+R` sobrepondo keybinding nativo do VSCode**: tratar a
tecla só no `keydown` da Webview (com `event.preventDefault()`) não impede o VSCode de TAMBÉM despachar
seu próprio comando nativo pra essas teclas (`Ctrl+R` = "Abrir recente") — são dois listeners
independentes (host VSCode vs. conteúdo do iframe da Webview), `preventDefault()` de um não afeta o
outro. Mecanismo certo (e o usado aqui): `contributes.keybindings` (`extension/package.json`) rebind
explícito pros comandos `lasecsimul.rotateSelectionCw`/`Ccw`, com `"when": "activeWebviewPanelId ==
'lasecsimul.schematic'"` — sobrepõe o nativo do VSCode SÓ enquanto o painel do esquemático está em
foco; ao trocar de foco o `when` deixa de casar e o atalho nativo volta a funcionar sozinho, sem
nenhuma lógica de restauração manual no código. O comando manda `requestRotateSelection`
(`HostToWebviewMessage`) pra Webview; a Webview NÃO trata mais `Ctrl+R`/`Ctrl+Shift+R` no próprio
`keydown` (só esse caminho, pra não rotacionar em dobro caso o evento ainda chegasse de algum jeito).
Mesmo padrão deve ser usado pra qualquer atalho futuro que colida com um comando nativo do VSCode —
nunca tentar "ganhar a corrida" só dentro da Webview.

### 13.5 Atualizacao Core/Paleta SimulIDE de Switches, Passive, Active e Outputs

Implementado em 2026-06-28: a paleta canonica (`project/schema/component-catalog.json`) inclui os itens das
pastas do SimulIDE mostradas na referencia do usuario: `Switches`, `Passive` (`Resistors`, `Resistive
Sensors`, `Reactive`), `Active` (`Rectifiers`, `Transistors`, `Other Active`) e `Outputs` (`Leds`,
`Displays`, `Motors`, `Other Outputs`). No LasecSimul esses itens aparecem nas pastas pt-BR usadas pela UI
atual (`Interruptores`, `Passivos`, `Ativos`, `Saidas`) e preservam os nomes de item do SimulIDE, como
`Push`, `Switch (all)`, `Switch Dip`, `Relay (all)`, `KeyPad`, `ResistorDip`, `Electrolytic Capacitor`,
`BJT`, `Mosfet`, `LedMatrix`, `Hd44780`, `Dc Motor`, etc.

O Core registra os itens simples como built-ins em `CoreApplication.cpp`. Componentes que o solver atual
consegue representar diretamente continuam por `IComponentModel` built-in (resistivos, potenciometro,
chaves, rele simples, regulador de tensao, LED simples e passivos equivalentes). A regra de produto para
componentes complexos fica explicita: eles nao devem ganhar uma terceira forma de runtime; entram por uma
das duas vias existentes, built-in ou ABI. Nesta rodada, os componentes que estavam incompletos por serem
protocolados/graficos ou modelos ativos mais ricos foram movidos para a via ABI/plugin em
`devices/simulide-complex/`, mantendo os mesmos `typeId`s do catalogo:
`outputs.ssd1306`, `outputs.sh1107`, `outputs.hd44780`, `outputs.aip31068_i2c`, `outputs.ili9341`,
`outputs.st7735`, `outputs.st7789`, `outputs.gc9a01a`, `outputs.pcf8833`, `outputs.pcd8544`,
`outputs.ks0108`, `outputs.max72xx_matrix`, `outputs.ws2812`, `outputs.servo`, `outputs.audio_out`,
`passive.transformer`, `active.diac`, `active.scr`, `active.triac`, `active.bjt`, `active.mosfet` e
`active.jfet`.

A ABI foi aprimorada sem criar runtime paralelo: `PluginRuntime` injeta a propriedade reservada
`__typeId` no contexto de configuracao para permitir que um mesmo binario ABI compartilhe codigo entre
varios manifests, e `SimulationSession`/IPC expõem `sendComponentEvent`, que entrega eventos diretamente a
`LsdnDeviceVTable::on_event`. O evento usa os tags ABI existentes (`LSDN_EVT_PIN_CHANGE`/`LSDN_EVT_TIMER`)
para bordas temporizadas — `LSDN_EVT_BUS_WRITE`/`LSDN_EVT_BUS_READ_REQUEST` foram removidos no bump de ABI
major 2 (sem barramento por bytes nunca ligado a um `SimulationSession` real, ver
`docs/17-pendencias-pos-sessao-qemu-abi.md` seção 0.3). Quando uma biblioteca ABI
declara um `typeId` que ja existia como built-in aproximado, o registro de plugin substitui explicitamente a
factory anterior para novas instancias; isso preserva o contrato "built-in ou ABI" sem manter duas
implementacoes ativas do mesmo componente.

O pacote `simulide-complex` implementa interpretadores de comandos inspirados no SimulIDE para HD44780/AIP31068,
OLED SSD1306/SH1107, PCD8544, KS0108, controladores TFT ST77xx/ILI9341/GC9A01A/PCF8833, MAX72xx, WS2812 e
servo PWM, expondo RAM/framebuffer/estado por `get_state`. A entrada principal desses componentes e bit a bit via
`LSDN_EVT_PIN_CHANGE`: HD44780/KS0108 fazem latch de pinos paralelos em `EN`, PCD8544/MAX72xx/TFTs deslocam bits em
SCK/SCL, AIP31068/SSD1306/SH1107 reconhecem START/STOP e bytes I2C MSB-first, WS2812 mede pulsos temporizados e
servo PWM converte largura de pulso em alvo angular. Nao existe mais modulo generico de barramento remontando
byte algum — cada device decodifica o protocolo por conta propria a partir dos eventos de borda. Tambem substitui os aproximados de
DIAC/SCR/TRIAC, BJT/MOSFET/JFET, audio out e transformer por plugins ABI com estado/propriedades/modelo eletrico no
caminho de plugin. Teste de aceitacao headless: `CoreBootstrapTest::testSimulideComplexAbiEventsOverIpc` carrega
`devices/library.json`, instancia `outputs.hd44780` via ABI, envia RS/RW/D0-D7/EN por IPC bit a bit e verifica a DDRAM
via `getComponentState`.

Tambem esta implementado o contrato de `setProperty` que estava pendente na secao 6.1.2: validacao de
`readOnly`, tipo, faixa e opcoes antes do setter; erro IPC estavel (`errorCode`); `affectsTopology` marcando
topologia suja; e `requiresRestart` reportado explicitamente na resposta IPC sem reinicio automatico.

## 15. Novos verbos IPC e contratos de UI (2026-07-03)

### 15.1 `setTunnelName` — renomear túnel em runtime via IPC dedicado

**Contrato**: `setTunnelName { instanceId, pinId, oldName, newName }` → `{ ok, error? }`.

O `setProperty` genérico NÃO pode ser usado para renomear túnel porque ele apenas re-stampa o
componente (não reconstrói topologia). `SimulationSession::setTunnelName` faz o que é necessário:
remove o slot do mapa de túneis pelo nome antigo, muda o nome da propriedade, e re-registra — o que
dispara o rebuild de topologia correto (mesma operação que o `Tunnel::setName()` do SimulIDE real
desencadeia via `Simulator::rebuild()`). A Extension captura o estado ANTES de atualizar o
`schematicState` para obter `oldName` e `pinId`, depois chama `setTunnelName` em vez de `setProperty`
quando `name === "name"` e `typeId === "connectors.tunnel"`.

O catálogo de `connectors.tunnel` declara `defaultProperties: { name: "NetA" }` para que toda nova
instância tenha um nome não-vazio desde a criação — sem isso, o primeiro `setTunnelName` receberia
`oldName: ""` e não encontraria o slot para mover.

### 15.2 `setSimulationConfig` — throttle e limite de iterações não-lineares

**Contrato**: `setSimulationConfig { targetStepUs?, maxNonLinearIterations? }` → `{ ok, error? }`.

Configura dois parâmetros do `Scheduler` via `std::atomic` (thread-safe, sem parar a simulação):
- `targetStepUs`: intervalo mínimo de sleep entre eventos processados. `0` = sem throttle (padrão).
  Útil para ver a simulação em câmera-lenta em projetos simples.
- `maxNonLinearIterations`: cap no número de iterações do settle-loop por evento. `0` = sem limite
  (padrão). Útil para evitar que simulações com não-linearidades fortes travem em laços longos.

Ambos sobrevivem até o próximo `setSimulationConfig` ou fim da sessão. O Core não persiste esses
valores em arquivo — é responsabilidade da Extension reaplicá-los ao abrir o painel (via listener de
`vscode.workspace.onDidChangeConfiguration`).

### 15.3 Settings VSCode (`lasecsimul.*`)

As seguintes configurações VSCode (contribuídas em `package.json`) controlam comportamento global:

| Setting | Tipo | Default | Efeito |
|---|---|---|---|
| `lasecsimul.simulation.targetStepUs` | number | 0 | Enviado via `setSimulationConfig` ao mudar |
| `lasecsimul.simulation.maxNonLinearIterations` | number | 0 | Enviado via `setSimulationConfig` ao mudar |
| `lasecsimul.ui.showComponentIds` | boolean | false | Mostra IDs internos na UI (debug) |
| `lasecsimul.ui.snapToGrid` | boolean | true | Snap de posicionamento à grade |

O comando `lasecsimul.openSettings` abre o painel nativo de Settings do VSCode filtrado em
`"lasecsimul."` via `workbench.action.openSettings` — sem painel próprio, sem reimplementar a UI de
configurações.

### 15.4 Campo `help` no catálogo de componentes

`WebviewComponentCatalogEntry.help?: { description?: string; url?: string; file?: string }`

- `description`: texto curto (1-2 linhas) exibido no tooltip do botão "Ajuda" no diálogo de
  propriedades e no tooltip do item na paleta de componentes.
- `url`: link externo para documentação completa. O botão "Ajuda" no diálogo de propriedades dispara
  `requestOpenExternal { url }` → Extension → `vscode.env.openExternal(Uri.parse(url))`.
- `file`: caminho relativo ao manifesto para arquivo `.md` local (não implementado ainda — reservado).

O botão "Ajuda" fica desabilitado quando `help` está ausente ou nenhum `url` é fornecido. Todos os
device JSONs de `devices/simulide-sensors/` e `devices/simulide-peripherals/` têm `help.description`
declarado. Os built-ins do catálogo `project/schema/component-catalog.json` têm `help` nos tipos
relevantes (resistor, capacitor, fontes, medidores, conectores, etc.).

### 15.5 `requestOpenExternal` (Webview → Extension)

**Mensagem**: `{ version, type: "requestOpenExternal", url: string }`

Disparado pela Webview ao clicar no botão "Ajuda" quando `help.url` está presente. A Extension
simplesmente chama `vscode.env.openExternal(vscode.Uri.parse(url))` — sem validação adicional (a URL
vem do manifesto de primeira parte ou de item registrado pelo usuário, já confiável no mesmo nível que
o restante do manifesto).

## 16. Bug corrigido: menu de contexto do dispositivo aparece e é substituído pelo menu nativo (2026-07-06)

**Sintoma relatado**: clique direito num dispositivo mostra o menu customizado correto (com todas as
propriedades/ações) por um instante, mas ele logo desaparece e é substituído por um menu genérico
com apenas Cortar/Copiar/Colar.

**Causa raiz**: `showContextMenu()` (`extension/src/ui/webview/main.ts`, chamada por TODOS os 5
handlers de `contextmenu` da Webview -- componente, rótulo de texto externo, corner/segment handle
de fio, canvas vazio) chamava `event.stopPropagation()` incondicionalmente. Isso cortava a
propagação do evento DOM antes dele chegar em `window`/`document` -- onde o HOST da Webview do
VSCode (fora do controle da extensão, parte da infraestrutura de webview do próprio VSCode/Electron)
também escuta `contextmenu` pra decidir se abre o menu NATIVO (Cortar/Copiar/Colar) do editor, com
base em `event.defaultPrevented`. Como o evento nunca chegava lá, o host nunca via que o menu já
tinha sido tratado por completo e abria o nativo por cima -- um instante depois, por ser um
round-trip nativo/nível-Electron, não um evento DOM síncrono, o que explica o "aparece e some".

Confirmado com uma simulação do algoritmo real de dispatch/bubble (target → ancestors → window,
checando `defaultPrevented` a cada nível): com `stopPropagation()`, o "host" nunca observa o evento
e vê `defaultPrevented=false` (abriria o nativo); sem `stopPropagation()`, o host observa
`defaultPrevented=true` depois que qualquer handler mais específico já tratou o evento.

**Correção**: removido `event.stopPropagation()` de `showContextMenu()` e dos 2 handlers que também
chamavam explicitamente (componente, rótulo de texto externo) -- `preventDefault()` sozinho já basta
pra suprimir o menu nativo do navegador E sinalizar (via `defaultPrevented`) pro host que o evento
foi tratado. Como o evento agora BORBULHA normalmente até o `canvas` (ancestor de todo
componente/fio/handle no DOM, ver `.canvas` > `.canvas-content` > elementos), o handler de
`contextmenu` do `canvas` (o "genérico", mostra só "Selecionar tudo" em área vazia) ganhou uma
guarda `if (event.defaultPrevented) return;` no topo -- nunca substitui um menu mais específico já
mostrado por um descendente. Os 2 handlers de `handle` (corner/segment de fio) e o de rótulo de
texto externo NUNCA chamavam `stopPropagation()` diretamente (só via `showContextMenu`), então já
ficaram corretos automaticamente com a mudança na função compartilhada.

**Por que não é workaround visual**: a causa raiz era a suposição errada de que "cortar a propagação"
é a forma certa de impedir um menu mais genérico de substituir um mais específico -- na presença de
um host de Webview que TAMBÉM observa o mesmo evento em `window`/`document`, cortar a propagação tem
o efeito colateral de esconder do host que o evento já foi tratado. A troca por `defaultPrevented`
resolve os dois problemas com o MESMO mecanismo idiomático do DOM (`preventDefault()` sinaliza "já
tratado" pra qualquer observador em qualquer nível da árvore, sem impedir ninguém mais de OBSERVAR o
evento).

**Limitação desta sessão**: sem GUI disponível neste ambiente pra abrir o VSCode e confirmar
interativamente que o menu nativo não aparece mais -- a verificação foi (a) compilação limpa
(`tsc` webview + test), (b) suíte de testes completa sem regressão, e (c) uma simulação numérica do
algoritmo de bubble/`defaultPrevented` reproduzindo o bug com o código antigo e confirmando a
correção com o novo. Recomenda-se confirmar visualmente no VSCode real.

## 17. Undo/Redo (Ctrl+Z/Ctrl+Y/Ctrl+Shift+Z) (2026-07-06/07)

Recurso inexistente até aqui (ver seção 13, item "Não existe" da auditoria de 2026-07-03) -- primeira
implementação, cobrindo tanto o circuito principal quanto a sessão de autoria de símbolo/subcircuito
("Abrir Subcircuito"/editor de `package`).

### 17.1 Por que snapshot de conteúdo, não comando/patch reversível

`state.components`/`state.wires` (`main.ts`) são mutados de formas inconsistentes ao longo do
arquivo -- às vezes por reatribuição imutável (`state = {...state, ...}`), às vezes campo a campo
direto (`component.x = ...` durante um drag, `state.viewport.x = ...` no pan). Não há um único ponto
de mutação nem um padrão de comando reversível (tipo Redux/command-pattern) pra interceptar. Em vez
de reescrever esse padrão do zero (risco alto, toca ~40 pontos do arquivo), o undo aproveita
`persistState()` (`main.ts`) como o funil ÚNICO por onde toda mutação relevante já passa hoje --
comparando o CONTEÚDO (`components`/`wires`, serializado) ANTES/DEPOIS de cada chamada e empilhando
um snapshot profundo (`structuredClone`) só quando algo realmente mudou.

### 17.2 Dois hooks, não quarenta

Mapeamento das ~40 chamadas de `persistState()`/`send()` revelou dois padrões de mutação:

1. **Mutação local + `persistState()`** (drag de componente, rotação, edição de propriedade no
   diálogo, Modo Placa, etc.) -- já cai automaticamente no hook de `persistState()`
   (`recordUndoSnapshotIfChanged`), sem precisar tocar cada call site.
2. **Só `send()` pro Host, sem mutar `state` local** (`deleteSelectedItems()` fora de autoria manda
   `requestRemoveComponent`/`requestRemoveWire` e espera o Host devolver o estado já sem o item via
   `syncState`; `pasteClipboardItems()` muta local mas via `vscode?.setState(state)` direto, não
   `persistState()`) -- sem cobertura própria, ficaria não-desfazível. Coberto por um 2º hook no
   handler de mensagem `"syncState"` (`main.ts`): compara o `state` ATUAL (ainda não sobrescrito)
   contra o `message.project` recebido, ANTES de aplicar a sobrescrita -- mesma função
   (`recordUndoTransition`) usada pelo hook de `persistState()`, só que alimentada por uma fonte
   diferente. `"init"` (1ª carga) NUNCA vira uma entrada de undo -- reseta o histórico pro estado
   recém-carregado em vez de registrar transição.

Isso evita duas armadilhas: (a) instrumentar manualmente 40+ pontos de mutação (alto risco de
esquecer um, ou de duplicar registro quando os DOIS hooks disparam pro mesmo evento -- o hook de
`syncState` é idempotente quando o conteúdo já bate, ex. depois de uma rotação que já mutou local +
persistiu, o `syncState` de confirmação do Host não gera 2ª entrada); (b) desfazer/refazer coisas que
não são realmente "ações do usuário" (mudança só de seleção, que também passa por `persistState()`
em vários call sites, nunca conta pra fins de undo -- comparação usa só `components`+`wires`, nunca
`selectedComponentIds`/`selectedWireIds`).

### 17.3 Uma pilha do esquemático

Desde 2026-07-09 não existe sessão de autoria visual de símbolo/package dentro do webview. O undo/redo
é uma única `UndoHistory` (`mainUndoHistory`) do esquemático real, e `activeUndoHistory()` sempre retorna
essa pilha. `mainUndoHistory` é resetada só em `"init"` (1ª carga/reload do painel); alterações
confirmadas por `"syncState"`/`"syncStatePatch"` entram nessa mesma história.

### 17.4 Atalho de teclado -- mesmo caminho do Ctrl+R (não o `keydown` da Webview)

Ctrl+Z (undo), Ctrl+Y e Ctrl+Shift+Z (redo, os dois) são comandos GLOBAIS nativos do VSCode
(undo/redo do editor de texto) -- mesmo problema documentado na seção 13.4 pro Ctrl+R/Ctrl+Shift+R:
sem um keybinding dedicado, o VSCode intercepta a tecla antes dela chegar no `keydown` da Webview.
Resolvido com o MESMO padrão: `contributes.keybindings` (`package.json`, `when:
activeWebviewPanelId == 'lasecsimul.schematic'`) aponta pros comandos `lasecsimul.undo`/
`lasecsimul.redo` (`extension.ts`), que só fazem `schematicPanel?.postMessage({type: "requestUndo"
| "requestRedo"})` -- a Webview trata essas mensagens (`main.ts`) chamando as MESMAS funções
`undo()`/`redo()` internas, únicas donas da lógica (nenhuma lógica duplicada no `keydown` local).
Como o painel do esquemático é o MESMO em modo normal e em sessão de autoria (`state` troca, o
painel/`viewType` não), o mesmo par de comandos cobre os dois contextos automaticamente --
`undo()`/`redo()` escolhem a pilha certa via `activeUndoHistory()` em tempo de execução.

### 17.5 Verificação

Sem GUI disponível neste ambiente pra confirmar interativamente no VSCode real. Feito: (a)
compilação limpa (`tsc` main + webview + test), (b) suíte de testes completa sem regressão, (c) uma
simulação standalone (Node, fora do DOM) replicando fielmente `recordUndoTransition`/`undo`/`redo`/
`resetUndoHistory` com 15 cenários -- sequência de undo/redo de múltiplas ações, nova ação após um
undo invalida o redo, mudança só de seleção não empilha, fluxo `syncState` (remoção via Host) vira
undoable e restaura a seleção anterior, pilhas de autoria/principal independentes -- todos passando.
Recomenda-se confirmar visualmente: mover/rotacionar/apagar/colar itens no schematic real e dentro de
"Abrir Subcircuito", Ctrl+Z/Ctrl+Y em cada caso, incluindo com o foco alternando entre o painel do
esquemático e outros painéis do VSCode.

## 18. Bug corrigido: bola azul grande permanente nas alças de canto de fio ortogonal (2026-07-09)

**Sintoma relatado** (com screenshot do circuito interno do ESP32 DevKitC dentro de "Abrir
Subcircuito", ver `lasecsimul-subcircuits.spec` seção 16): alguns encontros/cotovelos de fio
mostravam uma bola azul grande, permanente, poluindo visualmente o esquemático -- padrão diferente
do SimulIDE real, que não desenha marcador nenhum sobre fio fora de interação ativa.

**Causa raiz**: `renderWireCornerHandles()` (`extension/src/ui/webview/main.ts`) desenha um
`<circle class="wire-layer__corner-handle">` em CADA ponto interior (cotovelo) de TODO fio ortogonal
com 3+ pontos -- chamada incondicionalmente pro loop principal de render (`main.ts`) e pra
`updateWireVisual` (atualização incremental), nunca gated por seleção/hover. A classe base
`.wire-layer__corner-handle` (`styles.css`) tinha `fill: #eef5ff; stroke: #5b7fd1` (azul claro)
como cor PADRÃO, só trocando pra âmbar (`--selected`, `#f4b942`) quando aquele cotovelo específico
estava selecionado -- ou seja, todo cotovelo de todo fio multi-segmento ficava permanentemente
visível em azul, não só o selecionado. Isso não é o mesmo marcador que `.junction-dot` (nó elétrico
real de nó de topologia, âmbar 8px, ver seção 15 do spec de subcircuitos) -- é uma alça de UI
pra ARRASTAR o cotovelo, sem relação nenhuma com topologia elétrica. **Nota 2026-07-11** (seção 24):
na época desta seção, aquele nó elétrico ainda era o componente `connectors.junction`; desde a
reconstrução do sistema de fios ele é um `topologyNode` puramente visual, nunca um componente do
Core -- o resto desta seção (o bug da alça de canto azul) não muda em nada.

**Correção** (`extension/src/ui/webview/styles.css`): base de `.wire-layer__corner-handle` virou
`fill: transparent; stroke: transparent` (igual ao padrão já estabelecido em `.pin-terminal`, mesmo
bloco de comentário histórico "bola grande na cor de destaque" de 2026-07-04) -- `fill: transparent`
(não `none`) preserva 100% da área clicável/arrastável (`pointer-events` só ignora `none`;
"transparente" ainda conta como pintado), então NENHUMA lógica de drag/roteamento/reconciliação foi
tocada, só a cor. `.wire-layer__corner-handle--selected` continua âmbar como antes -- único estado em
que a alça fica visível, exatamente quando o usuário já selecionou aquele cotovelo especificamente
(mesmo princípio de `.wire-layer__segment-highlight`, que também só aparece com
`isWireSegmentSelected`, nunca por hover passivo). `cursor: move` (inalterado) já basta de affordance
antes de clicar.

**Verificação**: compilação limpa (`tsc` webview + test) e suíte de testes completa (154 testes) sem
regressão -- nenhum teste depende de cor/preenchimento de alça de fio. Mudança é puramente CSS (uma
troca de `fill`/`stroke` na regra base), zero linha de TypeScript tocada nesta correção. Sem GUI
disponível neste ambiente pra confirmar visualmente; recomenda-se reabrir um esquemático com fios
roteados em L/Z e confirmar que nenhuma bola aparece até selecionar o fio.

## 19. "Recarregar Firmware" removido da UI -- recarga automática antes de "Run" (2026-07-09)

**Pedido**: o usuário não deveria precisar clicar manualmente em "Recarregar Firmware" (menu de
contexto, MCU direto ou exposto dentro de um subcircuito) toda vez que recompilava o `.bin` fora do
LasecSimul -- ver seção 8.3 (`FirmwareWatcher`) pra contexto: aquele mecanismo (Core, polling de
PASTA) foi ESPECIFICADO em 2026-06-28 mas **nunca chegou a ser ligado em lugar nenhum** (confirmado
de novo nesta sessão: `grep` por `FirmwareWatcher` fora de `FirmwareWatcher.{hpp,cpp}`/seu teste
próprio não acha nenhuma chamada -- zero uso em `QemuProcessManager`/`McuComponent`). A UI sempre
exigiu o clique manual documentado como "nunca deveria acontecer" -- a seção 8.3 descrevia uma
INTENÇÃO de design, não o comportamento real até esta sessão.

**Decisão de arquitetura**: em vez de finalmente ligar o `FirmwareWatcher` nativo (pasta + polling
contínuo, muito mais invasivo -- exigiria trocar o seletor de arquivo por seletor de PASTA, mexer em
`QemuProcessManager`, recompilar o Core), a recarga automática foi implementada na Extension, no
formato que o pedido descreveu (arquivo único escolhido pelo usuário, verificado só no momento de
"Run", não continuamente):

- `extension/src/mcu/mcuCommands.ts::ensureAllMcuFirmwareUpToDate` -- roda ANTES de toda "Run"
  (`extension.ts::runSimulationWithFirmwareCheck`, os dois pontos de entrada: mensagem
  `requestRunSimulation` da Webview E comando `lasecsimul.run`). Para cada MCU/CPU com
  `properties.firmwarePath` configurado (`collectMcuFirmwareTargets` -- direto, `mcuHost: true` no
  catálogo, OU exposto dentro de uma instância `subcircuit-file`, via
  `gatherInternalComponentSnapshots`): confirma que o arquivo existe (`fileExists`), lê `mtimeMs`/
  `size` (`fs.statSync`) e compara contra `state.ts::lastLoadedFirmwareByCoreId` (novo `Map`, chave =
  `instanceId` do Core, não `componentId` -- uma instância NOVA, criada por
  `rebuildCoreFromSchematicState`, nunca está no mapa, então sempre recebe o firmware pelo menos uma
  vez, mesmo no PRIMEIRO Run; uma instância que sobrevive a Parar/Rodar sem edição estrutural no meio
  mantém a marca e pula o push se nada mudou).
- Idêntico (mesmo, mesmo tamanho) → pula, não chama `loadMcuFirmware` de novo (sem reiniciar o
  processo QEMU à toa). Diferente ou nunca carregado → chama `loadMcuFirmware` (mesmo verbo IPC de
  sempre -- Core trata como reset, seção 8 item 10, nenhuma lógica nova nele) e atualiza o mapa.
  Arquivo ausente/inacessível OU a própria recarga falhando → devolve `{ok:false, message}`, o Run
  inteiro é abortado com `vscode.window.showErrorMessage`, nada roda com firmware potencialmente
  desatualizado.
- "Carregar firmware" (escolher um NOVO arquivo, ação que continua existindo -- só "Recarregar" foi
  removida) empurra imediatamente se a simulação já estiver rodando (comportamento pré-existente,
  inalterado) e agora também grava em `lastLoadedFirmwareByCoreId`
  (`mcuCommands.ts::recordFirmwareLoaded`) -- sem isto, trocar o firmware ao vivo e depois Parar/Rodar
  recarregaria o MESMO arquivo de novo à toa no próximo Run.
- Removido da UI: itens de menu "Recarregar firmware" (`main.ts`, topo E submenu de MCU exposto),
  mensagens `requestReloadMcuFirmware`/`requestReloadExposedMcuFirmware` (`messages.ts`), funções
  `reloadMcuFirmwareCommand`/`reloadExposedMcuFirmwareCommand` (`mcuCommands.ts`) -- sem substituto
  nem no menu nem em nenhum comando de paleta de comandos, a recarga não é mais uma ação que existe
  pro usuário disparar.

**O que NÃO mudou**: como o `.bin` é escolhido inicialmente ("Carregar firmware", ainda um seletor de
ARQUIVO único, não pasta -- diferente do `FirmwareWatcher` especificado, que assumia pasta de build
variável); o verbo IPC (`loadMcuFirmware`, mesmo path+`instanceId`); o efeito no Core (mesmo kill+
respawn de sempre). `FirmwareWatcher` (seção 8.3) permanece implementado e testado, porém morto --
não foi removido (nenhuma instrução pra isso), só continua sem nenhuma chamada real.

**Verificação**: compilação limpa (`tsc` main + webview + test) e suíte completa (154 testes) sem
regressão. Sem GUI disponível neste ambiente pra confirmar interativamente com um MCU real; a lógica
de dedup (mtime+tamanho, chave por `instanceId`) foi revisada por leitura, sem simulação numérica
dedicada (não há cálculo geométrico/matricial aqui pra valer a pena simular fora do DOM, diferente das
seções 17/18). Recomenda-se: escolher um `.bin`, rodar, recompilar o mesmo arquivo fora do LasecSimul,
rodar de novo (deve recarregar sozinho, sem clique manual) e rodar uma 3ª vez sem tocar no arquivo
(não deve reiniciar o processo QEMU).

## 20. Knob "Dial" -- porta fiel de `CustomDial::paintEvent` e correção dos dependentes (2026-07-09)

**Pedido**: o usuário identificou que SimulIDE tem um widget "Dial" reutilizado como base de vários
dispositivos (inclusive os knobs de ajuste do osciloscópio) e pediu uma porta fiel + atualização de
tudo que depende dele.

**Achado de arquitetura real (`gui/customdial.cpp`, `gui/dialwidget.cpp`, `gui/circuitwidget/
dialed.cpp`, `components/other/dial.cpp`, todos em `C:\SourceCode\simulide_2`)**: existem DOIS
"dials" diferentes no SimulIDE real, não um só --
1. **`CustomDial`** (`QDial` com `paintEvent` customizado, pintado à mão) -- base de `Dialed`,
   usado por `Dial` (`other.dial`), `Potentiometer`, `VarResBase`/`VarInductor`/`VarCapacitor`
   (resistor/indutor/capacitor variável) e o `SourceWidget` de fonte controlada. Geometria: arco de
   300° a partir de 240° (sem wrapping) ou 360° a partir de 270° (com wrapping); marcas de escala
   (contagem = `maximum/singleStep`, limitada a espaçamento mínimo de 4px, sempre par) com a
   PRIMEIRA sempre vermelha (referência de zero); gradiente radial quase-branco com centro
   deslocado pro canto superior-esquerdo (`0%→#fff, 80%→#e6e6e1, 83%→#dcdcd7, 100%→#c8c8c3`); nub de
   valor (halo + corpo, círculos concêntricos) que se move ao longo do arco via `ângulo(ratio) =
   ratio*spanDeg - startDeg` -- MESMA fórmula pras marcas E pro nub, nunca duas separadas.
2. **`QDial` nativo sem subclasse** -- usado SÓ pelos 4 knobs do osciloscópio/analisador lógico
   (`oscwidget.ui`/`lawidget.ui`: `timeDivDial`/`timePosDial`/`voltDivDial`/`voltPosDial`), chrome
   do próprio SO, sem paint customizado. `wrapping=true`, e o valor muda por DIREÇÃO relativa (~1%
   do valor atual por "clique" do encoder, `OscWidget::on_timeDivDial_valueChanged`) -- nunca por
   ângulo absoluto; não existe posição real pra refletir (µs↔s não cabe numa rotação fixa).

**Implementação** (`extension/src/ui/webview/componentSymbols.ts::dialKnobSvg`, antiga
`qDialKnobSvg` renomeada e reescrita): porta fiel da geometria de `CustomDial::paintEvent` acima,
parametrizada por raio total do widget + `ratio`/`wrapping`/`tickCount` opcionais. **Dois bugs reais
corrigidos na função antiga**: (a) fórmula das marcas usava `startDeg + spanDeg*i/n` (SEM o sinal
negativo de `painter.rotate(-startAngle)` do real) -- marcas ficavam sistematicamente fora de
posição; (b) o nub tinha uma fórmula TOTALMENTE separada, decorativa, sempre travado no meio do
curso -- as duas agora usam a mesma `ângulo(ratio) = ratio*spanDeg - startDeg`, verificada por
rederivação manual da matriz de rotação real do Qt (`painter.rotate()`, convenção Y-pra-baixo, mesma
já usada por `rotatePoint`/`svgBodyTransform` no resto do projeto).

**Dependentes atualizados**:
- `other.dial` (`componentSymbols.ts`): usa `dialKnobSvg` com `ratio: 0.5` (valor padrão real do
  `QDial` recém-criado, `setValue(500)` sobre range 0-1000) -- sem `properties` modeladas ainda
  nesta rodada (catálogo não declara min/max/valor), não há estado real além disso pra refletir.
  Comentário anterior ("widget do SO, não dá pra reproduzir em SVG") corrigido -- factualmente
  invertido, é o CONTRÁRIO que é verdade (`CustomDial` é pintado à mão pelo próprio SimulIDE, 100%
  reproduzível; é o `QDial` do osciloscópio que é nativo/não reproduzível com fidelidade 1:1).
- `passive.variable_resistor`/`variable_capacitor`/`variable_inductor` (`project/schema/
  component-catalog.json`, `viewSpec` declarativo dos 3, blocos idênticos): gradiente corrigido
  pros stops reais (`0/80/83/100%`, antes `0/55/100%` com cores mais escuras/erradas); nub ganhou o
  halo que faltava (2º `<ellipse>` sem preenchimento, MESMO `partId: "dialIndicator"` do nub
  original -- `viewSpecResolvedProjection` (`componentSymbols.ts:734`) é chamada POR FORMA, não uma
  vez por `partId` único, então múltiplas formas com o mesmo `partId` recebem a MESMA projeção
  computada e se movem juntas em sincronia, verificado por leitura antes de aplicar). Interação/
  hit-test/limites (`dragAngular`, `stepsPerRev`, `-150°..150°`) intocados -- zero risco à
  funcionalidade já testada (`ViewSpec rotate aceita propRange/angleRange para Dialed contínuo`).
  Marcas de escala (ticks) NÃO adicionadas nesta rodada -- exigiriam enumerar ~15-20 formas de linha
  à mão por componente (`ComponentViewSpec.paint` usa `PackageShape[]`, sem a primitiva `repeat` que
  `simulidePaint.primitives[]` tem); risco/esforço vs. ganho visual não pareceu valer nesta rodada,
  registrado como pendência.
- Knobs do osciloscópio/analisador lógico (`main.ts::makeKnobRow`): trocado o círculo CSS estático
  (gradiente + entalhe fixo que nunca girava) pelo `dialKnobSvg` real, com `wrapping: true` (igual
  ao `QDial` real desses 4 controles). Como o valor NÃO mapeia pra ângulo absoluto (ver ponto 2
  acima), o nub gira por um contador de posição PRÓPRIO (`knobDialPositions`, módulo-level, mesmo
  modelo 0-1000 do `QDial` interno real) incrementado a cada interação (roda do mouse/arrasto) --
  puramente feedback visual de "girei o botão", nunca uma representação do valor físico (µs↔s não
  caberia numa posição fixa sem pular loucamente a cada refresh). Interação real (wheel/drag
  ajustando o spinner numérico ao lado) inalterada.

**Verificação**: compilação limpa (`tsc` main + webview + test) e suíte completa (154 testes) sem
regressão, incluindo os 2 testes existentes que cobrem os 3 componentes `viewSpec.dial`
(`ViewSpec overlayPaint desenha dial por cima de simulidePaint`, `ViewSpec rotate aceita propRange/
angleRange para Dialed contínuo`) -- nenhum deles asserta contagem exata de `stops`/formas do nub, o
que teria quebrado com estas mudanças se fosse o caso. Fórmula angular verificada por rederivação
manual da matriz de rotação (não simulação numérica automatizada desta vez -- ver seções 17/18 pro
padrão quando compensa). Sem GUI disponível neste ambiente pra confirmar visualmente; recomenda-se
abrir um `other.dial`, um resistor/indutor/capacitor variável (arrastar o knob, confirmar que ainda
ajusta o valor normalmente) e a janela "Expande" do osciloscópio, e comparar visualmente com o
`CustomDial` real do SimulIDE.

**Errata visual do `CustomButton` (2026-07-13)**: `CustomButton::paintEvent()` configura um `QPen`
escuro e chama `QPainter::drawText`; isso colore os glifos, não cria contorno. Na tradução SVG, o
grupo `.meter-expand-button` MUST ser somente hit-target/cursor e MUST NOT declarar `fill`/`stroke`
herdáveis. O `<text>` MUST usar `stroke="none"`. Bordas e gradiente pertencem exclusivamente aos
retângulos do botão. Aplicar `stroke:#999` ao grupo produz texto duplo/borrado em qualquer DPI.

## 21. Bug corrigido: corpo do símbolo deslocado, desconectado dos pinos (2026-07-10)

**Sintoma relatado**: depois de adicionar o dial ao Potenciômetro (seção 20), o usuário reportou
"resíduo" -- na verdade era o corpo INTEIRO (dial, retângulo, fio do cursor) desenhado ~16 unidades
deslocado dos 3 pinos, restos "flutuando" desconectados na tela.

**Causa raiz** (`extension/src/ui/webview/componentSymbols.ts`): todo `package` com `simulidePaint`
passa por DOIS deslocamentos que deveriam ser UM só:
1. `simulidePaintToPackageShapes`/`transformFor` (`simulidePaint.ts`) já desloca coordenadas locais
   do `QPainter` (`bounds.x`/`bounds.y`, tipicamente negativas) pro espaço positivo da caixa.
2. `packageSymbolSvg` (`componentSymbols.ts:1107`) SEMPRE envolve o corpo inteiro num
   `<g transform="translate(offsetX,offsetY)">`, onde `offsetX/Y` vem de `resolvePackageLayout`
   (baseado na extensão real dos PINOS, não do `simulidePaint`).

Pra QUALQUER `typeId` cujos pinos usam coordenada "local" (mesmo espaço negativo do `simulidePaint`,
ex: `active.diode` pino ânodo em `x:-10`, espelhando `bounds.x:-10`) em vez de já-no-espaço-da-caixa
(convenção usada por `passive.variable_resistor`/`sources.voltage_source`/etc, pinos sempre ≥0), o
passo 2 RECALCULA `offsetX` a partir do próprio pino negativo -- deslocando o corpo (que o passo 1 JÁ
tinha posicionado certo) uma SEGUNDA vez pela MESMA quantidade. Pinos (que não passam pelo passo 1)
recebem só o deslocamento certo (passo 2) -- resultado: corpo e pinos acabam em referenciais
diferentes, sempre que `offsetX`/`offsetY` calculado a partir dos pinos for diferente de zero.

**Por que só apareceu agora**: o Potenciômetro sempre teve esse bug (`pin-1.x: -11`, deslocamento de
16 unidades) -- só nunca foi notado porque, sem o dial novo pra comparar, um retângulo cinza
levemente deslocado passava despercebido. Auditando TODOS os `typeId` com `simulidePaint` (medindo o
`translate(...)` real de cada um via script), achei **19 suspeitos** por terem caixa calculada maior
que a declarada -- sinal AMBÍGUO por si só (folga de lead também aumenta a caixa, de propósito).
Renderizando cada um por completo, confirmei **17 com o bug de verdade** (corpo genuinamente
desconectado dos pinos: `active.diode`/`zener`, `active.opamp`/`comparator`, `active.volt_regulator`,
`outputs.led`/`led_rgb`/`seven_segment`/`dc_motor`/`stepper`/`incandescent_lamp`,
`connectors.socket`/`header`, `passive.resistor_dip`, `passive.potentiometer` -- e **2 falsos
positivos** (`switches.keypad`, `meters.probe`, offset já `0` -- caixa maior só por folga de lead
mesmo, não bug).

**Errata normativa (2026-07-13)**: a correção descrita originalmente abaixo como “estratégia A/B”
era um workaround por componente e está **revogada** pela convenção única da seção 13.1.1. Não se
deve deslocar manualmente `pin.x/y`, zerar `simulidePaint.bounds.x/y` nem medir um `translate(...)`
particular para fazer corpo e terminais coincidirem.

Pacotes portados de `paint()` usam `coordinateSpace: "simulide-local"`: primitivas, pinos, labels e
contatos permanecem nos `QPoint/QRect m_area` originais, e o renderer normaliza todos uma única vez
usando `simulidePaint.bounds`. A folga dos terminais é consequência geométrica desses mesmos pontos,
não uma margem criada por teste ou por offset. `outputs.led_matrix`, `outputs.led_bar` e
`active.analog_mux` foram migrados para esse contrato; no mux, somente `z`/`en` são estáticos e os
endereços/canais vêm exclusivamente de `dynamicLayout.pinGroups`, eliminando a declaração duplicada.

O texto anterior desta seção permanece útil apenas como diagnóstico histórico da dupla translação.
Qualquer dado ou teste que exija as antigas estratégias A/B deve ser corrigido para a seção 13.1.1,
e não perpetuar a exceção.

## 22. Bloco genérico de subcircuito (`subcircuits.external`): vínculo pelo clique direito + forma
placeholder própria (2026-07-10)

**Contexto**: o bloco genérico "aponta pra `.lssubcircuit` por caminho" (seção do épico de
subcircuito por caminho, `extension.ts::chooseSubcircuitFileCommand`) tinha 2 problemas antes de
qualquer arquivo ser vinculado a ele.

**Problema 1 -- vínculo só pelo painel de propriedades**: o item de menu de contexto
"Localizar arquivo do subcircuito..." (`main.ts`, `subcircuitRefMenuItems`) só aparecia quando
`component.subcircuitRef` já existia -- ou seja, só depois de UMA vinculação anterior (mesmo que
quebrada, arquivo movido/apagado). Um bloco `subcircuits.external` recém-colocado, NUNCA vinculado
(sem `subcircuitRef` nenhum ainda), não tinha esse campo -- a única forma de escolher o
`.lssubcircuit` era abrir o painel de propriedades e achar o editor `filePath` da propriedade
"Arquivo do subcircuito". `chooseSubcircuitFileCommand` (`extension.ts:296`) já tratava os dois casos
igual (comentário próprio: "serve pra escolha inicial e pra 'relink'"), então bastou alargar a
condição do item de menu:
```ts
const subcircuitRefMenuItems: ContextMenuItem[] = !isGroup && (component.subcircuitRef || component.typeId === "subcircuits.external")
  ? [...]
  : [];
```
Nenhuma mudança no handler foi necessária -- ele já troca `typeId`/pinos/`package` da instância pro
do arquivo escolhido (`parsed.typeId`/`parsed.package`, ver seção 21 do
`.spec/lasecsimul-subcircuits.spec` referenciada no próprio comentário do handler), então a forma
final já reflete o conteúdo do `.lssubcircuit` normalmente -- isso nunca esteve quebrado, só o ponto
de entrada pelo clique direito é que faltava pro caso "ainda não vinculado".

**Problema 2 -- forma placeholder parecia um resistor**: a entrada de catálogo `subcircuits.external`
(`project/schema/component-catalog.json`) não declara `package` nenhum (forma só existe DEPOIS de
vinculado, injetada como catálogo efêmero pelo handler acima). Sem `package`, a renderização caía no
`default:` genérico de `componentSymbolSvg` (`componentSymbols.ts`) -- `horizontalLeads(box,yMid)` +
um retângulo fino de 20px de altura -- a MESMA composição (leads + corpo retangular fino) que dá a
silhueta de um resistor sem zigzag, numa caixa `DEFAULT_BOX` de 70x40. Corrigido com um `case`
dedicado pro typeId, igual ao padrão já usado por `other.test_unit`/`other.dial`:
- `builtinComponentBox`: `case "subcircuits.external": return { width: 56, height: 40 }` (retângulo
  "de tamanho médio" -- não os 70x40 do fallback genérico nem os 32x9 de um resistor real).
- `componentSymbolSvg`: `case "subcircuits.external"` desenha só
  `<rect x="2" y="2" width="52" height="36" rx="4" class="symbol-stroke" fill="none"/>` -- SEM leads
  (não há pino nenhum, `pinCount:0` no catálogo até ser vinculado), cantos arredondados pra
  diferenciar visualmente de qualquer corpo de componente real.

**Verificação**: compilação limpa (`tsc` webview + test) e suíte completa (154 testes) sem regressão.
Script Node ad-hoc chamando `componentBox`/`componentSymbolSvg` diretamente confirmou a caixa
`{width:56,height:40}` e o SVG exato do retângulo (sem leads, sem parecer resistor). Sem GUI
disponível neste ambiente; recomenda-se colocar um bloco "Subcircuit" novo no esquemático real,
confirmar visualmente o retângulo neutro, clicar com o botão direito nele (sem nenhum arquivo
vinculado ainda) e confirmar que "Localizar arquivo do subcircuito..." aparece e, ao escolher um
`.lssubcircuit`, a forma muda pra do arquivo escolhido.

## 23. Autoria visual de ícone (Figura) + Package do SimulIDE dentro de "Abrir Subcircuito"
(2026-07-10)

**Superseded em 2026-07-16**: todo o mecanismo descrito nesta seção (`other.package`/
`other.package_pin`/`packageIconRole`, `subcircuitPackageAuthoring.ts`) foi removido e substituído
por um modo de editor dedicado ("Símbolo"/"Ícone", `schemaVersion 3`) — ver
`.spec/lasecsimul-subcircuits.spec` seção 22 pro modelo atual. Registro histórico mantido abaixo.

Detalhamento completo (histórico) em `.spec/lasecsimul-subcircuits.spec` seção 17 (conceito de `SubPackage`/
`PackagePin` do SimulIDE real, distinção Figura×Package, formato de persistência, vínculo
pino↔túnel, migração/compat, decisão de estender a arquitetura atual em vez de restaurar a antiga).
Resumo: dentro da MESMA cena já usada pra editar o circuito interno de um subcircuito (seção 16 do
spec de subcircuitos, nenhum editor/modo novo), passou a ser possível colocar `other.package`/
`other.package_pin` (typeIds já existentes no catálogo, antes código morto sem compilador nenhum) +
UMA instância de `graphics.image` marcada como ícone (`WebviewComponentModel.packageIconRole`) --
`extension/src/catalog/subcircuitPackageAuthoring.ts` (novo, `seedPackageAuthoringComponents`/
`compilePackageAuthoringComponents`, puro/testável sem DOM) materializa esses componentes ao abrir a
sessão e compila de volta pra `package`/`interface[]` ao salvar, validando ANTES de qualquer escrita
em disco (pinId/vínculo de túnel duplicado, Package/ícone duplicado = erro bloqueante; pino sem
túnel = excluído + aviso). Vínculo pino↔túnel agora usa `interface[].internalTunnelId` (id ESTÁVEL do
componente-túnel) como fonte de verdade -- `internalTunnel` (nome, exigido pelo Core) é re-derivado
automaticamente a cada save, corrigindo o problema de quebrar ao renomear um túnel. Pré-requisitos
implementados junto: `graphics.image` ganhou `width`/`height` reais e passou a renderizar a imagem de
verdade (antes só um glifo decorativo); o editor de propriedade `filePath` foi generalizado pra
qualquer campo (antes hard-coded só pro bloco genérico de subcircuito).

**Verificação**: compilação limpa e suíte completa (168 testes: 154 anteriores + 14 novos de
`subcircuitPackageAuthoring.test.ts`) sem regressão. Sem GUI disponível neste ambiente pra confirmar
drag visual de pino/menu "Vincular a túnel..."/copiar-colar pela UI real -- recomenda-se verificação
manual no VSCode real (ver seção 17.7 do spec de subcircuitos pro roteiro completo).

## 24. Reconstrução do sistema de fios/junções: grafo de topologia canônico, transação atômica no
Core, `connectors.junction` removido (2026-07-11)

Decisão de arquitetura tomada a partir de `docs/auditoria-tecnica-fios-simulide-2026-07-11.md`
(auditoria técnica comparando a implementação de fios/junções do LasecSimul contra o SimulIDE-dev
real) -- **Alternativa D** da auditoria (reconstruir a cadeia, por substituição controlada e
fatiada, sem adaptador legado permanente), executada por partes: kernel de topologia + transação
atômica no Core + índice espacial + persistência v2. Não implementado (deliberadamente fora de
escopo desta rodada, ver seção 24.5): Command Bus/FSM explícito e documento canônico headless como
camada separada -- o mesmo efeito (nenhuma mutação de modelo/Core até o gesto terminar, transação
atômica, sem resíduo em cancelamento) foi alcançado direto em `extension.ts`/`main.ts` sem introduzir
essa camada nova.

### 24.1 Junção deixa de ser um `IComponentModel` do Core

`connectors.junction` (`core/src/components/connectors/Junction.hpp`) foi **removido por inteiro** --
não existe mais fábrica registrada em `CoreApplication.cpp::registerBuiltinComponents`. Uma junção de
grau N (T, cruzamento com derivação, etc.) nunca mais chega ao Core como um componente de 1 pino; em
vez disso, ela é **achatada** numa árvore de N-1 arestas porta-a-porta ANTES de o Core ver qualquer
coisa -- o Core só enxerga `IComponentModel`s reais conectados diretamente entre si. Dois lugares
independentes fazem essa mesma transformação, cada um no seu domínio:

- **Projeto principal** (Webview/Extension host): `electricalEdgesForProject`
  (`extension/src/core/coreLifecycle.ts`) -- percorre `wires[]` + `topologyNodes[]`, decompõe em
  redes conexas por BFS, e para cada rede emite N-1 arestas entre os pinos de componente REAIS
  daquela rede (ignorando os nós de topologia como vértices de passagem). Usado por
  `rebuildCoreFromSchematicStateNow` (rebuild completo) -- o Core nunca recebe um nó de topologia
  como endpoint de `connectWire`.
- **Subcircuitos** (`.lssubcircuit`, Core): mesmo algoritmo, dentro do próprio Core, em
  `CoreApplication.cpp::registerSubcircuitFromManifestRich` -- decompõe `topologyNodeIds` (ver 24.4)
  + `def.wires` num grafo de adjacência, faz BFS por rede, emite N-1 arestas entre portas reais.
  Comentário no código: "Junction é sintaxe topológica do arquivo, nunca componente de simulação."

Consequência prática: `connectors.bus` (que reusava a classe `Junction` como implementação) passou a
usar `SimulidePassiveState` com o mesmo pino único -- mesmo comportamento elétrico (nó de
passagem), sem depender da classe removida.

### 24.2 Webview/host: `topologyNodes` substitui a junção-como-componente-oculto no caminho vivo

`WebviewProjectState`/`schematicState` ganhou um array paralelo, `topologyNodes: Array<{id, x, y}>`,
separado de `components`/`wires`. Um nó de topologia (T, cruzamento com derivação) vive **só** nesse
array -- nunca mais nasce como `WebviewComponentModel{typeId: "connectors.junction", hidden: true}`
no caminho de edição vivo. `JUNCTION_TYPE_ID` (`model.ts`) continua existindo só como forma de
projeção legada usada nas bordas (ver 24.6).

`extension/src/ui/webview/topologyDocument.ts` (novo) define um documento canônico
(`CanonicalTopologyDocument{revision, nodes[], conductors[]}`, endpoints
`{kind:"port",componentId,pinId}|{kind:"node",nodeId}`) com validação de invariantes
(`assertTopologyInvariants` -- nó/condutor duplicado, endpoint órfão, condutor de comprimento
topológico zero, vértices duplicados). **Não é o modelo de edição vivo** -- é usado só nas bordas
(persistência, seção 24.6; rebuild do Core) como ponte determinística entre o par
`components+wires+topologyNodes` (formato vivo) e o par `topology{nodes,conductors}` (formato
canônico/persistido). O comentário no código chama isso explicitamente de "ponte determinística
temporária".

### 24.3 IPC: transação atômica de fio + revisão otimista

Novo verbo `applyWireTopologyTransaction` (`CoreApplication.cpp`, handler `msg.type ==
"applyWireTopologyTransaction"`; `SimulationSession::applyWireTopologyTransaction`,
`SimulationSession.hpp/cpp`): aplica um lote de operações `connect`/`disconnect` como uma única
mutação observável. `baseRevision` precisa bater com `SimulationSession::wireTopologyRevision()`
(contador incrementado a cada `connectWire`/`disconnectWire`/transação bem-sucedida) -- divergência
lança `topology_revision_conflict` sem tocar em nada. Internamente, a transação faz uma cópia barata
do `Netlist` (staging), aplica cada operação, e se qualquer uma falhar restaura `Netlist`/
`m_topologyDirty`/`m_wireTopologyRevision` para o estado anterior por inteiro -- nunca deixa o Core
com metade das arestas aplicadas. `connectWire`/`disconnectWire` (verbos IPC já existentes) passaram
a devolver `topologyRevision` na resposta também, e resolvem pino por id exato primeiro, com
fallback posicional `pin-N` (`resolveSlot` em `SimulationSession::connectWire`) para arquivos de
autoria antigos/packages genéricos.

Do lado da Extension: `CoreClient.applyWireTopologyTransaction` (`ipc/CoreClient.ts`) guarda
`wireTopologyRevision` localmente, atualizado a cada resposta; `pushWireTopologyTransaction`
(`coreLifecycle.ts`) resolve `componentId` webview -> `instanceId` Core e chama o verbo. Usado em
`syncProjectSnapshotToCore` (`extension.ts`) quando só endpoints de fio mudaram (sem nó de topologia
envolvido) -- substitui o antigo padrão de mandar `connectWire`/`disconnectWire` um a um sem garantia
de atomicidade entre eles.

### 24.4 Verbos antigos removidos: gesto vira transação, split para de ser commitado cedo

`requestConnectPins`/`requestConnectPinToWire` (mensagens Webview->Host) foram **removidos**, junto
com `wireConnections.ts` (arquivo inteiro deletado -- `buildPinToPinWire`/`buildPinToWireConnection`).
Substituídos por um único verbo, `requestConnectEndpoints`, carregando `baseRevision`
(`state.schematicState.topologyRevision`) -- se o host detecta que o cliente trabalhou sobre uma
revisão desatualizada, republica o estado canônico via `syncState` completo em vez de tentar mesclar
por heurística (`extension.ts`, handler `"requestConnectEndpoints"`). A computação pura de split/
reuso de junção existente vive em `connectEndpointToNode` (`wireTopology.ts`), que devolve
`newNodes`/`newWires`/`replacedWireIds` -- o host aplica o resultado ao `schematicState`, dispara
`queueCoreRebuild()` uma vez, e só publica a `syncState` nova depois do Core confirmar (rollback pro
estado anterior se o rebuild falhar).

**Bug histórico corrigido (o mais citado na auditoria)**: `requestStartWireFromWire` (iniciar uma
derivação clicando no MEIO de um fio já existente) deixou de fazer split/criar junção/tocar no Core
nesse momento -- é um DRAFT PURO (`pendingConnection: {kind:"wire", wireId, point}`), sem nenhuma
mutação de modelo. Esc, botão direito ou trocar de ferramenta simplesmente limpam
`pendingConnection` sem deixar nenhum resíduo (nem no Core, nem em `components`/`wires`). O split/
criação de nó só acontece quando o gesto de fato termina em outro ponto, dentro do mesmo
`requestConnectEndpoints` transacional acima.

### 24.5 `Netlist::rebuildTopology`: full-rebuild continua sendo o único oracle (decisão revertida)

Uma otimização de cache incremental de conectividade dentro de `Netlist` (union-find comprimido
reaproveitado entre chamadas, com invalidação por slot dirty) foi implementada, testada
(diferencial de 250 mutações aleatórias contra um `Netlist` de referência, mais um teste dedicado de
contagem de slots revisitados) e **revertida no mesmo dia** -- risco de correção desproporcional ao
ganho: união via union-find não é uma operação desfazível (remover uma aresta pode precisar separar
nós que estavam fundidos; renomear um túnel idem), e um cache incremental hand-rolled é uma
superfície de bug sutil bem maior que o benefício, considerando que:

- `rebuildTopology()` já só roda quando `m_topologyDirty` está setado
  (`SimulationSession::rebuildTopologyIfNeeded`, `SimulationSession.cpp:450`) -- ou seja, "um rebuild
  por lote de edição" já é garantido de graça pelo gate existente, com ou sem cache incremental
  dentro do `Netlist`; o cache só ajudaria no caso estreito de múltiplos ciclos dirty consecutivos
  com pouca mudança entre eles.
- Componentes ativos/não-lineares podem precisar de reestabilização completa depois de qualquer
  mudança estrutural -- `core/test/diode_test.cpp` ganhou um teste de regressão específico (settle
  de uma rede com diodo depois de um split/restauração via `applyWireTopologyTransaction`) que
  travava com o cache incremental.

`Netlist::rebuildTopology` (`core/src/simulation/Netlist.hpp`) permanece um union-find puro,
recalculado do zero a cada chamada -- documentado no comentário de classe como "sempre do zero --
nunca incremental" com a justificativa acima.

O reaproveitamento seletivo posterior é descrito em 25.5. Ele não altera este contrato: o grafo é
sempre reconstruído integralmente; somente matrizes de ilhas lineares comprovadamente idênticas
podem sobreviver, e apenas depois de uma adição pura de aresta.

### 24.6 Persistência `.lsproj` v2: `topology{revision,nodes,conductors}` substitui `wires[]`

`ProjectTypes.ts::LS_PROJ_SCHEMA_VERSION` subiu de 1 para 2. `ProjectDocument.topology`
(`ProjectTopology{revision, nodes[], conductors[]}`, mesmo formato do `CanonicalTopologyDocument` da
seção 24.2) é agora **obrigatório** e é a fonte de verdade gravada em disco -- `ProjectSerializer.save`
não grava mais `wires[]` nem `visual.wires`/`visual.components` (só `visual.viewport`).
`ProjectSerializer.load` valida `topology` (`validateTopology`, endpoints tipados, nó/condutor
duplicado, referência a componente/nó inexistente) e deriva `wires[]` em memória só como projeção de
compatibilidade interna (não persistida). **Sem adaptador de leitura pra `schemaVersion` 1** -- um
`.lsproj` antigo sem bloco `topology` falha ao carregar (consistente com a política do projeto de
não manter compat retroativa preventiva, ver seção sobre isso mais adiante neste documento).
`project/schema/lsproj.schema.json` foi atualizado pra `schemaVersion: {const: 2}` + bloco `topology`
+ `visual` só com `viewport` obrigatório (documentação/referência -- nada no código valida
runtime contra este arquivo hoje, `ProjectSerializer.ts` tem sua própria validação manual).

O mesmo formato `topology{...}` substitui `wires[]` dentro de `.lssubcircuit` também --
`.spec/lasecsimul-subcircuits.spec` seção 19 tem o contrato completo (parsing no Core, achatamento de
junção, e uma regressão real encontrada/corrigida num parser de teste duplicado).

### 24.7 Índice espacial de fios (`WireSpatialIndex`)

`extension/src/ui/webview/wireSpatialIndex.ts` (novo) -- spatial hash mutável (`cellSize` padrão 64),
`upsertWire`/`removeWire` O(células tocadas), `queryPoint`/`queryConnectionPoints` idem. Integrado em
`wireTopology.ts::findAtPosition`/`buildWireSpatialIndex` (índice opcional -- sem ele, cai pro scan
linear anterior, usado só nos testes puros que não montam um índice) e mantido incrementalmente no
`render()` de `main.ts` (`wireSpatialIndex.upsertWire` só quando a polilinha de um fio muda de
verdade, comparado por assinatura de pontos) -- usado tanto pro hit-test de clique quanto por
`maybeAutoJunctionForDraggedComponents` (consulta `queryPoint` pra detectar overlap pino-sobre-fio
depois de arrastar um componente).

### 24.8 Regressão encontrada e corrigida: parser de teste duplicado não migrado

`core/test/esp32_devkitc_subcircuit_test.cpp` mantém propositalmente um `parseLssubJson` PRÓPRIO,
independente de `CoreApplication.cpp` (comentário no código: "mesmo mapeamento de campos... mantido
em sincronia manualmente"). Ao migrar `subcircuits/esp32_devkitc_v4.lssubcircuit` pro formato
`topology{...}` (seção 24.6), esse parser de teste NÃO foi atualizado -- continuou lendo
`manifest["wires"]`, chave que o arquivo migrado não tem mais, resultando em **zero fios**
registrados silenciosamente (só os nós unidos por `connectors.tunnel`, que não depende de `wires[]`,
sobreviviam). Sintoma: `ctest` reportando `esp32_devkitc_subcircuit` falho, com várias tensões de
rede (3V3/5V/EN) caindo pra 0V por sistema singular. Corrigido replicando a mesma branch
`canonicalTopology` de `CoreApplication.cpp` neste parser de teste. Um segundo problema, encontrado
na mesma investigação e não relacionado à migração: o teste só dava 5 iterações de
`session.settleStep()` antes de ler tensão -- suficiente com a topologia antiga (efetivamente vazia),
insuficiente para o circuito real totalmente conectado; aumentado para 200 (mesma ordem de grandeza
de `diode_test.cpp::settleWithin`). Lição: qualquer teste que reimplemente parsing de manifesto por
razões de isolamento precisa ser tratado como uma segunda fonte de verdade que PODE divergir -- exatamente
o débito "regras diferentes entre serializers/loaders" que a auditoria já apontava (seção de débitos
técnicos, `docs/auditoria-tecnica-fios-simulide-2026-07-11.md`), reproduzido de novo dentro da própria
correção.

## 25. Roteamento de edição de fio pela transação atômica + FSM leve + validação de invariante em
toda edição (2026-07-11, plano em `docs/27-analise-critica-fios-vs-auditoria-2026-07-11.md`)

Continuação direta da seção 24 -- a análise crítica em `docs/27-...` achou que
`applyWireTopologyTransaction` (24.3) ficava **inatingível na prática** assim que um projeto tinha
qualquer nó de topologia, porque `syncProjectSnapshotToCore`/`requestConnectEndpoints` sempre caíam
em `queueCoreRebuild()` (full teardown+recreate sequencial, O(componentes+fios) round-trips de IPC)
pra esse caso -- o caminho DEFAULT de qualquer edição de fio num circuito real, não uma exceção. Esta
seção fecha essa lacuna.

### 25.1 EX-F: diff de arestas achatadas substitui full-rebuild como caminho default

`electricalEdgesForProject`/`diffElectricalEdges` (movidos de `coreLifecycle.ts` pra
`wireTopology.ts` -- são funções puras, cabem na "fonte única de verdade" que o arquivo já é;
`coreLifecycle.ts` reexporta pra não quebrar import site nenhum) -- o diff compara duas listas JÁ
ACHATADAS (saída de `electricalEdgesForProject`, antes/depois) por identidade de PAR DE PINOS REAIS
(chave `componentId::pinId`, ordem-independente), nunca por id sintético (`electrical-N` muda de
índice a cada chamada). Como o achatamento é determinístico por rede não tocada, o diff fica
naturalmente restrito à(s) rede(s) que a edição de fato afetou -- **não precisa de um algoritmo
incremental à parte**, só recomputar a árvore inteira duas vezes (barato, é um BFS em memória) e
comparar os dois conjuntos resultantes.

Roteamento atualizado:
- `syncProjectSnapshotToCore` (`extension.ts`): a antiga condição "há nó de topologia E (geometria OU
  componente mudou) → `queueCoreRebuild()`" virou duas condições separadas -- `componentSetChanged`
  continua indo pro rebuild completo (registrar/desregistrar instância Core exige isso mesmo);
  só-topologia-mudou agora usa o diff achatado + `pushWireTopologyTransaction`.
- `requestConnectEndpoints`: nunca muda o CONJUNTO de componentes (só fios/nós) -- sempre usa o diff
  achatado agora; `queueCoreRebuild()` fica reservado pra quando a transação é rejeitada (conflito de
  revisão etc.), não mais o caminho feliz.
- `requestRemoveWire`/`requestRemoveComponent`: mesmo diff achatado. Para remoção de COMPONENTE, o
  "antes" achatado é computado sobre `afterRemoval.wires` (já excluindo os fios que tocavam o
  componente removido) -- nunca sobre a lista completa anterior, porque o Core já desconectou esses
  fios sozinho dentro de `Netlist::removeComponent` (`pushRemoveToCore` já rodou); incluir esses
  endpoints no diff falharia a resolver `coreInstanceIdByComponentId` (mapeamento já apagado) e
  derrubaria a transação inteira à toa.
- `pushWireTopologyTransaction` (`coreLifecycle.ts`) passou a capturar qualquer exceção internamente
  (inclusive `topology_revision_conflict`) e devolver `false` -- nenhum chamador precisa mais de
  try/catch próprio pra tratar rejeição de transação; todos caem no mesmo padrão "`if (!applied) await
  queueCoreRebuild()`".

**Correção não é garantida ser mínima, só é garantida ser correta**: se a inserção de uma porta nova
muda qual porta é escolhida como raiz da estrela do achatamento, o diff pode incluir mais
`connect`/`disconnect` do que o estritamente necessário (a rede inteira "reconecta" em vez de só o
ramo novo) -- mas o resultado final é sempre eletricamente equivalente. Testado explicitamente:
`wireTopology.test.ts` ("root da estrela muda de porta -- diff ainda cobre a rede inteira
corretamente"), que reconstrói a rede a partir do diff e confere via union-find que nenhuma
conectividade se perde, mesmo no pior caso.

**Testes de regressão** (`wireTopology.test.ts`, 5 casos novos): sem nó (1 aresta por fio), T de 3
ramos achata em N-1 sem nunca referenciar o nó, adicionar um ramo gera só 1 `connect` e não toca rede
não relacionada, colapso de nó grau-2 em fio direto não gera operação nenhuma (já é a mesma aresta),
e o caso de troca de raiz acima.

### 25.2 FSM leve: ferramentas de fio e posicionamento de componente nunca mais coexistem

Achado real na análise (`docs/27-...`, seção "Análise da FSM"): `enterPlacementMode()` não verificava
`state.pendingConnection`, e o handler de Esc tinha um `return` antecipado que, com os dois estados
combinados, só cancelava um dos dois -- exigia um SEGUNDO Esc. Investigação mais funda durante a
correção achou mais 3 pontos com a MESMA classe de bug (clique em alça de canto de fio, clique em
alça de segmento de fio, clique em pino -- todos os três chamam `stopPropagation()`, então nunca
delegavam a decisão pro handler de fundo do canvas que já tratava `placingTypeId`).

Correção: dois funis únicos de entrada (`extension/src/ui/webview/main.ts`) --
`beginWireDraft(origin)` (cancela posicionamento de componente ativo antes de armar um draft de fio)
e `enterPlacementMode(typeId)` (cancela draft de fio ativo antes de entrar em posicionamento) -- e um
funil único de saída, `cancelActiveTool()` (chamado por Esc, incondicional, sem `return` antecipado
escondendo o segundo caso). Os 4 pontos de entrada adicionais (clique em pino, canto, segmento,
botão-direito-no-canvas) ganharam a mesma guarda (`if (placingTypeId) return;` logo após
`stopPropagation()` -- clique é descartado, nunca inicia derivação por baixo da ferramenta ativa).

**Escopo deliberadamente contido**: não virou uma FSM formal genérica cobrindo TAMBÉM marquee-select
e arrasto de segmento/canto -- esses dois já são estruturalmente protegidos por `pointerCapture`
(exclusivos por construção dentro de um único gesto contínuo de ponteiro, não podem vazar pra outro
modo entre cliques discretos como `pendingConnection`/`placingTypeId` podiam). A correção mira
exatamente a classe de bug encontrada (estados que persistem ENTRE cliques discretos), não todo
estado de interação do editor.

### 25.3 Validação de invariante antes de commitar (não só em save/load)

`requestConnectEndpoints`/`requestRemoveWire`/`requestRemoveComponent` (`extension.ts`) passaram a
chamar `canonicalTopologyFromLegacy(...)` (que já roda `assertTopologyInvariants` como efeito
colateral, `topologyDocument.ts`) sobre o resultado ANTES de commitar em `state.schematicState` --
descarta o documento canônico resultante, só a validação importa aqui. Duas políticas diferentes
deliberadas:
- `requestConnectEndpoints`: falha BLOQUEIA a mutação (`return` antes de tocar `state.schematicState`)
  -- nada irreversível aconteceu ainda no Core nesse ponto, seguro rejeitar.
- `requestRemoveWire`/`requestRemoveComponent`: falha só AVISA (`reportCoreWarning`, sem `return`) --
  pra remoção de componente, o Core já processou `pushRemoveToCore` antes desse ponto (irreversível);
  bloquear a atualização do lado Webview deixaria os dois lados mais divergentes, não menos.

### 25.4 Consolidação parcial (não a migração completa pro modelo canônico vivo)

A análise recomendava (seção "Recomendação arquitetural") promover `CanonicalTopologyDocument` a
modelo vivo por inteiro -- `WebviewWireModel.from/to` virando `CanonicalEndpoint`
(`{kind:"port"|"node",...}`) em vez de `{componentId,pinId}` plano, e `state.wires`/`state.topologyNodes`
virando um único `state.topology`. Avaliado nesta rodada e **conscientemente não executado por
inteiro**: essa retipagem tocaria centenas de call sites em `main.ts` (render, hit-test, drag,
undo/redo) que hoje assumem endpoint plano, sem nenhuma cobertura de teste de GUI possível neste
ambiente pra confirmar visualmente que nada quebrou -- risco desproporcional ao ganho, que é de
manutenção futura (a duplicação hoje é gerenciável, não um bug ativo), não de correção presente.

O que FOI feito desta frente, com risco baixo e valor real e verificável: consolidado
`main.ts::wirePolylinePoints` (chamado em TODO `render()`, hot path) pra delegar em
`wireTopology.ts::pinScenePosition` em vez de reimplementar a distinção porta-vs-nó pela terceira vez
no projeto (as outras duas cópias já reduzidas a `Set.has()` de uma linha em
`electricalEdgesForProject`/`voltageProbesForProject`, risco de divergência bem menor que uma função
inteira duplicada). `topologyNodes` continua um array paralelo a `wires`; `topologyDocument.ts`
continua sendo ponte de borda -- ambos permanecem trabalho futuro caso uma feature nova (barramentos
tipados, rótulo de rede) force a mão, não uma dívida bloqueante hoje.

**Verificação**: suíte completa da Extension (223 casos, incluindo os 5 novos de 25.1) e suíte
completa do Core (36/36) sem regressão. Sem GUI disponível neste ambiente pra confirmar
interativamente os 6 pontos de FSM corrigidos (25.2) nem o comportamento visual do roteamento novo
(25.1) -- ambos verificados por rastreamento direto de código + testes puros onde o código é
testável; recomenda-se sessão manual no VSCode real cobrindo exatamente os 6 cenários de estado
combinado desta seção antes de considerar 25.2 encerrado.

**SUPERSEDIDO pela seção 25.6**: a decisão de escopo contido acima (não retipar
`WebviewWireModel.from/to`, não unificar `state.wires`/`state.topologyNodes`) foi revisada na mesma
sessão seguinte -- decisão explícita de que tamanho de mudança não é critério negativo por si só, só
qualidade técnica/funcional do resultado. A migração completa foi feita; ver 25.6.

### 25.5 Core: `reuseUnaffectedCircuitGroups` -- não marca todo componente vivo como dirty a cada
rebuild de topologia (2026-07-11)

Lacuna deixada explícita em 25.1 como conhecida, não escondida: `rebuildTopologyIfNeeded()`
(`SimulationSession.cpp`) reconstruía a topologia inteira do zero a cada mudança (correto, união não é
desfazível -- ver `Netlist.hpp`), mas depois marcava **todo componente vivo** como dirty,
independente de estar ou não na rede afetada -- efeito prático: editar um fio em QUALQUER lugar do
circuito re-estampava (e refatorava, se a admitância mudasse) TODOS os `CircuitGroup`, mesmo os de
redes eletricamente desconexas e intocadas. Maior retorno/menor risco que sobrava do plano original
de `docs/27-...`.

**Política de segurança (revisada em 2026-07-12)**: o reuso só é elegível quando a revisão
pendente contém exclusivamente adições de fio. Deleção, split, mudança de túnel, pinos,
componente ou propriedade topológica executa rebuild + restamp global. Grupos que contenham qualquer
`isNonlinear()` nunca são reaproveitados. O flag `m_topologyReuseSafe` acumula essa classificação
durante o lote e também participa do rollback transacional.

**Mecanismo**: `reuseUnaffectedCircuitGroups(previous, previousNodeVoltages)`, chamada de dentro de
`rebuildTopologyIfNeeded()` logo após o rebuild, compara a topologia ANTIGA (capturada por
`std::move` antes do rebuild) com a NOVA por **assinatura de grupo** (conjunto ordenado de
`componentIndex` vivos que caem em cada grupo). Grupo cujo conjunto de componentes bate dos dois
lados só é reaproveitado se, ALÉM disso, todo pino de todo membro cair no MESMO `localIndex` (linha/
coluna da matriz) nos dois lados -- conjunto de componentes igual não basta (A-B + B-C virar A-B +
B-C + A-C encolhe de 3 nós pra 2 sem o conjunto mudar, mas a fiação real mudou). Só quando as duas
condições batem, os vetores de índices globais de nó também precisam ser idênticos; então o
`CircuitGroup` antigo (com toda a estampa acumulada e a fatoração LU em cache) é
literalmente `std::move`ido pro slot do grupo novo, e SÓ os componentes de grupos NÃO reaproveitados
entram no `dirtySet()` do `Scheduler`.

Índices globais não são presumidos estáveis: uma fusão anterior na ordem de slots pode deslocar a
numeração densa de redes posteriores. Por isso `nodeIndices()` antigo e novo são comparados por
igualdade exata; qualquer deslocamento cai no restamp seguro.

**Bug real encontrado e corrigido durante a verificação** (não presumir "compilou, deve estar certo"
-- ver `[[feedback_review_build_and_test_before_reporting]]`): a primeira versão reaproveitava o
`CircuitGroup` corretamente, mas `rebuildTopologyIfNeeded()` continuava fazendo
`m_nodeVoltages.assign(novoTamanho, 0.0)` incondicionalmente pra TODO o array a cada rebuild.
`MnaSolver::solve()` pula grupo não-dirty (`if (!group.dirty()) continue;`, `MnaSolver.hpp`) -- um
grupo reaproveitado nunca é dirty (suas flags já estavam limpas desde a última solve antes do
rebuild), então nunca seria resolvido de novo, e sua leitura de tensão ficava travada em 0.0 pra
sempre (até a rede voltar a ficar dirty por outro motivo). Sintoma: `circuit_group_reuse_test`
(abaixo) falhava JÁ na primeira rodada -- ilha elétrica nunca tocada caía de 5V pra 0V assim que
QUALQUER outra rede do circuito era editada. Corrigido capturando
`previousNodeVoltages = std::move(m_nodeVoltages)` antes do reset e, dentro de
`reuseUnaffectedCircuitGroups`, copiando `previousNodeVoltages[nodeIndex]` pra
`m_nodeVoltages[nodeIndex]` de cada nó do grupo reaproveitado -- os índices são os mesmos dos dois
lados (parágrafo acima), então a cópia é direta, sem remapeamento.

**Teste de regressão**: `core/test/circuit_group_reuse_test.cpp` (novo, registrado em
`CMakeLists.txt` como `circuit_group_reuse`) -- duas ilhas elétricas independentes (divisores de
tensão), ilha 1 nunca tocada depois do settle inicial, ilha 2 editada 20 vezes seguidas (liga/desliga
um resistor em T). Cada rodada confere BIT-A-BIT que a tensão da ilha 1 não mudou (prova que
reaproveitamento não vaza estampa velha nem perde a tensão já resolvida) e que a ilha 2 continua
fisicamente correta pra topologia atual (prova que a rede que DEVERIA ser re-estampada foi).

**Verificação**: suíte completa do Core, 37/37 (36 anteriores + `circuit_group_reuse`).

### 25.6 Fase C completa: `CanonicalEndpoint` promovido a modelo vivo único (2026-07-11)

Revisão da decisão de escopo contido em 25.4 (marcada como superseded acima) -- instrução explícita
de que tamanho de refatoração não é critério negativo por si só, só qualidade técnica/funcional do
resultado. Migração completa executada nesta sessão:

- `WebviewWireModel.from`/`.to`: de `{componentId, pinId}` plano pra `CanonicalEndpoint`
  (`{kind:"port", componentId, pinId} | {kind:"node", nodeId}`, `model.ts`) -- elimina a suposição
  implícita de que nó de topologia e componente real compartilhavam o mesmo espaço de string por
  convenção (`componentId` de um endpoint-nó era na verdade um `nodeId`).
- `WebviewProjectState`: campos separados `wires[]`/`topologyNodes?[]`/`topologyRevision?` viram um
  único `topology: CanonicalTopologyDocument` (`{revision, nodes: TopologyNode[], conductors:
  WebviewWireModel[]}`) -- fonte única de verdade, viva E persistida (não existe mais um formato de
  runtime e outro de disco).
- Helpers centralizados em `model.ts` (`endpointId`, `endpointPinId`, `portEndpoint`, `nodeEndpoint`,
  `remapEndpoint`) substituem acesso direto a `.componentId`/`.pinId` em toda a base -- ponto único
  de verdade sobre "qual é o id/pino do outro lado deste endpoint", nunca reimplementado por chamador.
- `topologyDocument.ts`: as funções-ponte `canonicalTopologyFromLegacy`/`legacyTopologyFromCanonical`
  foram REMOVIDAS por inteiro (não fazem mais sentido -- não existe mais um lado "legado" separado
  pra converter). Arquivo ficou só com `assertTopologyInvariants`, operando nativamente sobre os tipos
  de `model.ts`.
- `wireTopology.ts` inteiro (todas as funções: `pinScenePosition`, `wirePolylinePoints`,
  `findExistingJunctionAt`, `findAtPosition`, `splitSegmentAtPoint`, `connectEndpointToNode`,
  `removeOrphanNodes`, `normalizeWireGeometry`, `rebuildElectricalNet`, `electricalEdgesForProject`,
  `diffElectricalEdges`) reescrito pra operar sobre `TopologyNode[]`/`CanonicalEndpoint` diretamente
  -- elimina todo tratamento de `JUNCTION_TYPE_ID` como se fosse um componente disfarçado dentro
  dessas funções (a distinção porta-vs-nó agora é o `kind` do endpoint, não uma checagem de typeId).
- `extension.ts::normalizeRuntimeTopology` (função-ponte que sintetizava componentes
  `connectors.junction` a partir de `topologyNodes[]` pros 3 call sites que ainda esperavam o formato
  antigo) foi DELETADA -- os 3 call sites chamam `normalizeWireGeometry` direto.
- `projectCommands.ts::importProjectCommand`: bug PRÉ-EXISTENTE encontrado e corrigido durante a
  migração -- nós de topologia importados eram silenciosamente descartados (só componentes/fios
  passavam por remapeamento de id); agora `remapEndpoint` também é aplicado aos nós.
- Todos os arquivos de teste (`topologyDocument.test.ts`, `wireTopology.test.ts` -- 34 casos,
  `junctionComponent()` substituído por `topologyNode()`+`nodeWire()`/`portWire()` --,
  `simulideSceneTranslator.test.ts`) reescritos pro novo shape.

**Verificação**: os 3 tsconfigs (`tsconfig.json`/`tsconfig.webview.json`/`tsconfig.test.json`)
compilam sem erro; suíte completa da Extension, 214/214 casos, 0 falhas.

### 25.7 Fase E: varredura de código morto -- conclusão é que não sobrou nada pra remover (2026-07-11)

Varredura final de referências a `JUNCTION_TYPE_ID` fora de teste, pra confirmar que a migração de
25.6 não deixou nenhum tratamento especial de "junção como componente" sobrevivendo por inércia.
Resultado, arquivo por arquivo -- todos os 6 usos são LEGÍTIMOS, nenhum removido:

- `subcircuitInternals.ts`/`extension.ts` (parsing de manifesto de subcircuito/device): NÃO é
  compat especulativa -- existem arquivos REAIS no repositório hoje ainda no formato antigo
  (`subcircuits/esp32_wroom32.lssubcircuit` usa `wires[]` direto, não `topology.conductors[]`; a
  grande maioria de `devices/*.lsdevice` idem) que o parser do Core (`parseLssubJson`,
  `esp32_devkitc_subcircuit_test.cpp`, mesma lógica de `CoreApplication.cpp`) também aceita via
  fallback deliberado, não removido. Testado e exercitado de verdade pelo teste
  `esp32_devkitc_subcircuit` (carrega os DOIS arquivos, migrado e não-migrado, no mesmo run).
- `extension.ts:677` (`requestAddComponent`): defesa em profundidade documentada em comentário --
  junção só nasce de split de fio real, nunca de mensagem IPC direta; guarda contra mensagem
  malformada/webview desatualizada, não relacionado a formato de arquivo.
- `componentSymbols.ts` (`builtinComponentBox`/anchor): `connectors.junction` continua um typeId de
  catálogo válido e registrado (`hidden:true`, filtrado da paleta, não deletado do sistema) -- a
  entrada de tabela de 1 linha devolvendo caixa 0x0 é consistente com isso, não é resíduo morto.

Nenhuma remoção feita nesta seção -- ver `[[feedback_no_preemptive_compat_during_production_phase]]`
antes de reconsiderar: a distinção que importa é "arquivo real existente hoje" vs. "formato
hipotético futuro", não "código que menciona um formato antigo" por si só.

### 25.8 Bug pré-existente corrigido durante a verificação: pull-up do EN do ESP32 DevKitC não
tocava 3V3 (2026-07-11)

Achado ao investigar por que `esp32_devkitc_subcircuit_test` falhava mesmo depois de 25.5/25.6 --
confirmado por instrumentação temporária que o reaproveitamento de `CircuitGroup` (25.5) NUNCA
disparava neste teste (é o primeiro rebuild da sessão, `previous` sempre vazio), então a causa era
outra: bug de fiação real em `subcircuits/esp32_devkitc_v4.lssubcircuit`, não uma regressão desta
sessão.

`pullup_en` (resistor de 10k) tinha o pino 1 ligado ao MESMO nó de `mcu1.RST`/`button_en` (em vez de
à trilha 3V3) e o pino 2 ligado direto ao pino exposto `EN` -- ou seja, o resistor ficava EM SÉRIE
dentro da própria rede EN/RST, sem nenhuma ponta tocando 3.3V; o "pull-up" não puxava pra lugar
nenhum. Comparado contra o padrão do circuito irmão (BOOT/GPIO0, com fiação correta:
`pullup_boot.pin-1` -- 3V3, `pullup_boot.pin-2` -- {GPIO0, button}) pra derivar a topologia certa.
Corrigido trocando o destino de 2 condutores no `.lssubcircuit`: `pullup_en.pin-1` agora liga na
junção 3V3 (mesma junção de `tunnel_3v3`/`pullup_boot.pin-1`), e `tunnel_EN` ganhou um condutor extra
direto pra junção RST/button (em vez de só tocar `pullup_en.pin-2`) -- resultado:
3V3 -[pullup_en]- {EN, RST, button_en} -[button_en]- GND, mesmo padrão do BOOT.

**Verificação**: `esp32_devkitc_subcircuit_test` (assert `nodeVoltageOfPin(EN) > 3.0` com botão
solto) passa; suíte completa do Core, 37/37, 0 falhas.

### 25.9 Reestruturação da interação de fios/junções: motor de hit-test unificado, junção
interativa, mover-em-grupo generalizado (2026-07-12)

Pedido explícito do usuário, com autorização de mudança disruptiva ("não me preocupo em mudanças
robustas desde que o ganho seja grande") e 4 queixas concretas de uso real: (1) clicar no meio de um
fio pra iniciar uma derivação não funcionava de forma confiável, (2) a marca visual da junção era
grande e inadequada, (3) impossível conectar corretamente um 4º+ fio no mesmo ponto, (4) selecionar
um componente + um fio e movê-los juntos não funcionava fora do caso de um único canto/segmento já
selecionado. Investigação encontrou uma causa raiz comum em `main.ts`: interação de fio nunca usava
o motor de hit-test unificado que `wireTopology.ts` já tinha (pronto e testado, mas código morto --
`findAtPosition`/`buildWireSpatialIndex` sem NENHUM call site fora dos próprios testes), e em vez
disso cada tipo de alça (pino/segmento/canto) reimplementava sua própria cópia quase idêntica da
lógica de "iniciar vs. terminar uma derivação". Junção especificamente nunca teve handler nenhum
(`.junction-dot` era `pointer-events:none`) -- não havia COMO clicar numa junção existente, só por
acidente via a borda de um segmento adjacente.

**25.9.1 Junção virou elemento SVG interativo real.** `renderJunction` (antes um `<div>` decorativo
solto em `canvasContent`) agora é um `<g>` dentro do MESMO `wire-layer` SVG que pino/segmento/canto,
com dois círculos concêntricos: um alvo de clique/arrasto maior e invisível (`r=8`,
`.wire-layer__junction-hit`) e a marca visual pequena por cima (`r=2.5`,
`.wire-layer__junction-dot`, `pointer-events:none` -- todo o hit-test fica no círculo de baixo). Isso
resolve (2) diretamente (marca pequena, fiel ao SimulIDE) e (3): clique na junção passa pelo MESMO
`handleWireGestureClick` de pino/segmento/canto usando `{kind:"wire", wireId: <qualquer fio que já
toca a junção>, point: <posição do nó>}` -- **sem precisar de um `kind:"junction"` novo no
protocolo**: como o ponto clicado já É uma extremidade real daquele fio (a própria junção),
`splitSegmentAtPoint` cai no caminho "ponto já é extremidade, não divide" e `connectEndpointToNode`
resolve via `findExistingJunctionAt` pro MESMO nó -- reaproveita 100% da máquina já existente e
testada (`.spec` seção 24), zero mudança de modelo/mensagem IPC. Junção também ganhou arrasto (mover
`node.position` direto -- mais simples que canto/segmento, os fios tocando o nó se re-roteiam
sozinhos via `wirePolylinePoints`/`buildOrthogonalPath`, igual a mover um componente) e menu de
contexto (seleciona os fios tocando + `deleteSelectedItems`).

**25.9.2 `handleWireGestureClick` consolida pino/segmento/canto/junção numa função só.** Único
ponto de decisão "clicar num alvo de conexão já existente" -- início de derivação é SEMPRE local
(`beginWireDraft`, nunca mais um round-trip pela Extension só pra armar `pendingConnection`, que é
estado 100% transitório da Webview); terminar SEMPRE passa por `requestConnectEndpoints` no Core (o
único momento em que a topologia de verdade muda). O verbo IPC `requestStartWireFromWire`
(round-trip que servia SÓ pra armar o draft, sem tocar no Core -- redundante com o padrão já usado
pro pino) foi removido por inteiro (`messages.ts`, `extension.ts`, `main.ts`) -- resolve (1): a causa
raiz mais provável do "clique não inicia derivação" era a combinação de um round-trip assíncrono
desnecessário com uma seleção `render()`-síncrona disparada dentro do PRÓPRIO `pointerdown` que
recriava o DOM do alvo antes do `click` nativo do browser ter chance de disparar nele.

**25.9.3 Mover-em-grupo generalizado pra `selectedWireIds` inteiro.** `currentGroupWireSelection`/
`applyGroupWireDelta` (pré-existente) só cobriam UM canto ou segmento individualmente selecionado
acompanhando um arrasto de componente -- não cobria fio inteiro selecionado via marquee. Nova dupla
`computeGroupMoveWireTargets`/`applyGroupMoveWireDelta` (esta última reaproveitando o mesmo nome de
função de uma versão anterior mais restrita, agora generalizada) cobre TODA a seleção múltipla de
fios: cada fio selecionado translada seus pontos internos pelo delta; um nó de topologia só
translada junto se `movableTopologyNodeIds` (`wireTopology.ts`, nova função pura, testada) confirmar
que TODOS os fios que o tocam também estão selecionados -- senão um T com só um ramo selecionado
rasgaria os outros dois. Aplicado simetricamente nos 4 pontos de entrada de arrasto (componente,
canto, segmento, junção) -- resolve (4): arrastar QUALQUER elemento cuja seleção inclua
componente(s) e/ou fio(s) move tudo junto, não só o caso estreito de antes.

**Verificação**: os 3 tsconfigs compilam sem erro; suíte completa da Extension, 218/218 (4 novos
casos de `movableTopologyNodeIds`), 0 falhas. Sem GUI disponível neste ambiente pra confirmar
interativamente os 4 gestos corrigidos -- verificado por rastreamento direto de código (incluindo
correção de um bug real encontrado durante a própria implementação: a marca visual da junção não
acompanhava seu próprio arrasto, só os fios tocando ela) + testes puros onde o código é testável;
recomenda-se sessão manual no VSCode real cobrindo os 4 cenários desta seção (derivar do meio de um
fio, conectar um 4º fio numa junção existente, arrastar uma junção, selecionar componente+fio e
mover juntos) antes de considerar 25.9 encerrado.

### 25.10 Auditoria pente fino da camada de interação de fios/junções (2026-07-12)

Pedido explícito do usuário: varredura de código morto, duplicação e regras repetidas em toda a
camada de desenho/edição/interação de fios (`main.ts`, `wireTopology.ts`, `wireGeometry.ts`,
`wireSpatialIndex.ts`, `messages.ts`, `extension.ts`, `coreLifecycle.ts`), consolidando em fonte
única sem alterar comportamento. Cada remoção/consolidação abaixo foi confirmada por grep de TODOS
os call sites antes de agir (não só leitura) -- ver `[[feedback_review_build_and_test_before_reporting]]`.

**Bug real encontrado e corrigido (não era só limpeza)**: no arrasto de componente,
`groupWireDragTarget` (canto/segmento especificamente selecionado) e `groupWireMoveTargets` (toda
`selectedWireIds`) podiam mirar o MESMO fio simultaneamente -- `selectOnlyWire`/
`selectOnlyWireCorner` sempre colocam o fio em `selectedWireIds` como efeito colateral de selecionar
um canto/segmento dele. Os dois mecanismos escreviam em `wire.points` na mesma rodada de `onMove`,
o segundo (`applyGroupMoveWireDelta`, mais grosseiro -- desloca TODOS os pontos internos por igual)
sobrescrevendo silenciosamente o ajuste preciso do primeiro (`applyGroupWireDelta`, que respeita o
eixo do canto/segmento). Corrigido excluindo o fio de `groupWireDragTarget` da computação de
`groupWireMoveTargets` nesse ponto de entrada (`computeGroupMoveWireTargets(groupWireDragTarget?.wireId)`).

**Código morto removido:**
- `findAtPosition`/`buildWireSpatialIndex`/`HitTestResult` (`wireTopology.ts`) -- motor de hit-test
  unificado, correto e testado, mas ZERO call sites fora dos próprios testes: `main.ts` nunca
  adotou esse caminho, construiu 4 alças DOM independentes (pino/segmento/canto/junção) com
  hit-test nativo do browser em vez disso (ver 25.9). Removido junto: a metade de
  `WireSpatialIndex` que só existia pra sustentar isso (`upsertConnectionPoint`/
  `removeConnectionPoint`/`queryConnectionPoints`/`IndexedConnectionPoint`/`clear()`) -- a metade de
  SEGMENTOS (`upsertWire`/`removeWire`/`queryPoint`) continua em uso real
  (`maybeAutoJunctionForDraggedComponents`). Cobertura de teste do que sobrou da classe reescrita
  pra testar `WireSpatialIndex` direto, sem depender de `findAtPosition`.
- `rebuildElectricalNet` (`wireTopology.ts`) -- união-busca sobre endpoints, zero call sites de
  produção (só os próprios testes); a invariante que ela verificava ("cruzamento sem nó fica
  eletricamente separado") foi PORTADA pra um teste novo em cima de `electricalEdgesForProject`
  (o mecanismo que de fato roda em produção), não simplesmente descartada.
- Um condicional morto (`if (matchedWire) break;`) em `maybeAutoJunctionForDraggedComponents` --
  inalcançável (o `break` de dentro do `if` anterior já garante que `matchedWire` nunca chega
  `truthy` nesse ponto do laço).
- Verbo IPC `requestStartWireFromWire` já tinha sido removido na sessão anterior (25.9); confirmado
  sem nenhum resíduo nesta varredura.

**Duplicação consolidada em fonte única:**
- `applyGroupTagAlongDelta` (`main.ts`, nova) -- as 4 alças de arrasto que tocam fio/junção (canto,
  canto via Shift-no-segmento, segmento, junção) repetiam byte a byte o mesmo bloco de ~10 linhas
  pra aplicar o delta de grupo (componentes + fios co-selecionados acompanhando o elemento
  agarrado). Agora cada uma só calcula `groupDx`/`groupDy` e delega.
- `startWireDragListeners` (`main.ts`, nova) -- as mesmas 4 alças repetiam a fiação de
  `pointermove`/`pointerup`/`pointercancel` em `window` com um `finish` nomeado só pra poder se
  referenciar nos próprios listeners. Agora é uma função (`onMove, onFinish`) reutilizada nas 4;
  cada `onFinish` continua sendo o código específico de cada uma (limpa a referência de arrasto
  certa -- `wireCornerDrag`/`wireSegmentDrag`/variável local da junção -- e decide
  persistir/suprimir o próximo clique), deliberadamente NÃO generalizado (tipos de referência de
  arrasto diferentes entre si, generalizar exigiria um genérico sem ganho real).
- `electricalOperationsDiff` (`coreLifecycle.ts`, nova) -- `extension.ts` repetia, em 4 handlers
  (sync genérico de `projectChanged`, `requestRemoveComponent`, `requestRemoveWire`,
  `requestConnectEndpoints`), o cálculo "achata antes/depois em arestas de pino real
  (`electricalEdgesForProject`) e monta a lista de operações connect/disconnect
  (`diffElectricalEdges`)". Extraída só essa PARTE mecânica (idêntica nos 4); a orquestração de
  cada verbo (aguardar ou disparar sem esperar, fallback quando não há diferença nenhuma,
  granularidade de polling) continua no call site -- são genuinamente diferentes entre si (ver
  "problema estrutural" abaixo) e forçar uma fusão total arriscaria alterar comportamento de
  rollback/erro que hoje é intencional.
- `WireEndpoint` (`messages.ts`) e `ConnectionEndpoint` (`wireTopology.ts`) eram dois tipos
  estruturalmente IDÊNTICOS (`{kind:"pin",componentId,pinId} | {kind:"wire",wireId,point}`)
  definidos em paralelo -- exemplo literal de "regra de conexão repetida em arquivo diferente".
  `WireEndpoint` agora é um alias de `ConnectionEndpoint` (import direto, sem redefinição), os dois
  lados do protocolo (mensagem IPC e motor de topologia) nunca mais podem divergir por acidente.

**Duplicação avaliada e mantida DELIBERADAMENTE (não é remendo, é fronteira arquitetural real):**
`flipLocalPoint`/`rotateLocalPoint` (`wireTopology.ts`) duplicam `flipPoint`/`rotatePoint`
(`main.ts`), mesma matemática de box/origem/flip/rotação, ~15 linhas. Já documentado como deliberado
numa sessão anterior: `wireTopology.ts` roda tanto no Host (Node, sem DOM) quanto na Webview, e
`main.ts` é Webview-only (não pode ser importado pelo Host). Extrair um 3º módulo compartilhado só
pra ~15 linhas usadas por exatamente 2 consumidores, um dos quais é o "original", seria abstração
desproporcional ao ganho -- mantido como está, documentado aqui de novo pra não ser "redescoberto"
como duplicação ingênua numa auditoria futura.

**Problemas estruturais encontrados (não corrigidos nesta rodada -- mudança de comportamento, fora
do escopo de "não alterar funcionalidades existentes"):**
1. **"Reconexão" de extremidade de fio não existe como gesto dedicado.** O pedido do usuário lista
   reconexão entre as operações que precisam de fonte única de verdade, mas não há hoje nenhum
   caminho de UI pra arrastar a PONTA de um fio existente (pino ou nó real, índice 0/último de
   `wirePolylinePoints`) pra outro pino -- `renderWireCornerHandles` deliberadamente pula esses dois
   índices (`for (let index = 1; index < points.length - 1; ...)`), só cobre pontos INTERNOS. O
   único caminho hoje é apagar o fio e desenhar outro. O modelo de dados já suporta a mudança
   (`WebviewWireModel.from`/`.to` são campos comuns, nada os torna imutáveis) -- o que falta é o
   gesto interativo em si (handle no índice 0/último com hit-test especial, arrasto que solta sobre
   um pino/segmento/junção e reescreve só aquele endpoint). Fica como trabalho futuro explícito, não
   implementado aqui por ser funcionalidade NOVA, não consolidação.
2. **Os 4 handlers de `extension.ts` que chamam `electricalOperationsDiff` têm orquestração
   pós-diff genuinely diferente** (aguardar vs. disparar sem esperar, fallback quando o diff vem
   vazio, granularidade de polling, rollback em erro). Isso É uma duplicação de FORMA (todos seguem
   "computa diff → decide o que fazer") mas não de CONTEÚDO -- uma fusão total exigiria um
   parâmetro de estratégia (callback/enum) que ganha pouco e arrisca alterar o comportamento de
   recuperação de erro de cada verbo, hoje ajustado individualmente. Candidato a uma passada futura
   SE esses 4 comportamentos forem intencionalmente unificados por decisão de produto (não é uma
   decisão de limpeza de código).

**Verificação**: os 3 tsconfigs compilam sem erro; suíte completa da Extension, 218/218, 0 falhas
(mesmo total de 25.9 -- nenhum teste foi perdido, `rebuildElectricalNet` teve sua invariante
portada, não descartada). ~146 linhas líquidas removidas nesta rodada (321 remoções, 175 inserções,
7 arquivos). Sem GUI disponível neste ambiente -- verificação das operações de conexão feita por
rastreamento de código (cada função consolidada foi comparada campo a campo com as N cópias que
substituiu antes de remover as originais) e pela suíte automatizada; recomenda-se sessão manual no
VSCode real cobrindo criação de fio (pino→pino, pino→segmento, segmento→segmento), arrasto de
canto/segmento/junção com e sem seleção mista, e remoção de fio/componente com simulação rodando
antes de considerar 25.10 encerrado.

## 26. Auditoria de Modo Placa e Componentes Expostos (2026-07-12)

**Nota 2026-07-16**: o "Mecanismo A" descrito na seção 26.2 abaixo (`subcircuitBoardMode.ts`, toggle
DENTRO da sessão de edição) foi removido e absorvido pelo modo de editor "Símbolo" — ver
`.spec/lasecsimul-subcircuits.spec` seção 22.5. O "Mecanismo B" (overlay na instância JÁ COLOCADA,
`renderBoardOverlaysFor`/`boardOverlayData`) continua vivo e ativo, só re-cabeado pra ler/escrever
`exposedComponents[]` (array de nível superior do `.lssubcircuit`, schemaVersion 3) em vez dos
campos planos `boardX`/`boardY`/... descritos na seção 26.3 — o bug de dois-armazenamentos-paralelos
ali documentado não existe mais estruturalmente (só há UM array de exposição agora, não dois
formatos concorrentes). Registro histórico mantido abaixo.

Pedido explícito do usuário: auditoria minuciosa de "Modo Placa" e "Selecionar componentes
expostos" durante edição de subcircuito, usando o SimulIDE real como referência (fonte estudada:
`subpackage.cpp`/`subpackage.h`, `linker.cpp`/`linker.h`, `component.cpp`/`component.h`, branch
`simulide_2`).

### 26.1 Como o SimulIDE real funciona (pesquisa de código, não suposição)

Dois mecanismos SEPARADOS e ortogonais, ambos vivendo em `SubPackage` (item que representa o
símbolo/pacote externo de um subcircuito, análogo ao `other.package` do LasecSimul):

- **`SubPackage::setBoardMode(bool)`** (ação de menu "Board Mode", checkable): opera sobre TODOS os
  componentes da CENA atualmente aberta (equivalente a estar dentro de "Abrir Subcircuito" no
  LasecSimul). Ao entrar: salva posição/rotação/flip atuais em `circPos`/`circRot`/etc, e SE já
  existia uma posição de placa salva (`boardRot() != -1e6`, sentinela de "nunca definido"), aplica
  `boardPos`/`boardRot`/etc. Ao sair: salva a posição atual (de placa) em `boardPos`/etc, restaura
  `circPos`/etc. `Component::setHidden(mode,...)` esconde o corpo INTEIRO de todo componente
  NÃO-`m_graphical`; componentes `m_graphical` só têm os PINOS escondidos (corpo visual continua
  visível) -- ou seja, **só quem é `m_graphical` aparece no Modo Placa**, sem exceção, sem seleção
  adicional.
- **`m_graphical`** (`Component`, `component.h`): flag booleana **hardcoded por CLASSE de
  componente** no construtor de cada subclasse (LEDs, switches, motores, displays, medidores,
  sensores, MCU, potenciômetro, `shape`/`textcomponent`, `dial`, o próprio `SubPackage` etc, ~40
  classes) -- **NUNCA uma propriedade editável pelo usuário por instância**. É um traço do TIPO,
  não do componente individual.
- **`Linker`/`m_isMainComp`** ("Select Exposed Components", outra ação de menu em `SubPackage`):
  clique-para-alternar (`startLinking()`/`compSelected()`) quais componentes internos são "Main
  Components". Persistido via `getLinks()`/`setLinks()` (lista de UIDs separada por vírgula,
  resolvida de volta em `createLinks()` no carregamento). Destaque visual: azul+número durante a
  seleção ativa, amarelo permanente fora dela (`Component::paintSelected`).
- **Achado importante**: `m_isMainComp` **NÃO controla visibilidade no Modo Placa** (`setBoardMode`
  nunca consulta `isMainComp()`) -- os dois mecanismos são estruturalmente independentes no C++
  real. O uso real de `isMainComp` encontrado é dar acesso rápido às propriedades do componente
  interno a partir de fora (`Component::contextMenu`, `if (!event && m_isMainComp)`), não gate de
  Modo Placa.
- **Achado importante #2**: `SubPackage::paint()` só desenha `Chip::paint()` (fundo/pinos do
  pacote) -- **não existe, no SimulIDE real, nenhuma renderização de componentes internos
  "espiando" por cima do símbolo externo quando visto de FORA do subcircuito** (isto é, a partir do
  circuito PAI, sem abrir o subcircuito). Esse recurso (pressionar um botão exposto de uma
  instância direto no circuito principal, sem abrir o subcircuito) é uma **invenção do
  LasecSimul**, sem equivalente no SimulIDE -- mantida por ser funcionalidade real e útil (ex:
  apertar o botão RESET de uma instância de ESP32 durante a simulação sem precisar entrar no
  subcircuito), não removida, mas identificada explicitamente aqui para não ser confundida com
  paridade de SimulIDE.
- **Achado importante #3** (responde à seção 2 do pedido do usuário, "representação diferente no
  Modo Placa"): não foi encontrada NENHUMA representação visual alternativa/distinta pro Modo Placa
  em componente nenhum -- `Component::m_boardMode` (flag estática) só é lida em MAIS UM lugar do
  código inteiro (`component.cpp:174`, um modificador de evento de mouse, não desenho). Um
  componente `m_graphical` usa o MESMO `paint()` tanto no esquemático quanto no Modo Placa -- Modo
  Placa muda só POSIÇÃO e VISIBILIDADE, nunca a forma de desenhar. **Não foi implementada** uma
  "representação Board-Mode distinta por componente" porque ela não existe no SimulIDE real que o
  pedido pede pra usar como referência -- ver seção 26.4 (comportamento não-equivalente/decisão) pra
  transparência completa sobre esse ponto.

### 26.2 Mapeamento do que já existia no LasecSimul (dois mecanismos, nomeados aqui pra clareza)

- **Mecanismo A** (`subcircuitBoardMode.ts` + `main.ts::setSubcircuitBoardMode`/
  `isBoardModeVisible`): Modo Placa de verdade, só ativo DENTRO de uma sessão "Abrir Subcircuito"
  -- já era uma porta fiel de `SubPackage::setBoardMode` (`captureCircuitTransforms`/
  `applyBoardTransforms`/`captureBoardTransforms`/`restoreCircuitTransforms`, mesmo padrão
  circPos/boardPos). Reaproveita o pipeline de renderização/interação normal do esquemático (mesmos
  `state.components`, só reposicionados) -- por construção, mover/rotacionar/espelhar/multi-
  selecionar/arrastar já funcionavam SEM nenhum código adicional, confirmado por leitura (nenhum
  gate de `subcircuitBoardMode` nos handlers de seleção/arrasto/rotação/flip).
- **Mecanismo B** (`main.ts::renderBoardOverlaysFor` + `boardModeEnabled` property + IPC
  `requestBoardOverlayData`/`requestUpdateBoardOverlayVisual`/`requestUpdateBoardOverlayProperty`):
  overlay interativo no circuito PRINCIPAL sobre uma instância de subcircuito com Modo Placa
  ligado -- funcionalidade LasecSimul-específica (ver 26.1), não existe no SimulIDE.

### 26.3 Bug crítico real encontrado e corrigido: dois armazenamentos paralelos nunca sincronizados

`WebviewComponentModel` (`model.ts`) já tinha os campos PLANOS corretos, persistidos e usados pelo
Mecanismo A: `boardX`/`boardY`/`boardRotation`/`boardFlipH`/`boardFlipV`. Mas o Mecanismo B lia e
escrevia um campo **completamente diferente e nunca lido por mais ninguém**:
`subcircuitInternals.ts::extractInternalComponents` lia `value.boardVisual` (objeto aninhado
`{x,y,rotation,flipH,flipV}`) direto do JSON cru -- campo que o Mecanismo A **nunca escreveu** (só
escreve os campos planos). E `mcuCommands.ts::updateBoardOverlayVisualCommand` (chamado ao
ARRASTAR o overlay no circuito principal) escrevia justamente nesse `boardVisual` aninhado, nunca
nos campos planos.

Consequência real: posicionar um componente com o Modo Placa DE VERDADE (Mecanismo A, dentro de
"Abrir Subcircuito") nunca aparecia no overlay da instância no circuito principal (Mecanismo B
sempre lia `undefined`, caindo no posicionamento padrão em coluna); e arrastar o overlay no
circuito principal nunca refletia de volta no Modo Placa real. Exatamente o "array paralelo sem
sincronização" que a seção 5 do pedido pede pra caçar -- este era o mais grave encontrado.

**Corrigido**: `subcircuitInternals.ts` ganhou `boardVisualFromFlatFields`, que deriva o
`boardVisual` (agrupamento só de conveniência pro payload IPC `InternalComponentSnapshot`, não mais
fonte de verdade) a partir dos MESMOS campos planos que o Mecanismo A grava.
`updateBoardOverlayVisualCommand` agora escreve direto em `boardX`/`boardY`. Fonte única de verdade
persistida: os 5 campos planos em `WebviewComponentModel`, os mesmos de sempre -- nenhuma migração
necessária (nenhum arquivo real no repositório tinha `boardVisual` OU `boardX` escritos ainda,
confirmado por grep em `subcircuits/`/`devices/` antes da correção).

### 26.4 Comportamento que permanece NÃO-equivalente ao SimulIDE (decisão consciente, documentada)

- **Representação visual distinta no Modo Placa** (seção 2 do pedido): não implementada -- ver
  26.1, achado #3. O SimulIDE real não tem esse recurso; implementá-lo seria inventar
  comportamento sem lastro na referência pedida. Se o usuário quiser isso mesmo assim como recurso
  PRÓPRIO do LasecSimul (não paridade SimulIDE), é uma decisão de produto nova, não uma correção de
  divergência -- fica pendente de confirmação explícita antes de qualquer implementação futura.
- **Mecanismo B (overlay no circuito principal)** continua sem equivalente no SimulIDE -- mantido
  por ser funcionalidade real já usada (não removida, matching "não remover funcionalidades
  existentes"), agora corretamente sincronizado com o Mecanismo A (26.3).
- **`isMainComp`/exposed não gatilha Modo Placa no SimulIDE real, mas gatilha no LasecSimul**
  (filtro `item.exposed && item.graphical` em `renderBoardOverlaysFor`) -- decisão deliberada de
  MANTER o comportamento atual do LasecSimul (dá controle de curadoria que o SimulIDE não tem: nem
  todo componente `graphical` de um subcircuito precisa aparecer no overlay externo) em vez de
  replicar a independência total do SimulIDE, que teria o overlay mostrando TODO componente
  gráfico sem nenhuma curadoria possível -- pior UX, não melhor paridade que valha a pena.
- **Grade/snap ao arrastar componente** (dentro OU fora do Modo Placa): LasecSimul não tem snap de
  grade no arrasto de componente (só fios têm `WIRE_GRID_SIZE`/`snapCoordinate`) -- isto NÃO é uma
  lacuna introduzida ou específica do Modo Placa, é como TODO arrasto de componente já funciona no
  editor hoje; não alterado aqui pra não introduzir uma inconsistência nova (componente ganhando
  snap só dentro do Modo Placa, diferente do resto do editor).

### 26.5 Outras correções desta auditoria

- `main.ts`: "Modo Placa"/"Selecionar Componentes Expostos" só apareciam no menu de contexto de um
  componente já existente -- numa folha de subcircuito recém-criada (zero componentes), não havia
  NENHUM jeito de entrar em Modo Placa. Adicionadas as mesmas 2 entradas ao menu do fundo vazio do
  canvas, condicionadas a `state.subcircuitEditingContext` (igual ao menu por componente).
  Resolve "entrada e saída do Modo Placa" (seção 1) pra qualquer estado do canvas.
- `main.ts::pasteClipboardItems`: colar uma cópia de um componente já posicionado no Modo Placa
  deslocava `x`/`y` (esquemático) pelo grid, mas NUNCA `boardX`/`boardY` -- a cópia nascia
  exatamente empilhada sobre o original na visão de placa. Mesmo deslocamento aplicado aos dois
  agora.
- `isBoardModeVisible` (antes função local em `main.ts`, acoplada a `catalogEntryFor`) extraída pra
  `subcircuitBoardMode.ts` como função pura (recebe `isGraphicalTypeId` injetado) -- resolve
  "responsabilidades misturadas entre UI e modelo" (seção 5) pro cálculo de visibilidade
  especificamente, e torna a regra "só `graphical` (ou `other.package`/ícone) aparece" testável
  diretamente, sem precisar montar um catálogo inteiro pro teste.

### 26.6 Segurança contra duplicação/referência órfã (verificado, não precisou de correção)

- `exposed`/`boardX`/`boardY`/`boardRotation`/`boardFlipH`/`boardFlipV` são campos ESCALARES
  (`number`/`boolean`) direto em `WebviewComponentModel` -- `cloneComponent` (`{...rest}`) já os
  copia por valor, sem risco de referência compartilhada entre original e cópia/colagem.
  `exposed` É copiado através de cópia/colagem deliberadamente (mesmo comportamento esperado de
  `BoolProp` no SimulIDE real, que copia todas as propriedades registradas ao colar).
- **Sem array paralelo de "ids expostos"**: `exposed` é uma flag NO PRÓPRIO componente, não uma
  lista separada referenciando ids (diferente do `Linker::m_linkedComp`/UID-string do SimulIDE
  real) -- excluir ou renomear um componente exposto nunca deixa referência órfã, por construção
  (não existe uma segunda estrutura de dados que precise ser limpa à parte). Isto é estruturalmente
  MAIS robusto contra órfãos do que o mecanismo original do SimulIDE.
- **Duas instâncias do mesmo subcircuito**: layout de Modo Placa e conjunto de expostos são
  propriedades do ARQUIVO `.lssubcircuit` (definição compartilhada), não da instância -- duas
  instâncias mostram o MESMO layout de placa por design (igual ao SimulIDE: `SubPackage`/Board Mode
  pertence à cena INTERNA do subcircuito, não à instância externa). `boardModeEnabled` (se o
  overlay está LIGADO) é uma property PER-INSTANCE (`component.properties`, objeto próprio por
  instância via `cloneComponent`), então ligar o overlay numa instância nunca liga na outra --
  testado por leitura de código, comportamento correto confirmado.

### 26.7 Testes adicionados

`subcircuitBoardMode.test.ts`: +5 casos -- `isBoardModeVisible` (gráfico/não-gráfico/`other.package`/
ícone), seleção múltipla incremental (marcar 3, desmarcar 1, os outros 2 continuam), componente sem
posição de placa salva nunca pula pra `(0,0)` (arquivo antigo/1ª vez), rotação+espelhamento
sobrevivem a um ciclo completo entrar/sair do Modo Placa, e duas capturas independentes (2
"instâncias") nunca compartilham objeto de transform por referência. `subcircuitInternals.ts`/
`mcuCommands.ts` (o outro lado do fix) não têm suíte própria porque importam `vscode` no escopo do
módulo -- mesma limitação estrutural de QUALQUER arquivo do lado Extension que toca a API do VS
Code neste projeto (sem shim de `vscode` no test runner atual); verificado por compilação limpa +
leitura campo a campo comparando com o padrão já testado em `subcircuitBoardMode.ts`.

**Verificação**: os 3 tsconfigs compilam sem erro; suíte completa, 223/223 (5 novos), 0 falhas. Sem
GUI disponível neste ambiente -- "comparação visual com o SimulIDE" (item 19 dos testes pedidos)
feita por leitura direta do código-fonte real do SimulIDE (`C:\SourceCode\simulide_2\src`, branch
`simulide_2`, já usado numa auditoria anterior -- ver `[[reference_simulide_schematic_analysis]]`),
não por captura de tela (sem GUI aqui pra rodar nenhum dos dois programas). Recomenda-se sessão
manual no VSCode real cobrindo: abrir/fechar Modo Placa numa folha de subcircuito vazia (via o novo
menu de fundo), posicionar um componente gráfico e confirmar que a MESMA posição aparece no overlay
da instância no circuito principal (e vice-versa, arrastando o overlay e reabrindo o subcircuito),
colar uma cópia de um item posicionado na placa, e desfazer/refazer um ciclo de Modo Placa.

## 27. Representação visual própria do Modo Placa (2026-07-12)

Pedido explícito do usuário, respondendo diretamente à "decisão pendente" registrada em 26.4/26.1
achado #3: confirmar (com duas imagens de referência de um ESP32 DevKitC -- vista "placa física" com
botões redondos "e"/"b", e vista "esquemático/fiação" com os mesmos botões ao lado dos pinos
elétricos reais) que o LasecSimul deve implementar uma aparência de Modo Placa DISTINTA da
aparência esquemática, como recurso PRÓPRIO do LasecSimul (não paridade SimulIDE -- ver 26.1/26.4:
o SimulIDE real usa o MESMO `paint()` nos dois contextos, só muda posição/visibilidade).

### 27.1 Requisito e por que não é paridade SimulIDE

Requisitos explícitos do pedido: (1) aparência distinta por componente no Modo Placa; (2)
posicionamento independente (já existia, `boardX`/`boardY`/etc, seção 26); (3) tamanho/orientação
próprios do Modo Placa; (4) vínculo com o MESMO componente/estado, nunca uma cópia paralela; (5)
interação (clique/estado) durante simulação usando os MESMOS pinos/propriedades; (6) persistência;
(7) não alterar o comportamento do modo esquemático, não duplicar lógica elétrica/simulação.

Como 26.1 já documentou que `Component::m_boardMode` só é lido fora do `paint()` no SimulIDE real,
este recurso não tem onde "portar de" -- é autoria nova, seguindo o MESMO formato declarativo
(`package.simulidePaint`, primitivas ellipse/rect/roundedRect/polygon/line/text/repeat com
`stateFill`/`stateVisible`/`stateText`) já usado para portar os símbolos elétricos reais, só que sem
fonte C++ para copiar -- as imagens anexadas pelo usuário foram a referência visual usada.

### 27.2 Arquitetura: 3º slot de package, escolhido por CONTEXTO de renderização (não por propriedade)

Extensão direta do padrão já existente para "Chip or Logic Symbol"
(`LOGIC_SYMBOL_PACKAGE_BY_TYPE_ID`, escolhido por `properties.logicSymbol === true`, uma propriedade
da INSTÂNCIA): `componentSymbols.ts` ganhou `BOARD_PACKAGE_BY_TYPE_ID` (mapa separado) e um novo
parâmetro `variant?: "board"` em `resolvedPackageFor`/`componentBox`/`packageSymbolSvg`, propagado
por `registerPackage(typeId, pkg, logicSymbolPkg?, boardPkg?)`. Diferença deliberada do Logic
Symbol: Board-Mode-ness é uma decisão de QUEM está renderizando (`main.ts`, dentro do Modo Placa
real -- Mecanismo A -- ou no overlay da instância -- Mecanismo B), nunca um estado gravado no
componente; por isso é um parâmetro explícito passado a cada chamada, não uma property lida de
dentro de `componentSymbols.ts`. Prioridade quando ambos existem: `variant==="board"` vence sobre
`logicSymbol` (contexto de renderização mais específico). Sem `boardPackage` registrado pro typeId,
cai no `package` esquemático de sempre -- Modo Placa nunca fica sem aparência nenhuma, e nenhum
typeId existente muda de comportamento sem ser explicitamente portado.

`registerPackage` aceita `boardPkg` sem exigir nenhum pino (guarda mais frouxa que `pkg`/
`logicSymbolPkg`, que exigem `pins.length > 0`): ao contrário do esquemático, o Modo Placa nunca
desenha fio/terminal (26.1: pinos ficam ESCONDIDOS pra componentes `m_graphical` em Board Mode, só o
corpo visual continua) -- uma aparência com 0 pinos é o caso NORMAL aqui, não uma entrada malformada.

Consequência direta em `main.ts::updateComponentElement`: quando `boardVariant==="board"`, o laço
que desenha terminal/pino de fio é pulado inteiramente (`if (boardVariant !== "board") { ...laço de
pinos... }`) -- coordenadas de pino do package esquemático não fariam sentido sobre uma forma/
tamanho de package diferente, e replica o comportamento real do `Component::setHidden` (26.1) de
esconder pinos em componentes gráficos durante Board Mode.

### 27.3 Tamanho/orientação próprios (`boardWidth`/`boardHeight`)

Reaproveita o mecanismo de escala por-instância já existente (`__simulideSceneScaleX/Y`, lido por
`packageInstanceScale`, já usado noutro fluxo de escala de package) em vez de inventar um 2º sistema
de geometria: `main.ts` calcula a razão entre `component.boardWidth`/`boardHeight` (novos campos em
`WebviewComponentModel`, mesma família de `boardX`/`boardY`/`boardRotation`/`boardFlipH`/
`boardFlipV`) e o tamanho NATURAL do `boardPackage` (via `componentBox(typeId, props, "board")`), e
injeta o fator resultante num objeto de properties SINTÉTICO passado ao renderer -- nunca mutando
`component.properties` em memória (risco identificado proativamente: `runtimeSymbolProperties` pode
devolver a referência VIVA de `component.properties`; o código sempre espalha `{...symbolProperties,
...}` numa cópia nova antes de injetar o fator de escala). Ausente (`undefined`) == usa o tamanho
natural do `boardPackage`, sem nenhuma escala aplicada. Rotação/flip do Modo Placa já eram cobertos
por `boardRotation`/`boardFlipH`/`boardFlipV` (seção 26), reaproveitados sem alteração.

### 27.4 Vínculo com o componente real / interação unificada

Nenhuma cópia paralela de componente ou de estado: o `boardPackage` é só uma FORMA DIFERENTE de
desenhar o MESMO `component.properties`/`component.pins`, resolvida a cada `render()` a partir do
mesmo `state.components` de sempre -- mesmo princípio já usado por `logicSymbol`. As primitivas do
`boardPackage` de `switches.push`/`switches.switch` usam `cssClass: "toggle-hit-zone"`, a MESMA
classe CSS que o handler de clique genérico em `main.ts` já procura (`event.target.closest(
".toggle-hit-zone")`, linha ~4646) para decidir `canToggle`/chamar `setSwitchClosed(component,
component.properties.closed !== true)` (linha ~4720) -- verificado por leitura direta do fluxo
clique→toggle: não existe (nem foi criado) nenhum 2º caminho de clique específico do Modo Placa;
clicar no botão físico do Modo Placa aciona exatamente o mesmo `closed` que o símbolo elétrico do
esquemático leria, e a mudança aparece nos dois (schematic + board) no próximo `render()`, porque
ambos leem o mesmo `component.properties.closed` -- só a `stateFill` do binding SVG muda.

### 27.5 Componentes portados nesta rodada e limitações documentadas

- **`switches.push`**: botão físico redondo (referência: botões EN/Boot do ESP32 DevKitC).
  `stateFill` em `closed` (verde/cinza), `stateText` ecoando `key` (mesmo rótulo do esquemático).
- **`switches.switch`**: chave/rocker física, dois "thumbs" com `stateVisible` opostos em `closed`.
- **`outputs.led`**: LED físico redondo (vermelho fixo). **Limitação conhecida e documentada no
  próprio `component-catalog.json` (`source.notes`)**: o Core ainda não expõe corrente/intensidade
  real como propriedade pra `outputs.led` -- o símbolo ESQUEMÁTICO também não reflete estado hoje.
  A aparência do Modo Placa é estática (mesma cor sempre) até esse dado existir; quando existir, o
  binding é só adicionar `stateFill`/`stateProjection` aqui, sem mexer no resto da arquitetura.
- **Fora de escopo desta rodada** (decisão deliberada, não pressa): `passive.potentiometer` e
  `outputs.seven_segment` não ganharam `boardPackage` -- typeIds sem `boardPackage` registrado
  simplesmente continuam reusando o package esquemático no Modo Placa (27.2), nenhum comportamento
  quebrado, só menos "físico" visualmente até serem portados numa rodada futura.
- **`registeredSources.ts`** (manifesto `.lsdevice`/`.lssubcircuit`, que já tem seu próprio
  `logicSymbolPackage` via `sanitizePackage`) deliberadamente NÃO ganhou `boardPackage` nesta
  rodada -- os typeIds pedidos pelo usuário são todos do catálogo base (`component-catalog.json`),
  não de device/subcircuito externo; extensão do manifesto fica pendente de necessidade real.

### 27.6 Bug real encontrado e corrigido de passagem (Mecanismo B, overlay no circuito principal)

`renderBoardOverlaysFor` montava `properties` como `{ closed: false }` **hardcoded**, descartando
`item.properties` inteiramente -- um switch salvo com `closed: true` sempre desenhava aberto no
overlay da instância no circuito principal (Mecanismo B), mesmo com o Modo Placa real (Mecanismo A)
mostrando o estado correto. Corrigido para `{ closed: false, ...item.properties }` (default só para
typeIds sem a propriedade, nunca sobrescrevendo o valor real salvo). Diretamente relevante ao
requisito "5. Interação durante simulação -- estado deve refletir imediatamente" do pedido: sem essa
correção, a NOVA aparência física do Modo Placa herdaria o mesmo bug de estado errado no overlay.

### 27.7 Dados novos / formato

- `PackageDescriptor` (formato já existente, sem mudança de schema) usado como o TIPO do novo campo
  `boardPackage?: PackageDescriptor` em `WebviewComponentCatalogEntry` (`model.ts`) e
  `UnifiedCatalogItem`/`entryToWebview` (`UnifiedCatalog.ts`) -- mesmo shape de `package`.
- `WebviewComponentModel` ganha `boardWidth?: number`/`boardHeight?: number` (persistidos junto dos
  demais campos escalares `boardX`/`boardY`/etc, mesma família, mesma garantia de cópia por valor em
  `cloneComponent` -- seção 26.6 já cobre essa garantia estrutural, reaproveitada sem mudança).
- `component-catalog.json`: `boardPackage.simulidePaint.source.file` marcado explicitamente como
  `"N/A -- aparência própria do Modo Placa do LasecSimul, sem equivalente no paint() real do
  SimulIDE"` em cada entrada nova, para nunca ser confundido com os OUTROS `simulidePaint` do mesmo
  arquivo, que são portes fiéis de `paint()` C++ reais.

### 27.8 Testes e verificação

`componentSymbols.test.ts`: +5 casos -- seleção do package certo por `variant` (sem variant reusa o
esquemático; com `variant:"board"` e `boardPackage` registrado usa o board; com `variant:"board"` mas
SEM `boardPackage` registrado cai no esquemático, nunca fica sem aparência); os 3 typeIds portados
(`switches.push`/`switches.switch`/`outputs.led`) lidos DIRETO do `component-catalog.json` real (não
fixture) confirmando SVG do Modo Placa visualmente diferente do esquemático, `key`/`closed`
continuam ecoados (mesmo estado, nunca duplicado), e presença de `toggle-hit-zone` (clicável pelo
mesmo mecanismo genérico).

Um dos 5 testes inicialmente falhou por um erro na PRÓPRIA fixture do teste (não na implementação):
um pino de teste com `angle:180,length:8` se estendia 8px para fora da caixa 32x28 declarada, e
`resolvePackageLayout` corretamente EXPANDE o bounding box calculado para caber qualquer lead que
ultrapasse `width`/`height` (comportamento correto e pré-existente, não uma regressão desta rodada)
-- o box observado (40x28) misturava a largura esperada do board package (40) só por coincidência
numérica. Corrigido trocando o pino da fixture por um terminal canônico (`x`/`y`) com `length:0`, exatamente
na borda declarada (não estica o box), preservando a exigência de `registerPackage` de pelo menos 1
pino para tratar o package como "real".

**Verificação**: os 3 tsconfigs (`tsconfig.json`/`tsconfig.webview.json`/`tsconfig.test.json`)
compilam sem erro; suíte completa, 228/228 (5 novos sobre os 223 anteriores), 0 falhas. Sem GUI
disponível neste ambiente -- comparação feita por leitura de código (fluxo clique→toggle→render,
binding `stateFill`/`stateText`), não por captura de tela real; recomenda-se sessão manual no VSCode
cobrindo: entrar no Modo Placa de um subcircuito com `switches.push`/`switches.switch`/`outputs.led`,
confirmar visual físico (botão redondo, chave rocker, LED bulbo) distinto do esquemático, clicar no
botão/chave físicos durante simulação e confirmar que o pino elétrico correspondente reage no
esquemático (mesma rede), redimensionar via `boardWidth`/`boardHeight` numa propriedade futura de UI
(ainda sem editor dedicado nesta rodada -- os campos existem e persistem, mas não há um controle
"Largura na Placa"/"Altura na Placa" na paleta de propriedades ainda), salvar e reabrir o arquivo
confirmando que posição/tamanho/orientação do Modo Placa sobrevivem.

### 27.9 Correção: `switches.push`/`switches.switch` NÃO precisam de `boardPackage` (2026-07-12)

Usuário questionou a afirmação de 27.1 ("SimulIDE não tem representação distinta") pedindo análise
mais profunda -- achado real, não estava certo pela metade.

**O que a 1ª pesquisa (seção 26/27.1) confirmou certo**: `Component::m_boardMode` só é lido em
`freeMove()` e `SubPackage::setBoardMode()` -- nunca dentro de um `paint()`. Um componente NUNCA
redesenha a si mesmo diferente por causa do Modo Placa.

**O que a 1ª pesquisa deixou passar**: `Push::paint()` (`components/switches/push.cpp:110-135`)
desenha a barra do atuador usando um `QGraphicsProxyWidget` de fundo, `CustomButton`
(`gui/custombutton.cpp`), cujo `paintEvent()` **já muda de gradiente sozinho** com
`isDown()||isChecked()` -- e `LedBase::paint()` (`components/outputs/leds/ledbase.cpp:152-187`) **já
calcula a cor a partir de `m_intensity`** (corrente real) a cada frame. Ou seja: pra estes tipos
`m_graphical`, a ÚNICA aparência que existe já É física (botão com gradiente 3D, LED redondo colorido)
e já É dinâmica (muda com o estado) -- desde SEMPRE, no esquemático inclusive, não é um recurso do
Modo Placa. Conferido contra o `component-catalog.json` REAL (não o `boardPackage` novo): o package
ESQUEMÁTICO de `switches.push` já tem `stateFill` em `closed` (`"#62d67b"`/`"#dddddd"`, porte fiel do
`CustomButton`) -- **já era dinâmico antes desta sessão**.

**Conclusão**: o `boardPackage` circular que autorei pra `switches.push`/`switches.switch` era
redundante -- duplicava (com forma diferente, sem lastro em nenhum C++ real) uma dinâmica que o
package esquemático já tinha. **Revertido**: `boardPackage` removido de ambos no
`component-catalog.json`; Modo Placa agora reaproveita o package ESQUEMÁTICO (já físico, já dinâmico)
via `boardX`/`boardY`/etc (mecanismo independente desde a seção 26), sem package próprio -- exatamente
como o SimulIDE real funciona pra estes dois tipos. Mecanismo `boardPackage` (`componentSymbols.ts`)
continua no código, disponível pra typeIds que precisarem de fato de uma forma diferente (nenhum caso
concreto identificado ainda).

**Bug real encontrado e corrigido nesta mesma revisão** (`main.ts::updateComponentElement`): o
esconde-pino do Modo Placa estava gated em `boardVariant === "board"` (só os typeIds com
`boardPackage` registrado), não em `catalogEntry?.graphical === true` como o `Component::setHidden`
real -- ou seja, TODO OUTRO componente `m_graphical` sem `boardPackage` (motores, displays, sensores,
LED antes desta rodada, etc, ~40 classes) ficava com pino visível/clicável no Modo Placa, divergindo
do SimulIDE. Corrigido pra `const pinsHiddenInBoardMode = subcircuitBoardMode && catalogEntry?.graphical
=== true`, cobrindo TODO componente gráfico, não só os poucos com aparência própria.

**`outputs.led` mantinha `boardPackage`** logo depois desta correção, como única exceção -- mas com a
MESMA ressalva: é igualmente estático ao package esquemático (nenhum dos dois reflete `m_intensity`/
corrente real, gap genuíno do Core, não resolvido por nenhum dos dois packages), então não resolvia o
"LED acende/apaga" que o usuário perguntou. **Decisão do usuário (mesma sessão, minutos depois):
remover também, por consistência** -- ver seção 27.10.

**Testes**: `componentSymbols.test.ts` -- o teste de `switches.push`/`switches.switch` reescrito pra
confirmar exatamente o comportamento revertido (SEM `boardPackage` no catálogo, `componentBox`/
`packageSymbolSvg` com `variant:"board"` caem no package esquemático, que já muda de cor com `closed`).
Suíte completa após a correção: 228/228, 0 falhas (mesma contagem de antes -- teste substituído, não
removido). 3 tsconfigs compilam limpos.

### 27.10 `outputs.led` também revertido -- os 3 tipos originais ficam sem `boardPackage` (2026-07-12)

Usuário confirmou (mesma sessão): remover `boardPackage` de `outputs.led` também, pela mesma lógica de
27.9 -- não resolve o problema real (LED não acende porque falta intensidade real do Core, não porque
falta forma redonda), e mantê-lo só pelos outros dois terem sido revertidos criaria inconsistência sem
motivo (um typeId com aparência própria estática, os outros dois reaproveitando o esquemático).

**Estado final desta rodada**: `component-catalog.json` não tem MAIS NENHUM `boardPackage` registrado
(nenhum dos 59 itens) -- `switches.push`/`switches.switch`/`outputs.led` todos caem no package
esquemático (já físico onde já era físico no SimulIDE real, ainda abstrato/estático onde o SimulIDE
real também é, caso do LED) via `boardX`/`boardY`/etc, exatamente como o SimulIDE faz. O MECANISMO
`boardPackage` (`componentSymbols.ts::BOARD_PACKAGE_BY_TYPE_ID`, `registerPackage`'s 4º argumento,
`variant?: "board"` em `resolvedPackageFor`/`componentBox`/`packageSymbolSvg`, `boardWidth`/
`boardHeight` em `WebviewComponentModel`) **continua no código, funcional e testado** (seção 27.8) --
não foi removido, só ficou sem nenhum usuário real no catálogo por ora. Antes de registrar um
`boardPackage` pra um typeId futuro, confirmar primeiro (27.9) se o `paint()` real do SimulIDE pra essa
classe já é físico e dinâmico por si só (a maioria dos `m_graphical` é) -- só vale a pena inventar uma
aparência nova quando o símbolo esquemático real for genuinamente abstrato/elétrico E não existir
nenhuma foto/forma física correspondente em lugar nenhum do C++ real pra reaproveitar.

**Correção de processo registrada em memória** (não `.spec`, mas relevante pra sessões futuras): ao
reverter o `boardPackage` do LED, um round-trip via `json.dump()` do Python (só pra remover 2 campos)
reformatou números não relacionados no arquivo inteiro (notação científica), e o reflexo de rodar
`git checkout --` pra desfazer só esse efeito colateral apagou TODO o trabalho não commitado da sessão
no arquivo (não só o efeito colateral) -- recuperado manualmente porque o conteúdo tinha acabado de
aparecer num `git diff` anterior. Reversões subsequentes usaram edição cirúrgica de texto (Edit tool),
nunca mais um round-trip de arquivo inteiro nem `git checkout` em arquivo com trabalho não commitado.

**Verificação final**: suíte completa 228/228 (2 testes a mais reescritos, mesma contagem), 3
tsconfigs compilando limpos, `component-catalog.json` validado como JSON íntegro (59 itens) após as
duas remoções cirúrgicas.

## 28. Bug de empacotamento: CSS dos webviews ausente no VSIX gerado pelo workflow (2026-07-12)

Usuário reportou (2 screenshots comparando lado a lado): a paleta de componentes compilada localmente
(F5/Extension Development Host) mostra uma LISTA de 1 coluna; a mesma paleta, instalada a partir do
`.vsix` gerado pelo `package-installers.yml` (mesmo commit, confirmado via `gh run view` -- não é
questão de versão desatualizada), aparece como uma GRADE de vários ícones por linha, sem nenhum
estilo aparente.

### 28.1 Causa raiz

`SchematicPanel.ts:115` e `ComponentPaletteViewProvider.ts:107` montam o HTML do webview **em tempo de
execução** referenciando o CSS DIRETO da pasta `src/` do código-fonte:

```ts
vscode.Uri.joinPath(this.extensionUri, "src", "ui", "webview", "styles.css")   // SchematicPanel.ts
vscode.Uri.joinPath(this.extensionUri, "src", "ui", "palette", "styles.css")   // ComponentPaletteViewProvider.ts
```

Isso funciona em DEV (F5) porque `extensionUri` aponta direto pra pasta `extension/` do repositório --
`src/ui/webview/styles.css` existe ali, sempre atualizado. Mas o `compile` do `extension/package.json`
é só `tsc -p ./ && tsc -p ./tsconfig.webview.json` -- `tsc` NUNCA copia `.css`, só processa `.ts`/
`.tsx`. E `scripts/package-release.js::stageExtensionFiles()` só copiava `out`/`out-webview`/`media`
pro pacote staged -- **nunca `src/`**. `rewriteStagedPackageJson()`'s `pkg.files` (o que `vsce package`
de fato inclui no `.vsix`) também nunca tinha um glob pra `src/**`. Resultado: os dois `styles.css`
NUNCA existiram no `.vsix` publicado -- só no repositório fonte. No pacote instalado, `<link
rel="stylesheet" href="...">` aponta pra um recurso inexistente, o webview carrega SEM NENHUM CSS
custom, e o navegador cai no layout padrão: `<button class="palette-item">` sem `display:flex`
declarado vira `inline-block` (padrão de `<button>`), e vários botões inline-block em sequência
naturalmente quebram linha e "empilham" em grade -- exatamente a grade vista no screenshot, sem
precisar de nenhuma regra CSS própria pra isso, é só o navegador sem estilo nenhum. O MESMO bug afeta
o editor de esquemático principal (`SchematicPanel.ts`), não só a paleta -- provavelmente também
aparece sem estilo algum na versão instalada, mesmo sem o usuário ter reportado ainda.

### 28.2 Correção

`scripts/package-release.js::stageExtensionFiles()` -- adicionados os 2 arquivos à lista `filesToCopy`
(`src/ui/webview/styles.css`, `src/ui/palette/styles.css`), copiados pro staging preservando o MESMO
caminho relativo `src/ui/...` (não precisa mudar nenhum `vscode.Uri.joinPath` em runtime, só garantir
que o arquivo exista onde o código já espera). `rewriteStagedPackageJson()`'s `pkg.files` ganhou os 2
caminhos explícitos, pra `vsce package` de fato incluir esses arquivos no `.vsix` (globs `out/**/*` etc
não cobririam `src/`).

Verificado por simulação isolada da lógica de cópia (Node ad-hoc, fora do pipeline completo -- rodar
`package-release.js` de ponta a ponta exige compilar Core/devices/MCU adapters nativos, pesado demais
pra esta verificação pontual): os 2 arquivos existem nos caminhos fonte esperados e a cópia produz o
destino correto. `node --check scripts/package-release.js` confirma sintaxe válida.

### 28.3 Correção relacionada: versão do pacote nunca refletia a tag da release

Investigação paralela (antes de achar a causa real acima) revelou um problema de processo genuíno,
mesmo não sendo a causa principal deste bug: `extension/package.json` ficava travado em `0.0.1`
independente da tag Git da release (`v0.0.1`, `v0.0.3` etc) -- o job `release` de
`package-installers.yml` só cria a tag no Git (`git tag`/`git push`), nunca escreve a versão de volta
em `package.json`. Corrigido: novo passo "Sync extension version with release tag" no job `package`,
que escreve a versão (do input `workflow_dispatch` ou de `github.ref_name` no push de tag, sem o
prefixo `v`) em `extension/package.json` **e** `extension/package-lock.json` (`npm ci` valida que os
dois batem, senão falha com "not in sync") -- só no checkout efêmero do runner, nunca commitado de
volta ao repositório. Relevante porque, mesmo corrigido o CSS, o VS Code só detecta uma extensão como
"atualizada" (e força reload de webviews abertos) quando o número de versão muda de verdade.

### 28.4 Ação imediata recomendada ao usuário (independente do fix de código)

Reinstalar via `code --install-extension ... --force` reescreve os arquivos em disco mas NÃO recarrega
um VS Code já aberto -- extension host e `WebviewView` continuam servindo o conteúdo antigo em memória
até "Developer: Reload Window" ou reiniciar o editor inteiro. Recomendado fechar todas as janelas do VS
Code e reabrir após qualquer reinstalação, não confiar só no `--force` do instalador.

### 28.5 Bug menor encontrado de bônus: ícone ausente de `other.package_pin`

`other.package_pin` referenciava `icon: "package-pin"`, sem nenhum arquivo `.svg`/`.png`
correspondente em `media/components/{light,dark}/` -- caía silenciosamente no fallback
`generic-component`. Criados `package-pin.svg` (light e dark), mesmo estilo/paleta de cores do
`package.svg` existente (retângulo do encapsulamento + 1 pino em destaque com um ponto de solda).
Bug pré-existente, presente igualmente em dev e instalado (não relacionado à causa raiz de 28.1).

## 29. Auditoria completa dos 59 dispositivos vs SimulIDE real (2026-07-13)

Pedido explícito do usuário: varredura completa de TODA categoria/dispositivo registrado, comparando
representação esquemática, Modo Placa, propriedades configuráveis, comportamento elétrico e
persistência contra o SimulIDE real, com evidências concretas (2 screenshots de `outputs.led_bar`
mostrando propriedades ausentes: Cor, lógica de acionamento, GND/VCC do comum, estado visual).

### 29.1 Metodologia

Dado o tamanho (59 dispositivos, 15 categorias), a pesquisa foi paralelizada: 7 agentes em background
(um por categoria: Switches, Motors/Other Outputs, Active, Passive, Sources, Meters, Connectors+Other+
Graphical), cada um lendo o C++ real do SimulIDE (`C:\SourceCode\simulide_2\src`) e comparando contra
`component-catalog.json`/`core/src/app/CoreApplication.cpp`/`core/src/components/**`, devolvendo
achados citados por arquivo:linha (nunca "poderia melhorar" vago). Em paralelo, eu mesmo fiz um
mergulho profundo e uma reescrita real na categoria com evidência concreta do usuário (Leds). Depois
dos 7 relatórios prontos, apliquei um subconjunto de correções de ALTA confiança (JSON/constante
isolada, sem redesenho de arquitetura) diretamente; o resto fica documentado como pendência com
justificativa técnica precisa (não uma correção rasa/forçada só pra "fechar item").

**Achado transversal repetido em quase toda categoria** (não é um bug isolado, é um padrão): muitos
componentes (`dc_motor`/`stepper`/`incandescent_lamp`, `outputs.led` antes desta rodada, `active.diode`
parcialmente) são modelados no Core como um `Resistor`/`ResistorArray` genérico, sem NENHUM estado
dinâmico (ângulo do rotor, brilho, corrente máxima) exposto -- então o `package.simulidePaint`
correspondente é necessariamente estático, mesmo quando o `paint()` real do SimulIDE é dinâmico. Corrigir
isso caso a caso não escala; o padrão certo (aplicado em 29.2) é generalizar no MODELO ELÉTRICO
primeiro (Core), não inventar bindings visuais sem dado real por trás.

### 29.2 Outputs > Leds -- reescrita real (led, led_rgb, led_bar, led_matrix, seven_segment)

**Causa raiz encontrada**: `outputs.led` usava a classe `Diode` (exponencial de Shockley, certa pra
`active.diode`/`active.zener`, ERRADA pro LED real). O LED real do SimulIDE (`eLed::voltChanged()`,
`simulator/elements/outputs/e-led.cpp`) é um modelo PIECEWISE totalmente diferente: abaixo de
`threshold` a perna está essencialmente aberta (condutância de fuga `1e-9`); acima, conduz como um
resistor linear (`resistance`) ancorado exatamente no joelho `(threshold, 0)` via uma fonte de corrente
companion. `led_rgb`/`led_bar`/`led_matrix`/`seven_segment` usavam `DiodeLegArray` (mesma exponencial,
N pernas) com `propertyDescriptors()` retornando `{}` -- ZERO propriedades editáveis, confirmando
exatamente o que o usuário reportou pro Led Bar (sem Cor, sem lógica de acionamento, sem indicar
GND/VCC do comum).

**Corrigido**: `core/src/components/active/DiodeLegArray.hpp` reescrita -- `stamp()` agora usa o modelo
piecewise real (não a exponencial), com propriedades REAIS `Color` (enum, 7 cores, mesmos labels de
`LedBase::getColorList()`), `Threshold` (V, também setável direto, Color só é um preset -- Threshold
salvo pelo usuário nunca é sobrescrito num reload, ver `applyLedProperties` em
`CoreApplication.cpp`), `Resistance` (Ω) -- as MESMAS 3 propriedades pros 5 typeIds de uma vez só
(generalização no sistema comum, não 5 correções isoladas). `outputs.led` migrado de `Diode` (2 pinos
dedicados) pra `DiodeLegArray` com 1 perna só -- unifica a família inteira numa classe e ganha
`current()` de verdade (só existe leitura de corrente via `getComponentCurrent`/IPC quando
`legs.size()==1`, honesto sobre não fingir uma leitura por segmento nos outros 4).

**Simplificações documentadas (não escondidas)**: `Color`/`Threshold`/`Resistance` são UNIFORMES pro
componente inteiro -- fiel ao real `LedBar`/`LedMatrix`/`SevenSegment` (que também aplicam um único
valor a todos os segmentos de uma vez, `ledbar.cpp::setColorStr` propaga a MESMA cor a cada `m_led[i]`,
nunca por-segmento individual -- então "cor individual por LED" que o usuário pediu como opção NÃO é
sequer um recurso do SimulIDE real pra estes tipos, só "geral" existe). `led_rgb` real tem
`Threshold_R/G/B`/`MaxCurrent_R/G/B`/`Resistance_R/G/B` (9 propriedades por-canal) + `CommonCathode`
(toggle Common Anode) -- aqui simplificado pra um valor uniforme + catodo comum fixo, documentado como
pendência (não implementado). `seven_segment` real tem `NumDisplays`/`Vertical_Pins`/`CommonCathode`
-- não portados. `MaxCurrent`/`Grounded` do LED real (que dirigem só a visual de brilho/GND, sem
efeito na equação `stamp()`) foram DELIBERADAMENTE deixados de fora desta rodada -- adicionar uma
propriedade sem efeito observável nenhum ainda violaria a regra do próprio pedido do usuário
("garanta que cada propriedade esteja realmente conectada ao comportamento"); a leitura viva de
brilho (`current()`→intensidade→`stateFill`) que daria sentido a `MaxCurrent` é um recurso de telemetria
NOVO que não existe hoje pra nenhum componente arbitrário (só instrumentos com `readoutFormat`
registrado têm sincronização ao vivo -- ver 29.9).

**Catálogo**: `defaultProperties` dos 5 typeIds atualizado (`color:"Yellow"`, `threshold:2.4`,
`resistance:0.6`, batendo com os defaults reais de `eLed::eLed()`) -- removidos os pares
`threshold`/`resistance` "mortos" que existiam antes sem NENHUM backing real (`outputs.led` tinha
`{threshold:2,resistance:1}` mas o Core só lia `saturationCurrent`; `outputs.led_rgb` tinha só
`{threshold:2}` sem nenhuma propriedade real atrás).

**Testes**: `core/test/zener_led_test.cpp` reescrito -- `testLedForwardVoltage` agora valida o joelho
piecewise real (Vd converge em ~2.4046V com R=1k+fonte 10V, não mais a faixa larga 1.0-3.0V do modelo
exponencial antigo); novo `testLedColorChangesThreshold` prova que `Color="Red"` muda o threshold de
simulação pra ~1.8V de verdade (não é rótulo decorativo).

### 29.3 Correções aplicadas em outras categorias (alta confiança, baixo risco)

- **`switches.push`**: barra do atuador solto desenhava em y=-8, real é y=-6 (`push.cpp:125`) --
  corrigido no `package.simulidePaint` e no teste.
- **`switches.switch_dip`**: default `closed:false` deveria ser `true` (`switchdip.cpp:194`, todas as
  8 posições nascem fechadas no real); housing desenhava `fill:"none"`, real é preenchido `#646478`
  (`QColor(100,100,120)`, `switchdip.cpp:47` + `Component::paint()` real sempre pinta com `m_color`).
- **`switches.keypad`**: os 7 pinos estáticos e os 2 `pinGroups` dinâmicos foram migrados para
  coordenadas canônicas de terminal; antes, o ponto de fiação ficava 4px deslocado do buraco/traço
  desenhado. Corrigido pelo contrato comum `simulide-terminal-v1`, sem flag ou regra específica do
  keypad; testes que validavam a geometria ANTIGA foram atualizados para validar a posição real.
- **`sources.rail`**: faltava `package.initialTransform` (rotação 90° -- `Rail::Rail()` sempre chama
  `setRotation(90)` no construtor, `rail.cpp:43`) -- mesmo mecanismo já usado por `meters.probe`
  (pivô `(-bounds.x,-bounds.y)`, aqui `(4,8)`).
- **`other.ground`**: ângulo do pino salvo como 270, real é 90 (`ground.cpp:33`, `IoPin(90,...)`) --
  corrigido por fidelidade de fonte, embora `length:0` torne isto sem efeito visual observável hoje.
- **`instruments.voltmeter`**: impedância de entrada 10x abaixo do real (`kInputConductance=1e-6`
  = 1MΩ; real `high_imp=1e7` = 10MΩ, `voltmeter.cpp:29`) -- corrigido em `Voltmeter.hpp`.

### 29.4 Bug pré-existente encontrado (não introduzido nesta sessão, documentado e parcialmente corrigido)

`core/test/esp32_devkitc_subcircuit_test.cpp` tem seu PRÓPRIO registro mínimo de componentes
(`registerNeededBuiltins`, independente de `CoreApplication.cpp`) que nunca incluía `outputs.led_bar`
-- confirmado por `git diff` que este arquivo estava intocado antes desta sessão, e por já existir
NO MESMO ARQUIVO um comentário idêntico sobre `sources.rail` ter tido o mesmo problema antes
("faltava aqui, causando 'Unknown component typeId'"). Corrigido o registro (`DiodeLegArray` com
pernas resolvidas de `p.pinList`) e a derivação de id `pin-P{i}`/`pin-N{i}` (o `.lssubcircuit` real
não embute id por pino em `properties`, só x/y -- confirmado que sem essa derivação os ids ficam
vazios/genéricos, nunca batendo com o que os fios do arquivo referenciam).

**Pendência restante** (mesmo teste, mais funda): mesmo com o id forçado corretamente, o teste ainda
falha com `fio interno inválido component-X.pin-P1 -> component-Y.pin-1: invalid stoul argument` --
rastreado até `SimulationSession::connectWire`/`resolveSlot` (`SimulationSession.cpp:198-210`): o
match exato (`slots.find(pinId)`) não está encontrando "pin-P1" nos slots do componente mesmo com o
`Pin.id` correto no vetor construído pela fábrica, caindo no fallback posicional genérico `pin-N`
(que exige sufixo NUMÉRICO puro via `std::stoul`, e "P1" não é). Não investigado mais fundo por
tempo -- pode ser (a) `m_netlist.pinSlotsOf()` construindo slots a partir de outra fonte que não
`component->pins()` no momento do `addComponent`, ou (b) uma diferença sutil entre o pinList que
`ComponentParams` entrega e o que a fábrica de fato usa. Este teste ISOLADO (só ele, dos 40) segue
falhando -- não é regressão desta sessão (já falhava antes, por um motivo diferente e mais raso),
mas também não foi totalmente resolvido. Ver 29.9.

### 29.5 Achados documentados, SEM correção aplicada (fora do escopo desta rodada -- pendências reais)

Resumo por categoria, prioridade e citação -- detalhe completo nos relatórios dos 7 agentes (não
reproduzidos aqui por tamanho; refazer a mesma pesquisa é barato se necessário, os prompts usados
citam arquivo:linha tanto do SimulIDE real quanto do LasecSimul).

- **Active** (`opamp`/`comparator`/`analog_mux`/`volt_regulator`/`diode`/`zener`): **achado de maior
  severidade potencial de toda a auditoria, NÃO verificado visualmente, NÃO corrigido por precaução**
  -- padrão sistemático em 5 de 6 dispositivos onde o ponto elétrico de cada pino parece estar
  deslocado pelo próprio `length` do lead (ex: `active.diode` pino calculado em `(0,32)` quando devia
  ser `(-6,26)`) -- se confirmado numa sessão com GUI, é um bug de fiação real (fios conectariam no
  lugar errado). `active.comparator` reusa a classe `OpAmp` (5 pinos, ganho) em vez de modelar um
  comparador digital de verdade (real: 3 pinos, sem `Gain`, com `Out_High_V`/`Inverted`/etc) --
  mudança de arquitetura, não catalogada aqui. `active.zener`: `defaultProperties` usa chaves
  (`threshold`/`resistance`) que não correspondem a NENHUMA propriedade real do Core
  (`saturationCurrent`/`breakdownVoltage`) -- silenciosamente ignoradas.
- **Passive**: 2 bugs de geometria CONFIRMADOS rodando o renderer de verdade (não só lidos): pinos de
  `passive.potentiometer` e `passive.resistor_dip` renderizam deslocados do corpo (fios pareceriam
  sair do lugar errado). Família "Dialed" (`variable_resistor`/`variable_capacitor`/
  `variable_inductor`) e família Reactive inteira (`capacitor`/`electrolytic_capacitor`/`inductor`)
  não têm ESR (`Resistance`)/`InitVolt` que o real expõe -- Core só modela capacitância/indutância
  pura.
- **Sources**: `sources.wave_gen` nasce ligado por padrão (`alwaysOn=true`), real nasce desligado.
  `sources.voltage_source`/`sources.current_source` não têm nenhum toggle liga/desliga (fonte sempre
  ativa desde que colocada) -- documentado como simplificação intencional já existente, não nova.
- **Meters**: `meters.oscope` falta o 5º pino de referência (`PinG`) que o real usa pra leitura
  DIFERENCIAL -- LasecSimul lê tensão absoluta ao terra em vez de V(canal)-V(ref); além disso
  `filter`/`autoScale`/`tracks`/`sampleIntervalNs` são descartados silenciosamente a cada reload
  (fábrica nunca lê essas properties de volta). `meters.probe`'s `negativeThreshold` é uma propriedade
  "morta" (só usada no lado visual, sem schema real no Core, nunca editável/sincronizada).
- **Connectors/Other/Graphical**: `connectors.bus` é um stub decorativo de 1 pino sem NENHUMA
  semântica de fan-out multi-bit do `Bus` real (achado de maior severidade da categoria).
  `connectors.socket`/`connectors.header` têm o ponto elétrico dos pinos deslocado +24px e no ângulo
  errado em relação aos buracos desenhados (confirmado, mesma classe de bug do Active). 5 tipos
  `graphics.*` faltam `Opacity` (todos) e `Border`/`strokeWidth` configurável (`ellipse` especificamente,
  inconsistente com `rectangle` que já tem).

### 29.6 Verificação final

Extension: suíte completa **228/228 passando** (2 testes reescritos pra refletir geometria corrigida
de push/keypad, contagem final igual), 3 tsconfigs compilando limpos. Core: **39/40 testes passando**
(`zener_led`/`voltmeter`/`diode` cobrindo as mudanças desta rodada, todos verdes; único vermelho é
`esp32_devkitc_subcircuit`, pré-existente e parcialmente investigado, ver 29.4). Sem GUI disponível
neste ambiente -- os 2 bugs de geometria de Passive foram confirmados executando o renderer de
verdade (não visual), os 5 do Active NÃO foram confirmados visualmente e por isso não foram corrigidos
às cegas.

### 29.7 Pendências e recomendação de próxima rodada

Por ordem de valor esperado:
1. Verificar visualmente (sessão com GUI/Extension Development Host) o padrão sistemático de pinos
   deslocados do Active (5 dispositivos) -- se confirmado, é a correção de maior impacto restante
   (fiação visualmente errada, não só cosmético).
2. Corrigir os 2 bugs de geometria confirmados do Passive (`potentiometer`/`resistor_dip`) -- mesma
   classe de bug do Active, já com posições corretas calculadas nos relatórios dos agentes.
3. Investigar a fundo `SimulationSession::connectWire`/`resolveSlot` (29.4) -- possível bug real de
   resolução de pino por id fora do fallback puramente numérico, não só um problema do teste.
4. Telemetria de corrente/intensidade genérica (não só pros LEDs) -- generalizaria o binding visual
   dinâmico pra motor/lâmpada/LED de uma vez, resolvendo o achado transversal da seção 29.1.
5. `connectors.bus` como componente real (fan-out multi-bit) -- maior gap funcional isolado
   encontrado.

### 29.8 Errata normativa e fechamento das pendencias prioritarias (2026-07-13)

Esta secao registra o estado final posterior a 29.4--29.7 e **substitui expressamente** as indicacoes
de pendencia e os resultados de testes ali documentados para os itens abaixo. As secoes anteriores
permanecem apenas como historico da auditoria e da investigacao.

#### 29.8.1 Geometria e referencia de coordenadas

Confirmou-se que a causa raiz do deslocamento visual nao era uma translacao arbitraria do renderer,
mas a mistura de duas convencoes no catalogo: algumas coordenadas descreviam o contato com o corpo e
outras ja descreviam o terminal eletrico. A correcao sistemica e o contrato
`simulide-terminal-v1`, definido em 13.1.1: toda coordenada `PackagePin.x/y` e o terminal eletrico,
enquanto o contato com o corpo e derivado de `angle`/`length` pela infraestrutura comum. Nao existe
flag que altere a semantica eletrica por dispositivo, `leadOrigin` no modelo canonico nem helper
geometrico duplicado. `coordinateSpace: "simulide-local"` apenas declara que todo o pacote conserva
o referencial nativo (`QPoint`/`m_area`); ele aciona a mesma normalizacao de corpo, pinos e labels e
nao constitui uma formula ou offset especial do dispositivo.

- `active.diode`, `active.zener`, `active.opamp`, `active.comparator`,
  `active.volt_regulator`, `outputs.led`, `outputs.led_rgb`, `outputs.led_bar`,
  `outputs.led_matrix` e `outputs.seven_segment` foram migrados como consumidores do mesmo contrato;
  nao constituem excecoes. O ponto visual e o ponto logico coincidem nas rotacoes 0, 90, 180 e 270
  graus e sob espelhamento.
- Em `led_bar`/`led_matrix`, o layout parametrico tambem corrige a caixa resolvida: os pinos deixam de
  puxar artificialmente o topo do componente e expandem apenas os lados/borda onde o terminal existe.
- `active.comparator` deixou de reutilizar o modelo de `OpAmp` de cinco pinos. Passou a ser um
  comparador real de tres pinos (`in+`, `in-`, `out`), com `outputHighVoltage` e `inverted` ligados
  ao comportamento eletrico.
- `passive.potentiometer` teve os dois terminais laterais e o terminal do cursor alinhados ao desenho
  real; `passive.resistor_dip` teve as origens de corpo/lead corrigidas e normalizadas pelo bounds.
- Rotacao, posicao e propriedades desses tipos continuam persistidas e reconstruidas sem alterar a
  topologia eletrica.

As coordenadas foram derivadas diretamente das fontes do SimulIDE para diodo, amplificador
operacional, comparador, regulador, potenciometro e resistor DIP, e validadas pelo mesmo resolvedor
usado pela Webview, incluindo limites do simbolo e coincidencia terminal/logica.

#### 29.8.2 Barramento funcional (`connectors.bus`)

`connectors.bus` deixa de ser um stub decorativo e passa a ser um endpoint vetorial real. A convencao
normativa e:

- largura configuravel de 1 a 64 bits e propriedade `startBit`;
- ordem LSB-first: o indice interno 0 representa `bit-startBit`; visualmente o vetor representa
  `[startBit + width - 1 : startBit]`;
- `bus-in` e `bus-out` sao aliases vetoriais equivalentes para os mesmos bits escalares ordenados;
- conexao vetor-vetor exige larguras iguais e expande, na compilacao da topologia, para pares de
  slots escalares; incompatibilidade de largura e rejeitada com erro explicito;
- split e merge sao feitos conectando `bit-N` individualmente ou conectando os endpoints vetoriais;
- bits desconectados permanecem em nivel baixo pela condutancia de fuga do modelo, sem estado
  indefinido; a leitura de estado expoe uma mascara digital de 64 bits com limiar de 2,5 V;
- alteracoes de `width` ou `startBit` afetam pinagem/topologia e exigem a recompilacao normal do
  grafo; conexao, desconexao e rebuild preservam o mapeamento deterministico;
- largura, bit inicial e fios sao persistidos pelo mecanismo generico do projeto. A representacao
  visual gera `bit-0` corretamente (sem o antigo fallback indevido para `bit-1`).

Essa solucao evita copiar valores por evento entre objetos: o barramento e resolvido para os mesmos
nos/slots escalares na topologia MNA, mantendo o caminho de simulacao compacto e sem alocacao por
passo.

#### 29.8.3 Osciloscopio e persistencia generica de instrumentos

`meters.oscope` agora possui os cinco pinos do SimulIDE: quatro canais e a referencia comum. Quando o
quinto pino esta conectado, cada canal mede `V(canal) - V(ref)` e os companions de entrada sao
carimbados entre canal e referencia. Quando ele esta desconectado, o comportamento legado e mantido:
a referencia equivale ao GND, evitando quebrar projetos antigos de quatro fios.

A hidratacao inicial de propriedades em `SimulationSession::addComponent` foi generalizada: todo
parametro cujo nome corresponda a um descritor do componente e aplicado ao modelo. Com isso,
`filter`, `autoScale`, `tracks`, `sampleIntervalNs` e as propriedades equivalentes dos demais meters
nao dependem mais de whitelists por fabrica e sobrevivem ao ciclo salvar/carregar.

#### 29.8.4 Subcircuitos, identificadores semanticos e ciclo de vida

A falha de `esp32_devkitc_subcircuit_test` foi eliminada. A causa raiz era a perda de `pinList` antes
da instanciacao do componente interno: os fios conservavam identificadores como `pin-P1`, mas o
netlist so possuia a pinagem generica reconstruida. A expansao de subcircuito agora recompõe a lista
de pinos a partir dos metadados, da especificacao de pinos e de todos os identificadores semanticos
referenciados pelos fios antes de criar o modelo. O fallback numerico de `connectWire` tambem valida
o sufixo e retorna erro de pino inexistente, em vez de deixar escapar `std::stoul`.

Durante a validacao foi encontrada e corrigida uma segunda causa independente: a hidratacao generica
podia aplicar `Clock.alwaysOn` antes de o componente receber um indice, marcando `UINT32_MAX` como
dirty e fazendo a estrutura esparsa tentar crescer excessivamente. `Clock` agora agenda/marca apenas
depois de ter indice valido. O pool de memoria deixa de ser pressionado por essa inicializacao.

#### 29.8.5 Contratos de arquitetura

O contrato de componente ganhou dois pontos deliberadamente pequenos e gerais:

- `busEndpointPinIds(endpoint)` descreve, quando aplicavel, a expansao ordenada de um endpoint
  vetorial; componentes escalares continuam retornando vazio e nao sofrem custo adicional;
- `onPinConnectionChanged(pinIndex, connected)` informa o estado de conexao externa apos cada rebuild,
  permitindo ao osciloscopio escolher referencia diferencial ou compatibilidade com GND sem consultar
  objetos da interface.

Esses contratos mantem a resolucao no Core, separada da Webview, e nao introduzem `new`, tarefas ou
IPC no loop de simulacao.

#### 29.8.6 Validacao final que substitui 29.6

- build completo do Core em Debug concluido com sucesso (MSVC, paralelismo 2);
- suite completa do Core: **41/41 testes passando**, incluindo o teste ESP32/subcircuito antes
  vermelho e a nova cobertura de barramento;
- barramento coberto por padrao de 8 bits `0xA5`, leitura/escrita por bit, vetor de mesma largura,
  rejeicao 8-vs-4, split/merge, desconexao/reconexao, rebuild e mascara de estado;
- osciloscopio coberto em modo legado (referencia desconectada) e diferencial (`3,3 - 1,3 = 2,0 V`),
  alem de historico e hidratacao de propriedades;
- suite completa da Extension concluida sem falhas, com os tres tsconfigs compilando; testes do
  renderer de simbolos: **58/58 passando**, incluindo os cinco ativos nas quatro rotacoes, as duas
  geometrias passivas e os bits visuais do barramento;
- serializacao cobre round-trip generico das propriedades de todos os meters e round-trip de
  posicao/rotacao das geometrias alteradas.

Nao restam pendencias funcionais dentro do escopo solicitado nesta rodada: geometria dos cinco ativos
e dos dois passivos, barramento multi-bit, referencia diferencial do osciloscopio, persistencia de
meters e falha do subcircuito ESP32 estao implementados e cobertos. Itens mais amplos ja listados em
29.5 (por exemplo telemetria visual generica de motores/lampadas ou novas propriedades de familias
reativas) continuam sendo evolucoes separadas e nao bloqueiam este fechamento.

### 29.9 Interface expandida comum dos instrumentos (2026-07-13)

Os popups de `meters.oscope` e `meters.logic_analyzer` compartilham obrigatoriamente a mesma
infraestrutura visual (`instrument-popup`, chassis, cabecalho, bezel do plot, secoes de controle,
legenda e comportamento responsivo). Eles nao devem voltar a manter layouts ou temas independentes.
A estrutura funcional do SimulIDE permanece como referencia: plot 10 x 8, controles laterais,
canais identificados por cor, base/posicao de tempo, escala/posicao de tensao e disparo.

Contrato do renderer de instrumentos:

- a grade possui divisoes principais, cinco subdivisoes menores e eixos centrais distintos;
- traces analogicos sao continuos e traces digitais usam sample-and-hold ortogonal, sem diagonais
  entre estados logicos;
- a legenda deriva das mesmas cores e do mesmo estado de visibilidade usados pelo trace;
- os controles continuam ligados ao estado persistente existente; a reformulacao visual nao cria
  uma segunda fonte de estado nem altera o protocolo Core/Webview;
- em viewport estreito os controles passam para baixo do plot e o SVG preserva a proporcao 10:8,
  sem corte ou overflow horizontal obrigatorio;
- novas funcoes comuns devem ser adicionadas aos helpers de instrumentos em `main.ts` ou
  `instrumentTrigger.ts`, nunca copiadas separadamente para os dois popups.

`digitalStepPath` e coberto por teste puro que exige arestas verticais e patamares horizontais. A
suite completa da Extension, incluindo compilacao dos tres tsconfigs, deve permanecer verde.

### 29.10 Canais de instrumentos por nome de Tunnel (2026-07-13)

Oscope e Logic Analyzer devem aceitar, em cada campo colorido, o nome de um `connectors.tunnel` da
mesma sessao. A referencia normativa e o SimulIDE real:

- `src/gui/dataplotwidget/datawidget.cpp:71-88`: `QLineEdit::editingFinished` chama
  `Oscope::channelChanged`, e `setTunnel` restaura o texto;
- `src/gui/dataplotwidget/datalawidget.cpp:54-83`: mecanismo identico nos oito canais digitais;
- `src/gui/dataplotwidget/plotbase.h:86` e `plotbase.cpp:239-244`: cada `DataChannel` guarda
  `m_chTunnel` e a propriedade `Tunnels` serializa a lista;
- `src/components/meters/oscope.cpp:129-141` e `logicanalizer.cpp:139-153`: primeiro verifica o
  conector fisico; somente se estiver desconectado chama `Tunnel::getEnode(nome)`;
- `src/components/meters/oscope.cpp:210-217` e `logicanalizer.cpp:292-299`: `setTunnels` hidrata os
  canais e os campos ao reabrir.

No LasecSimul, `IComponentModel::fallbackTunnelNameForPin` e `Netlist::setFallbackTunnelName`
generalizam essa semantica. Um fallback nao cria uma rede sozinho: ele so se une a um grupo criado
por Tunnel real do mesmo nome. Um fio fisico no pino desativa o fallback; ao remover o fio, o nome
persistido volta a valer automaticamente. A propriedade `tunnels` e uma lista CSV com exatamente
um campo por canal e participa do salvar/carregar generico.

Os campos compactos sao inputs reais em `foreignObject`, portanto acompanham as transformacoes SVG
do componente. As janelas expandidas expoem os mesmos valores, sem segunda fonte de estado. Testes
obrigatorios cobrem nome existente, nome inexistente, prioridade de fio, reativacao apos desconectar,
round-trip e renderizacao dos inputs.

#### 29.10.1 Layout compacto do Logic Analyzer

`DataLaWidget.ui` e a fonte normativa do empilhamento: oito `QLineEdit` de 60 x 14 e
`QVBoxLayout::spacing = 2`, seguidos por `CustomButton` de 60 x 16. A posicao vertical deve ser
derivada desses valores. Para o layout nativo atual, o oitavo canal ocupa `y=120..134` e o botao
comeca em `y=136`. A antiga constante `y=132` era incorreta e sobrepunha duas unidades do ultimo
campo verde. Teste de markup deve impedir a reintroducao dessa sobreposicao.

### 29.11 Janelas expandidas de instrumentos em tempo real (2026-07-13)

Esta secao substitui o escopo apenas visual de 29.9 por um contrato funcional verificavel. O
baseline anterior a implementacao foi comparado diretamente com o SimulIDE local de referencia:

| Aspecto | SimulIDE | baseline do LasecSimul | requisito normativo |
|---|---|---|---|
| composicao | `OscWidget`/`LaWidget` (`QDialog` + `.ui`) hospedam um `PlotDisplay` comum | popup DOM com SVG fixo de 560 x 448 | chassis responsivo e viewport comum, dimensionado pelo espaco real |
| desenho | `PlotDisplay::paintEvent` usa `QPainter`, `QPen` e antialiasing | SVG recriado integralmente em cada atualizacao | camada de plot reutilizavel, sem bloquear a thread da Webview |
| grade | 10 divisoes de tempo, trilhas/8 linhas e marcas centrais | 10 x 8 com subdivisoes, mas dimensao rigida | 10 divisoes, eixos e marcas conservados em qualquer tamanho |
| navegacao | `wheelEvent` altera `timeDiv` em 20% e ancora o tempo sob o cursor; arrasto horizontal altera `timePos` | somente knobs/campos | wheel ancorado, pan horizontal e reposicionamento do zero de tempo |
| medicoes | cursor, tempo e tensao sob o mouse; maximos/minimos analogicos | sem cursor nem leituras no plot | crosshair e leituras derivados da mesma transformacao tempo/valor |
| traces | sample-and-hold e decimacao min/max; digital ortogonal; barramento com hexadecimal | analogico diagonal; digital ortogonal | analogico sample-and-hold com envelope por pixel; digital/bus sem diagonais |
| redimensionamento | layouts Qt e `PlotDisplay::updateValues()` usam `width()`/`height()` correntes | tamanho fixo, apenas fallback CSS estreito | resize livre, limites minimos e nenhum controle sobreposto |
| persistencia | propriedades do `PlotBase`/instrumento guardam escalas, posicoes, trigger, canais e tunnels | a maior parte do estado vive apenas no `Map` aberto | estado de viewport/controles/janela serializado no componente |
| ciclo de simulacao | o componente atualiza o buffer; a janela apenas apresenta; ao pausar o ultimo quadro permanece | polling IPC assincrono ja desacoplado | preservar polling assincrono, congelar na pausa e continuar/reiniciar sem timer de UI concorrente |

Referencias normativas exatas do SimulIDE:

- `src/gui/dataplotwidget/plotdisplay.cpp:19-60`, construcao, cores, fontes e mouse tracking;
- `plotdisplay.cpp:67-105`, janela temporal e geometria recalculada pelo tamanho real;
- `plotdisplay.cpp:108-132`, zoom de wheel ancorado no cursor;
- `plotdisplay.cpp:135-179`, grade, eixos, trilhas e marcas;
- `plotdisplay.cpp:181-340`, pintura, cursor, sample-and-hold e decimacao min/max;
- `oscwidget.h:15` e `lawidget.h:16`, dialogs Qt; `oscwidget.cpp:13-81` e
  `lawidget.cpp:15-41`, grupos de canais e controles;
- `oscwidget.cpp:378-399` e `lawidget.cpp:180-201`, pan e zero de tempo;
- `oscope.cpp:160-178` e `logicanalizer.cpp:172-190`, transferencia do mesmo display entre modo
  compacto e expandido;
- `lawidget.cpp:161-170`, exportacao VCD.

A implementacao no LasecSimul deve usar um unico `InstrumentViewport` puro para conversao
tempo/valor/pixel, zoom, pan, cursor e limites; um unico codec versionado de estado persistente; e
um unico chassis responsivo. Osciloscopio e analisador so fornecem configuracao de canais e o
renderer analogico/digital. O estado de UI deve ser salvo numa propriedade reservada `__ui_` para
participar do `.lsproj` sem atravessar nem acoplar o Core de simulacao.

#### 29.11.1 Estado implementado e validacao

`instrumentViewport.ts` e a implementacao comum. A janela usa resize nativo com bounds, o plot
preenche o espaco flexivel, wheel preserva o tempo sob o cursor, arrasto faz pan e botao central
reposiciona o zero. O cursor informa tempo e, no osciloscopio, tensao. Traces analogicos usam
sample-and-hold com envelope min/max limitado por coluna de pixel; digitais permanecem ortogonais.
Atualizacoes de historico substituem apenas o SVG, nunca toda a janela. A propriedade versionada
`__ui_instrumentView` persiste controles e geometria sem atravessar o Core. Stop limpa buffers, pause
conserva o quadro e o analisador exporta VCD em 1 ns.

Validacao obrigatoria cumprida: build Debug do Core concluido; Core 41/41; suite completa da
Extension verde, incluindo `instrumentViewport` (zoom ancorado, pan, clamp, codec, sample-and-hold,
preservacao de pico e VCD), `instrumentTrigger` 11/11 e renderer 63/63.

As antigas pendencias de barramento vetorial, condicao executada no Core e validacao visual real
foram fechadas pelo contrato normativo 29.12 abaixo; este paragrafo nao deve voltar a descrever o
estado anterior como limitacao atual.

### 29.12 Sinais vetoriais, pausa deterministica e E2E real (2026-07-13)

Esta secao substitui as pendencias finais de 29.11.1. A fonte unica de resolucao e o contrato Core
`SignalSubscription` -> `ResolvedSignal`/`SignalDescriptor`; Analyzer e expressoes de pausa nao podem
manter resolvers paralelos. Uma referencia aceita componente/pino, alias, tunnel, barramento inteiro,
elemento (`BUS[3]`) ou intervalo (`BUS[7:4]`). O vetor interno permanece LSB-first; `msb`/`lsb` no
descritor conservam a apresentacao solicitada.

#### 29.12.1 Protocolo IPC v2 e Analyzer vetorial

- `PROTOCOL_VERSION` e 2 nos dois processos; v1 e recusado pelo handshake com mensagem explicita.
- `ReadoutKind::VectorHistory`/`vectorHistory` substitui `bitmaskHistory` para o Analyzer. O legado
  continua decodificavel e vira canais de largura 1 ao carregar; projetos antigos sem
  `signalChannels` materializam os oito pinos fisicos como oito subscriptions escalares.
- `signalChannels` e JSON persistido com `id`, `source`, `label` e `kind`; admite 1..32 canais, cada
  um com 1..64 bits. A UI expande visualmente `DATA` em `DATA[n]`, sem converter o contrato Core em
  canais escalares hardcoded.
- O blob V2 contem mascara escalar legada, magic `LAV2`, versao, descritores (id/label/source/kind,
  width/msb/lsb), quantidade e amostras `{timestampNs, packedValues}`. Cada valor usa exatamente
  `ceil(width/8)` bytes; inteiros de 64 bits atravessam JSON de eventos como decimal string para nao
  perder precisao no JavaScript.
- A aquisicao so percorre `m_signalSubscribers`; `wantsResolvedSignalSample(timestamp)` e consultado
  antes de resolver/alocar vetores. Nao ha varredura global nem trabalho de barramento antes do
  intervalo. IPC de notificacao usa fila dedicada, nunca bloqueia o scheduler.

#### 29.12.2 Linguagem e instante semantico da pausa

`PauseExpression` implementa lexer, parser, AST e avaliador deterministico, sem `eval`. Gramática:
literais decimais/hex/booleanos; `!`, `&&`, `||`; `==`, `!=`, `<`, `<=`, `>`, `>=`; parenteses;
referencias; `V(x)`, `digital(x)`, `I(x)`, `rising(x)` e `falling(x)`. Erros informam coluna e
contexto; simbolos, indices e tipos sao validados pelo mesmo resolver de sinais do Analyzer.

A expressao e avaliada no Core depois de os componentes atualizarem e o settle convergir, depois do
commit do passo aceito e antes do proximo passo. Ao ocorrer `false -> true`, o scheduler pausa
preservando aquele estado e publica `pauseConditionTriggered` com owner, expressao, timestamp e
valores resolvidos. Condicao nivel-alto nao redispara ate voltar a falso. `rising`/`falling` mantem
estado anterior por execucao e e resetado ao registrar/reiniciar. Condicao vazia remove o registro;
erro em runtime (sinal removido/largura alterada) pausa e e notificado uma vez. Retomar libera o
scheduler antes de `start`; a UI publica running antes do request para uma pausa no primeiro passo
nao ser sobrescrita pela resposta tardia de start.

#### 29.12.3 Harness visual normativo

`extension/test/e2e/run-webview-e2e.cjs` deve executar a extensao numa distribuicao VS Code 1.128.0
isolada por `@vscode/test-electron`, abrir a Webview real, carregar a fixture pelo serializer/Core
reais, abrir os dois instrumentos, iniciar sinais deterministas, observar pausa do Core, redimensionar
e reabrir. HTML isolado nao satisfaz este contrato.

Viewport e DPR sao 1440x1000 e 1. Fontes sao aguardadas; animacoes sao desativadas. Baselines
versionados ficam em `extension/test/e2e/snapshots`. `pixelmatch` usa threshold 0,12, ignora AA e
aceita no maximo 0,5% de pixels; expected/actual/diff e `results.json` sao artefatos. Atualizacao de
baseline so ocorre com `UPDATE_SNAPSHOTS=1`; a execucao normal deve comparar sem sobrescrever.

Validacao desta versao: build Debug completo; Core 43/43; Extension completa verde; E2E normal com
0 pixels diferentes nos dois snapshots. Carga Debug de 32 canais x 64 bits x 1024 amostras:
271078 bytes serializados e 49102 us de aquisicao total (aprox. 48 us por amostra extrema). Esse
numero e baseline de regressao, nao promessa de Release; qualquer mudanca deve preservar os gates
de assinantes, intervalo e packing e repetir a medicao.

## 30. Motor único de rótulo — 3 contextos, mesmas garantias (2026-07-18)

Revisão global pedida pelo usuário depois de relatos de labels quebradas "principalmente nos
switches": pediu-se separar explicitamente 3 contextos que não podem se confundir (esquemático
principal, package de subcircuito, circuito interno de "Abrir Subcircuito"), com um único motor
compartilhado entre eles, e um diagnóstico do catálogo inteiro antes de corrigir.

### 30.1 Diagnóstico

O diagnóstico (leitura de código, sem suposição) concluiu que a arquitetura de rótulo já era
majoritariamente compartilhada — o que faltava eram bugs pontuais na mesma base, não um sistema
duplicado por typeId. Achados:

- **Esquemático principal**: já genérico (ver seção 13.3, atualizada). Bugs reais corrigidos numa
  sessão anterior: offset padrão ancorado na borda esquerda em vez de centralizado (grave em corpos
  estreitos como `switches.switch_dip`/`switches.relay`), tamanho de fonte não configurável fora do
  Modo Símbolo, cor default do diálogo não batendo com a cor real do CSS.
- **Circuito interno de um subcircuito** (`subcircuitEditorMode==="circuit"`): já reusa o MESMO
  código do esquemático principal — confirmado que `subcircuitEditorMode` só é checado em 2 pontos
  de todo o sistema de rótulo (`main.ts::renderExternalLabel`/`externalLabelWorldBox`), ambos
  estritos a `symbol.pin` em Modo Símbolo. Nenhum sistema paralelo existe pra switches/LEDs/
  resistores dentro de um subcircuito.
- **Bloqueio do package no esquemático principal**: já correto, sem vazamento. O diálogo de
  propriedades de uma instância de subcircuito colocada (`main.ts::resolvePropertyFields`) só lê
  `catalogEntry.propertySchema` (propriedades declaradas pelo autor do subcircuito/device) — nenhum
  campo de `symbol.pins[]`/`symbol.shapes[]` (o PACKAGE) aparece ali. O mecanismo de "Modo Placa"
  (`exposedComponents[]`/`InternalComponentSnapshot`) expõe COMPONENTES DO CIRCUITO interno (ex: um
  switch interno marcado exposto) — espaço de id disjunto do package, sem relação nenhuma com
  pinos/formas/imagens do símbolo. O único caminho pro package é "Abrir Subcircuito"
  (`requestOpenSubcircuit` → `extension.ts::openSubcircuitForEditingCommand`), que navega pra dentro
  do modo de edição — nunca uma edição inline a partir do esquemático principal. Testado em
  `subcircuitDocument.test.ts` ("propertySchema (instância) e symbol.pins[] (package) nunca colidem
  nem vazam um no outro").
- **Modo "Editar Símbolo"**: aqui sim havia bugs reais de código, únicos que precisaram de
  implementação nova nesta rodada — ver seção 30.2 e `.spec/lasecsimul-subcircuits.spec` seção 23.

### 30.2 O motor compartilhado

`extension/src/ui/webview/componentLabels.ts` é a fonte única de: nomenclatura de propriedade
(`labelPropertyKey`), posição/cor/tamanho padrão (`resolveDefaultExternalLabelOffset`/
`resolveExternalLabelColor`/`genericExternalLabelFontSize`), rotação (`nextLabelRotation`) e — desde
esta rodada — os campos de alinhamento/visibilidade específicos de `symbol.pin`
(`symbolPinLabelPackageFields`, ver seção 23 do subcircuits.spec). É um módulo puro (sem `document`/
`window`), importável tanto pela Webview (`main.ts`) quanto pelo host (`catalog/subcircuitSymbolScene.ts`)
quanto por testes em Node — a MESMA fórmula nos 3 lugares, nunca duplicada à mão (achado real: antes
desta rodada, `compileSymbolScene` (host) e `compileLiveSymbolPins` (`main.ts`, preview ao vivo)
tinham cada um seu PRÓPRIO hardcode de alinhamento, e divergiram entre si sem ninguém perceber —
exatamente a classe de bug que motivou a extração).

As diferenças entre os 3 contextos existem só em PERMISSÃO/ESCOPO, nunca em mecanismo: o
esquemático principal e o circuito interno de um subcircuito chamam os mesmos resolvers pra
qualquer componente comum; o Modo Símbolo os chama só pra `symbol.pin`, com uma persistência
diferente (compila pro `package` do arquivo em vez de `requestUpdateProperty`); e a instância de um
subcircuito colocado no esquemático principal usa o rótulo comum pro seu PRÓPRIO nome (seção 13.3),
nunca tendo acesso aos rótulos internos do package (seção 30.1). Nenhum `if (typeId === "switches...")`
existe em lugar nenhum desse sistema.

## 31. Bug real: F5 "não mostra" mudanças da Webview mesmo depois de recompilar (2026-07-18)

Usuário reportou repetidamente que features já implementadas nesta sessão (rótulos expostos
arrastáveis, checkbox "Mostrar valor" da seção 13.3) não apareciam depois de F5 — suspeita de
"re-render/estado", não de lógica. Diagnóstico encontrou **dois** bugs reais e independentes na
fronteira host↔Webview, nenhum deles na lógica da Webview em si (que sempre esteve correta):

### 31.1 `SchematicPanel` nunca recarregava o script ao reexibir um painel retido

`SchematicPanel.createOrShow` (`src/ui/panels/SchematicPanel.ts`), ao encontrar `SchematicPanel.current`
já existente, só chamava `panel.reveal(...)` — nunca reatribuía `webview.html`. Com
`retainContextWhenHidden`, o contexto JS carregado é o mesmo desde a primeira criação do painel
NESTA sessão do VS Code; recompilar `out-webview/main.js` sem fechar a aba do esquemático antes não
tinha efeito algum. **Corrigido**: `createOrShow` agora compara o `mtime` de `out-webview/main.js`
contra o que foi carregado da última vez (`lastRenderedScriptMtimeMs`) e só força `render()` de novo
quando o arquivo mudou de fato — uso normal (trocar de aba e voltar) continua sem recarregar,
preservando undo/seleção/zoom. `ready` é resetado pra `false` nesse caminho, já que `render()` mata
o handshake `webviewReady` antigo; sem isso a mensagem `syncState` seguinte se perderia, despachada
antes do listener da Webview NOVA existir.

### 31.2 Erro de tipo no HOST silenciosamente travava a Webview inteira (achado mais sério)

`extension/package.json`'s `compile` era `"tsc -p ./ && tsc -p ./tsconfig.webview.json"`. Como
`noEmitOnError` não está setado em `tsconfig.json` (default `false`), `tsc` do HOST ainda emite
`out/` mesmo com erro de tipo — mas sai com código != 0, e o `&&` faz o `tsc` da WEBVIEW nunca
rodar. Host e Webview são unidades de compilação totalmente independentes (tsconfigs/runtimes
diferentes, uma não lê o `.js` emitido da outra, só `.ts` fonte compartilhado) — não havia razão
nenhuma pra uma depender do sucesso da outra. Resultado: **qualquer** erro de tipo em **qualquer**
arquivo do host (mesmo sem relação nenhuma com a mudança sendo testada) fazia `out-webview/main.js`
congelar silenciosamente no último build com sucesso, até o erro do host ser corrigido — reproduz
exatamente "aperto F5 várias vezes, nada muda", porque o arquivo em disco genuinamente não mudava.

**Corrigido**: `extension/scripts/compile.js` (novo) roda os dois `tsc` SEMPRE, incondicionalmente,
via `spawnSync(process.execPath, [require.resolve("typescript/bin/tsc"), "-p", tsconfigPath])` (não
depende de PATH/shell, funciona idêntico em cmd.exe/PowerShell/sh) — só propaga falha
(`process.exitCode`) no final, preservando "compile falha ⇒ pretest/CI falham". Verificado
empiricamente: com um erro de tipo deliberado injetado em `extension.ts`, `npm run compile` sai com
código 1 (erro reportado) mas `out-webview/main.js` É recompilado mesmo assim (mtime avança).
`.vscode/tasks.json`'s `"npm: compile"` (preLaunchTask do F5) não precisou mudar — só o `detail`
descritivo — continua rodando `npm run compile`, que agora é este script.

### 31.3 Cache de recurso da Webview (mitigação defensiva)

`webview.asWebviewUri(scriptPath)` devolve sempre a MESMA URL `vscode-webview-resource://...` pro
mesmo caminho — o cache HTTP do Chromium embutido pode, em tese, servir uma resposta antiga pra essa
URL mesmo depois de `render()` genuinamente rodar de novo (o `nonce` do CSP autoriza qual script
roda, não força buscar uma versão nova dele). `SchematicPanel::render()` agora anexa `?v=<mtime do
arquivo>` tanto no `<script src>` quanto no `<link rel="stylesheet">` — muda a URL em si, então o
cache nunca serve uma resposta antiga pra ela. Não foi isolado como causa raiz confirmada (31.2 já
explica o sintoma sozinho), mas é uma mitigação de baixo custo pro mesmo sintoma numa causa
adjacente, e evita reintroduzir o bug de CSS da seção 28 por um caminho de cache diferente.

### 31.4 Bug real e CONFIRMADO: arrastar rótulo externo (id/value) nunca funcionava (2026-07-19)

Depois de 31.1-31.3, usuário confirmou que uma janela NOVA do VS Code de fato refletia código
recompilado (os fixes acima resolveram o sintoma de build/cache), mas reportou (com screenshot) que
não conseguia mover NENHUM dos rótulos de valor visíveis (`10.0 kohm`, `100 Ω`, `10.0 Ω`) — clicar
selecionava normalmente (contorno tracejado aparecia), mas arrastar não movia nada. Bug real,
diferente de 31.1-31.3, isolado por leitura direta do handler de `pointerdown` do rótulo externo
(`main.ts::renderExternalLabel`, ~linha 8612):

```ts
if (!isTextLabelSelected(component.id, kind)) selectOnlyTextLabel(component.id, kind);
persistState();
render();                              // <-- recria TODO <div> de rótulo do zero
...
el.setPointerCapture(event.pointerId); // <-- `el` já está órfão, removido do documento
```

`renderExternalLabel` não tem reconciliação por id (diferente do componente, que reaproveita `el`
via `componentElementsById` entre renders, comentário em `main.ts` ~linha 5949) — cada `render()`
descarta e recria TODOS os `<div>` de rótulo. Chamar `render()` (pra refletir a seleção
imediatamente) ANTES de `el.setPointerCapture(...)` deixa `el` (a referência capturada no fechamento
do próprio handler) órfã — `setPointerCapture` num elemento desconectado do documento falha
silenciosamente (exceção não capturada dentro do listener, sem crash visível), e nem
`pointermove`/`pointerup`/`pointercancel` chegam a ser anexados. Resultado: clique/seleção sempre
funcionava (o `render()` que causa o problema é o que TAMBÉM desenha o contorno tracejado), mas o
arrasto morria ali mesmo, sempre, em qualquer rótulo id/value comum — não achado antes porque o
drag de rótulo exposto (Modo Placa, `main.ts` ~linha 1208) usa um caminho totalmente separado (sem
esse `render()` no meio) e nunca teve o bug.

**Corrigido**: depois do `render()`, o handler rebusca o elemento FRESCO recém-criado
(`document.querySelector('.component-floating-label[data-component-id="..."][data-label-kind="..."]')`)
e continua o gesto (`setPointerCapture`/`pointermove`/`pointerup`/`pointercancel`) nele, nunca no
`el` original do fechamento. Varredura em todo `main.ts` (todo `setPointerCapture` do arquivo)
confirmou que este era o ÚNICO handler com um `render()` síncrono entre a seleção e a captura — não
é um padrão repetido em outro lugar.

## 32. Temporização MCU/QEMU: indicador honesto, trava real Stop→Run corrigida, e sincronização de
ritmo Scheduler↔MCU (2026-07-22/23)

Usuário reportou, num relato extenso, que o ESP32 simulado (`millis()`/blink de LED) rodava ~4x mais
devagar que o tempo real mesmo com o indicador de simulação em "100%", que UART a 921600 baud perdia
dados, e que o LasecPlot fechava sozinho ao parar a simulação. Auditoria encontrou cinco causas-raiz
distintas (calibração de `-icount` nunca existente de verdade, indicador medindo só o relógio
elétrico — não o do MCU —, sincronização cross-process da fila sem barreira de memória, polling fixo
de 50ms do LasecPlot incompatível com 921600 baud, e auto-despublicação do LasecPlot ao parar). As
quatro últimas foram corrigidas de forma direta (atomics de acquire/release na fila PERF-13 via
`std::atomic_ref`/`qatomic_store_release`, UART com poll adaptativo por baud + ring maior, LasecPlot
nunca mais fecha sozinho fora de ação do usuário/fechamento do esquemático). A calibração de
`-icount shift` (`QemuIcountCalibrator`, `core/src/mcu/qemu/QemuIcountCalibrator.{hpp,cpp}`) foi
implementada, mas **descartada em produção**: calibrar contra a sonda (boot ROM em branco, aceite de
MMIO instantâneo) mede um cenário otimista de melhor caso que não reflete o custo real de despacho
de uma sessão completa — piorou ~5x a velocidade real e causou resets espúrios. Ficou desligada
(`McuController::start()` nunca chama `ensureIcountShiftCalibrated`), com a infraestrutura de medição
compilada/testada mas sem efeito em produção.

### 32.1 Indicador honesto de progresso do MCU — `arena->qemuTime` é campo morto

`arena->qemuTime` **nunca é escrito** pelo fork QEMU real (confirmado lendo `simuliface.c` — só
existe como variável LOCAL dentro de `getQemu_ps()`, nunca atribuída ao campo do arena) — lê-lo
direto (como `SimulationSession::firstMcuVirtualTimeNs()` fazia) sempre dava 0, prendendo o indicador
"MCU real-time %" em 0% para sempre mesmo com o MCU rodando normalmente. O tempo virtual só chega
EMBUTIDO em cada evento processado (`simuTimePs`, escrito tanto pelos heartbeats `SIM_EVENT` quanto
por cada leitura/escrita de registrador) — `McuComponent::pollStepLocked()` agora rastreia o maior
`simuTimePs` visto (compare_exchange, nunca retrocede) num novo `m_latestVirtualTimePs`, exposto via
`McuComponent::latestVirtualTimeNs()`. Este campo é resetado para 0 a cada
`loadFirmwareLocked()`/`openSyntheticArenaForTesting()` — sem isso, um firmware recarregado (Stop→Run)
nunca conseguia avançar o indicador até seu `simuTimePs` cru ultrapassar organicamente o pico deixado
pela sessão ANTERIOR (achado ao investigar por que `session_restart_stress_test`, seção 32.2, mostrava
"trava" mesmo com o MCU saudável rodando ciclo após ciclo).

### 32.2 Trava real 100% reproduzível em ciclos Stop→Run: `m_pollEventScheduled` preso em `true`

Usuário relatou, ao vivo (Core recém-iniciado, processo antigo já descartado como causa), três
comportamentos inconsistentes entre cliques repetidos de Stop→Run: às vezes o MCU nunca inicializa,
às vezes roda perfeitamente, às vezes roda por um tempo e trava. Reproduzido 100% das vezes (15/15
ciclos) num novo teste, `core/test/core/mcu/SessionRestartStressTest.cpp` (Scheduler + QEMU reais,
Stop→Run repetido na MESMA instância de `McuComponent`).

**Causa raiz**: `SimulationSession::stopSimulation()` para o `Scheduler` **antes** de chamar
`stopFirmware()` (de propósito: nenhum componente pode voltar a agendar trabalho enquanto as MCUs
são encerradas). Isso abre uma janela: a thread de poll dedicada (PERF-12,
`McuComponent::runBackgroundPollLoop`), ainda girando, pode flagrar "sem evento + Scheduler parou"
bem nessa janela e cair no ramo de "volta pro modo passivo" — que reagendava um poll via
`scheduleNextPoll()`/`schedulePollAt()`, deixando `m_pollEventScheduled=true` e um callback pendente
num Scheduler prestes a ser resetado. Esse callback é o ÚNICO lugar que zera
`m_pollEventScheduled` (em `onPollEvent()`), mas `Scheduler::reset()` (chamado logo depois, em
`stopSimulation()`) descarta a fila de eventos sem executá-lo — a flag fica presa em `true` para
sempre. Todo load posterior via `startPolling()`→`scheduleNextPoll()`→`schedulePollAt()` via a flag
presa e desiste silenciosamente (`if (m_pollEventScheduled) return;`) — nenhuma thread de poll nunca
mais nasce, o MCU trava para sempre.

**Corrigido** (`McuComponent.cpp::runBackgroundPollLoop`): o ramo "Scheduler parou no meio do giro"
agora só sai da thread, SEM reagendar — nenhum chamador real de `Scheduler::stop()` depende desse
reagendamento sobreviver (`stopSimulation()` sempre chama `stopFirmware()`+`reset()` logo em seguida).
Verificado: `SessionRestartStressTest` 15/15 ciclos passando, de forma estável em várias rodadas,
inclusive replicando a carga da suíte completa (rodado logo após os testes de estresse de 61s/38s).

### 32.3 Sincronização de ritmo: o solver elétrico acompanha o MCU mais lento (2026-07-23,
reescrito de forma disruptiva no mesmo dia)

Restava o problema original nº 1: o solver elétrico roda a "100%" (pareado 1:1 ao relógio de parede
por design, via `Scheduler::setMaximumTimeStepNs()`, um tique próprio e independente de qualquer MCU)
enquanto o MCU (QEMU/`-icount`, gargalado pela vazão real de instruções do host) roda mais devagar
(ex.: "83%"). Pedido do usuário: em vez de tentar acelerar o MCU (a calibração de `-icount` já
provou que isso regride), o solver elétrico deve desacelerar para acompanhar o participante mais
lento — e a solução não pode desperdiçar recursos de thread (nada de thread dedicada nova, nada de
busy-wait adicional).

#### 32.3.1 Primeira versão (revertida por completo): razão suavizada por EMA

Design inicial: `Scheduler::PacingRateLimitFn` (`std::function<std::optional<double>()>`) chamado
uma vez por ciclo de pacing, devolvendo um multiplicador de taxa (`std::clamp(*hook(),
kMinimumPacedRate=0.01, taxaConfigurada)`) combinado com `m_realTimeRate` existente.
`SimulationSession::computeSlowestMcuPacingRatio()` calculava esse multiplicador como uma razão
suavizada (EMA, ΔvirtualNs/ΔwallNs, constante de tempo ~1s, com janela de aquecimento por-MCU) a
partir de `McuComponent::latestVirtualTimeNs()`.

**Falhou em teste ao vivo duas vezes**: (1) o indicador travava em "0%" por muito tempo — um ciclo
de realimentação onde `latestVirtualTimeNs()` só avança quando um evento é DESPACHADO (que já
depende de `eventNs<=nowNs()`); se o elétrico desacelerasse por uma amostra ruim isolada, o
despacho travava, a razão media caía mais, e o freio apertava mais, sem saída natural. Uma correção
pontual (ignorar ciclos com `ΔvirtualNs==0`) resolveu esse sintoma específico, mas (2) com firmware
REAL (não a flash em branco dos testes) fazendo leituras de ADC, o sistema travou em "0%" de novo, e
quando "funcionou" assentou em **~22%, muito pior que o ~82% que o MCU sozinho já alcançava antes de
qualquer código de pacing existir**.

**Causa raiz confirmada por auditoria**: a EMA amostra `ΔvirtualNs/ΔwallNs` uma vez por ciclo do
laço de pacing do Scheduler — e a cadência desse laço é ELA MESMA função da taxa efetiva
(`requiredWallNs = deltaSim/realTimeRate`, cresce conforme a taxa cai). Desacelerar → o laço dorme
mais → amostra com menos frequência e mais ruído → mede uma razão pior do que a real → desacelera
mais ainda. A própria medição interfere no que está medindo — um problema estrutural de QUALQUER
abordagem por taxa suavizada, não um bug pontual corrigível com mais uma janela ou constante.
Instrução explícita do usuário: parar de remendar, refazer do zero, priorizando velocidade,
aceitando quebrar compatibilidade (fase beta) — algo simples e elegante, "elegantemente simples mas
funcional", disruptivo se necessário.

#### 32.3.2 Redesenho: teto de POSIÇÃO absoluta, não de taxa

Em vez de estimar "a que velocidade o MCU está indo" (uma derivada, sensível a ruído/cadência de
amostragem), compara diretamente duas posições absolutas na MESMA timeline: nunca deixa
`Scheduler::nowNs()` avançar mais que uma folga fixa à frente da última posição CONFIRMADA do MCU
mais lento. Elimina EMA, constante de suavização e janela de aquecimento — a checagem é sem estado
(exceto uma pequena exceção de staleness, ver 32.3.3), recalculada do zero a cada ciclo:

1. **`McuComponent::pacingPositionNs()`** (novo): mesma fonte de `latestVirtualTimeNs()`
   (`m_latestVirtualTimePs`, já cobre leitura E escrita/heartbeat, já correta), mas traduzida pra
   timeline do Scheduler (`qemuEventTimeNs(m_qemuTimeOriginNs, ps)`, mesma tradução que
   `pollStepLocked()` já faz pra `eventNs`) — comparável direto contra `nowNs()`. `m_qemuTimeOriginNs`
   virou `std::atomic<uint64_t>` (era `uint64_t` simples) porque este getter é lido cross-thread sem
   segurar `m_callbackState->mutex`, mesma razão de `m_latestVirtualTimePs` já ser atomic.
   **Correção de ordem de reset**: `loadFirmwareLocked()`/`openSyntheticArenaForTesting()` agora
   zeram `m_latestVirtualTimePs` ANTES de setar a nova origem (era o contrário) — um leitor lock-free
   que pegue a transição no meio agora só vê o pior caso "posição um pouco atrasada" (espera um
   instante a mais, inofensivo) em vez de "origem nova + simuTimePs velho = posição espúria no
   futuro" (deixaria o elétrico correr à frente indevidamente).
2. **`SimulationSession::computeSlowestMcuPositionNs()`**: itera todo `McuComponent` com arena
   aberta, lê `pacingPositionNs()` (nullopt = ainda não processou nenhum evento — boot ou logo após
   recarga), devolve a MENOR entre todas. Substitui `computeSlowestMcuPacingRatio()` por completo —
   `McuPacingSample`/`m_mcuPacingState`/as constantes de EMA/aquecimento saíram inteiras, sem
   depreciação (nenhuma peça era usada por IPC nem por mais nada no código).
3. **`Scheduler::AdvanceLimitFn`** (`std::function<std::optional<uint64_t>()>`, substitui
   `PacingRateLimitFn`): devolve a posição de referência (não mais uma taxa) — a folga é somada
   pelo PRÓPRIO Scheduler, aplicada como teto ABSOLUTO sobre `targetTimeNs` ANTES de `runUntil()`
   (não como multiplicador de taxa DEPOIS, como antes). Aplicado incondicionalmente, mesmo com
   `realTimeRate()==0`/ilimitado — mudança deliberada, é uma garantia de corretude, não um modo de
   pacing.
4. **Folga derivada de medição, não um número fixo adivinhado** (correção de rumo, feedback direto
   do usuário ao ver a primeira proposta de `kMaxElectricalLeadNs=50ms` fixo: "não está demonstrado
   que 50ms seja necessário"): `Scheduler::start()` já calibra `pacingQuantum` (medição real da
   granularidade de espera do SO deste host, via sonda `sleep_for(1ms)` já existente para o pacing
   de `realTimeRate`) — a folga é derivada dela: `leadNs = clamp(2*pacingQuantumNs(), 5ms, 20ms)`.
   Hosts com boa temporização ficam perto do piso; hosts com mais jitter recebem mais margem; o
   teto de 20ms garante que a defasagem nunca reabre grande o bastante pra reproduzir o sintoma
   original. Valores exatos são um ponto de partida a refinar com medição ao vivo.
5. **Evita busy-spin sem sacrificar o caso `configuredStepNs==0`**: um bug real foi encontrado
   DURANTE a implementação (não em teste ao vivo) — a primeira versão do teto pulava `runUntil()`
   inteiro sempre que `targetTimeNs<=cycleSimStartNs`, mas isso também é verdade no modo
   `configuredStepNs==0` quando há dirty pendente sem evento futuro (drena o dirty set NO MESMO
   instante, de propósito) — pulando `runUntil()` nesse caso trava os 3 testes de
   `CommandDrainFn`/`CommandPendingFn` (`SchedulerTest.cpp`) num laço de espera de 5ms infinito.
   Corrigido: uma flag `advanceLimited` só fica `true` quando o teto de VERDADE reduziu o alvo
   (`cap < targetTimeNs`) — `runUntil()` continua sendo SEMPRE chamado; só espera 5ms antes do
   próximo ciclo quando `advanceLimited && nowNs()==cycleSimStartNs` (nada avançou por causa do
   teto, não por falta comum de trabalho).
6. **`Scheduler::notifyAdvanceLimitChanged()`** (novo, sem lock, mesma categoria de
   `notifyCommandPending()`): chamado por `McuComponent::pollStepLocked()` assim que
   `m_latestVirtualTimePs` realmente avança — acorda o Scheduler se ele estiver esperando o teto
   subir, em vez de só perceber no próximo poll de 5ms.

**Por que isso sincroniza TODOS os MCUs, não só o mais lento, sem tocar em `McuComponent`**: o
despacho de evento do MCU (`McuComponent::pollStepLocked`) já compara `eventNs` contra `nowNs()` e
adia (`DeferredFuture`) qualquer evento `eventNs > nowNs`. Travar `nowNs()` perto da posição do MCU
mais lento automaticamente represa qualquer MCU mais rápido no mesmo circuito atrás dessa mesma
lógica — sem código novo por-MCU. Ressalva: a fila circular (32 entradas) é fire-and-forget para
escritas/heartbeats — convergência de um MCU mais rápido é limitada pela profundidade da fila, não
instantânea por evento; propriedade já intencional do protocolo v3, não nova.

**A situação contrária** (Scheduler pesado/lento, QEMU mais rápido) já é coberta pela arquitetura
existente, sem mudança nenhuma: o laço de pacing já nunca acelera pra "recompensar" um atraso de
computação (comentário já existente cita literalmente "Boot/CPU/QEMU ficou pra trás" como o cenário
evitado) — um solver lento nunca corre mais rápido que seu próprio custo de computação, e um MCU
rápido nesse cenário já fica represado atrás do elétrico lento pela mesma fila com backpressure. O
novo teto só pode puxar `nowNs()` pra BAIXO — estruturalmente incapaz de piorar esse outro sentido.

#### 32.3.3 Bug real encontrado ao rodar a suíte completa: MCU ocioso vira teto permanente

`McuComponentLivePollThreadTest.cpp` (2 MCUs reais) começou a falhar de forma determinística depois
do redesenho: MCU A, recarregado 10 vezes com o Scheduler vivo, parava de responder a escritas de
registrador. Causa raiz: MCU B (usado só numa rajada de 4s bem no início do teste) fica com a arena
ABERTA mas para de produzir eventos novos pelo resto do teste — sua `pacingPositionNs()` CONGELA no
último valor visto. Como `computeSlowestMcuPositionNs()` toma o MÍNIMO entre todos os MCUs, essa
posição congelada virou um teto permanente sobre TODO o elétrico, mesmo MCU B não estando "lento" de
verdade, só quieto — impedindo pra sempre que `nowNs()` alcançasse o que MCU A precisava pra
despachar seus eventos pós-recarga. O mesmo aconteceria em produção sempre que um MCU legitimamente
dormir/esperar um evento externo por um período longo enquanto outro MCU no mesmo circuito precisa
que o elétrico continue avançando.

**Corrigido** com o mínimo de estado necessário: `SimulationSession::McuPositionTracking`
(`m_mcuPositionTracking`, chave = componentIndex) rastreia só `(última posição, instante de parede
em que mudou)` por MCU — se a posição não mudou por mais que `kStaleMcuTimeout` (1000ms, ponto de
partida — precisa ficar bem maior que a folga de 5-20ms pra nunca excluir por engano um MCU
genuinamente lento mas ainda progredindo), esse MCU para de contribuir pro teto (mesmo tratamento de
"sem dado" que um MCU recém-carregado já recebe) — volta a contribuir normalmente assim que produzir
um evento novo. Único estado que sobrou no redesenho todo: nada de suavização/razão/aquecimento,
só uma detecção de staleness.

Verificado: 37 runs consecutivos de `scheduler_test` sem falha nem trava (valida especificamente a
correção do busy-spin da seção 32.3.2 item 5), `mcu_component_live_poll_thread_test` voltando a
passar de forma estável e repetida depois da correção de staleness (antes dela, falhava de forma
determinística com o sintoma descrito acima, sem travar -- `waitUntil()` tem timeout próprio), e a
suíte completa (`ctest`, 57/57) rodando no tempo normal (~164s) depois de tudo. Nota honesta: um
`ctest` completo rodado ANTES desta correção de staleness (mas já com a correção de busy-spin da
seção 32.3.2 item 5 aplicada) ficou preso por quase 3 HORAS, sem nenhum processo de teste ou QEMU
vivo no meio tempo -- não isolado a um teste específico antes de aplicar esta correção, mas
consistente com algum teste subsequente a `mcu_component_live_poll_thread` esperando (sem timeout
próprio) o Scheduler avançar enquanto um MCU essencialmente idêntico ao MCU B ficava represando o
teto pra sempre.

#### 32.3.4 Achado ao vivo ainda em aberto: MCU parou de responder no meio de uma sessão longa com
firmware real (potenciômetro + UART)

Depois de todas as correções acima, usuário reportou (com firmware real, não flash em branco) o
indicador do MCU subindo e depois caindo pra "0%" no MEIO de uma única execução (sem nenhum
Stop/Run), com o elétrico em "98%" (correndo livre, não travado). Confirmado que isto é consistente
com o fix de staleness funcionando como projetado -- um MCU que genuinamente parou de responder
deixa de travar o elétrico pra sempre -- mas NÃO explica por que o MCU parou de produzir eventos.

Novo teste (`McuSchedulerPacingSyncRealQemuTest.cpp`, ver seção 32.4) fecha uma lacuna de cobertura
real: nenhum teste existente exercitava QEMU real + Scheduler real + a sincronização de ritmo nova
numa ÚNICA sessão sustentada e longa (os existentes usam arena sintética, OU QEMU real mas em
muitos ciclos curtos de Stop→Run). Rodado por 90s sustentados com QEMU real (flash em branco) --
**nenhuma trava**, maior intervalo sem avanço de 222ms (MCU) e 318ms (elétrico), ambos muito abaixo
do limiar de 10s. Isso prova que o mecanismo de sincronização em si é sólido sob QEMU real
sustentado -- mas flash em branco não reproduz o padrão específico do firmware do usuário (leituras
de registrador via `analogRead()` frequentes, mais tráfego de UART). **Causa raiz do travamento
específico do usuário permanece em aberto** -- precisa ou do firmware real dele pra reproduzir
diretamente, ou de logs/diagnóstico capturados ao vivo na sessão que travou.

#### 32.3.5 Investigação concluída (2026-07-23): GPIO13 travado em LOW é uma corrida FORA do Core,
dentro da emulação de CPU do QEMU — não no mecanismo de sincronização de ritmo

Retomando o achado em aberto da seção 32.3.4: usuário forneceu o firmware real
(`EININDI01_GitHub_VSCode_PIO`) e o esquemático correspondente, autorizando testes livres
("aqui você está como administrator então faça o teste que você desejar"). Reproduzido
diretamente via `mcu_blink_long_run_test` com `LASECSIMUL_TEST_FIRMWARE` apontando pro
`merged.bin` real: **~30-50% das execuções terminam com o LED (GPIO13) nunca saindo de LOW**
(`transitions=0`), sempre com `qemu_alive=yes` e `unexpected_reset=no` (não é queda do processo
QEMU nem reset do firmware).

**Hipóteses investigadas e descartadas, uma a uma, com evidência direta (não suposição):**

1. **Inflação de `pacingPositionNs()` por PEEK em vez de despacho confirmado** — `arena.poll()` é
   PEEK, não consome; um evento meramente espiado (ainda não despachado, `eventNs > nowNs()`)
   podia inflar `m_latestVirtualTimePs` antes deste achado ser corrigido. Corrigido (mover a
   atualização de `m_latestVirtualTimePs` em `McuComponent::pollStepLocked()` pra depois da
   confirmação `eventNs <= nowNs()`) — mudança real e válida (ver `McuComponent.cpp`), mas
   **retestada isoladamente: não mudou a taxa de falha do GPIO13 travado**.
2. **Timeout de staleness (`kStaleMcuTimeout`, seção 32.3.3) removendo o teto cedo demais** —
   testado temporariamente com o timeout multiplicado por 30× (1s → 30s): **taxa de falha
   idêntica**. Descartado.
3. **Janela entre "Scheduler alcança o timestamp agendado" e "a thread de poll dedicada roda pela
   primeira vez"** em `McuComponent::onPollEvent()` (branch PERF-12) — `startBackgroundPollThreadIfNeeded()`
   só CRIA a thread e retorna, sem esperar ela despachar nada; o laço de `runUntil()` ficava livre
   pra avançar por cima de eventos seguintes do mesmo MCU nesse intervalo. Fechado (despacho
   síncrono do evento já vencido antes de delegar à thread dedicada) — janela real, fechamento
   verificado sem regressão no `ctest`, mas **também não mudou a taxa de falha do GPIO13**.
4. **MCU com arena aberta mas zero eventos despachados sendo excluído (nullopt) do cálculo do teto
   de avanço** em vez de contar como posição 0 — sem NENHUM MCU contribuindo, o teto ficava sem
   restrição nenhuma e `Scheduler::nowNs()` saltava de ~0 pro fim inteiro da simulação (~22s) em
   uma única rajada de iterações baratas, **comprovado com tracing de baixíssimo overhead
   (buffer em anel lock-free — fprintf comum MASCARAVA a corrida ao mudar o timing entre threads,
   sinal claro de corrida genuína) direto de dentro de `stamp()`**. Uma tentativa de correção
   (tratar "zero eventos ainda" como posição 0) reduziu o salto observado de ~22s pra ~7s no mesmo
   cenário, mas **também não mudou a taxa de falha do GPIO13** (permaneceu ~30-45%) E introduziu
   uma regressão real: `session_restart_stress` roda cada ciclo por só 600ms de parede, abaixo do
   `kStaleMcuTimeout` (1s) — um MCU recém-recarregado sem posição ainda ficava com o teto travado
   perto de zero pelo ciclo inteiro, sem tempo de a exclusão por staleness (item acima) entrar em
   ação. **Revertida** — o comportamento de exclusão por nullopt (original) foi restaurado; o salto
   de ~22s continua acontecendo em cenários sem realTimeRate configurado, mas isso não chegou a ser
   a causa do sintoma investigado, então não valia a regressão pra corrigi-lo agora.

Ou seja: **três correções reais e verificadas no mecanismo de sincronização de ritmo (mais uma
tentativa revertida por regressão), nenhuma
delas era a causa do sintoma reportado.** Isolado progressivamente com o usuário (`/loop` de
perguntas de "próximo passo"): UART removido do firmware (só restou `pinMode`+`digitalRead`+
`digitalWrite` a cada 500ms) — falha idêntica (~45%); componentes do circuito reduzidos ao mínimo
(removidos potenciômetro/motor/PWM/ADC, sobrando só GPIO13→resistor→LED→terra) — falha idêntica
(~20%); **LED (diodo não-linear) removido, sobrando só GPIO13→resistor→terra** — falha idêntica
(~30%). A reprodução mínima final é: um MCU ESP32 real (QEMU), um resistor de 1kΩ pra terra em
GPIO13, e um firmware que só faz `pinMode(13, OUTPUT)` seguido de
`digitalWrite(13, !digitalRead(13))` a cada 500ms.

**Causa raiz encontrada** via tracing direto (buffer em anel) de `stamp()`/`dispatchArenaEvent()`:
em TODAS as execuções que falham, `isOutputEnabled(13)` (consultado direto no adaptador, não via
o flag `changed`/fingerprint) **nunca se torna `true`** — ou seja, a escrita em `GPIO_ENABLE_REG`
que deveria habilitar GPIO13 como saída nunca chega a marcar esse bit no estado interno do
adaptador, mesmo com a mesma sequência de escritas, nos mesmos timestamps de evento
(`eventNs`), que em execuções que passam. Comparação direta confirmou: a MESMA escrita, no MESMO
timestamp de evento, ora inclui o bit 13 ora não — só varia entre execuções da MESMA imagem de
firmware. Isso é uma corrida de dados na própria emulação de CPU do QEMU (ex: acesso concorrente
de dois núcleos virtuais do ESP32 ao mesmo registrador de periférico, ou não-determinismo na
ordem de instruções emitidas pelo emulador) — **fora do processo Core do LasecSimul e fora deste
repositório**: `devices/qemu-esp32/bin/` só contém o binário `qemu-system-xtensa.exe` pré-compilado,
sem árvore de fontes do QEMU disponível aqui pra inspecionar ou corrigir o modelo do periférico
GPIO.

**Achado colateral, não um bug:** a falha "PWM27 nunca transiciona" observada em TODAS as execuções
(passando ou falhando) do `mcu_blink_long_run_test` não é um bug do Core — `platformio.ini` do
firmware real usa `build_src_filter = +<main0.cpp>`, e `main0.cpp` (o que é DE FATO compilado, não
o `main.cpp` mais elaborado do mesmo diretório) nunca chama `analogRead()`/`analogWrite()` no
`loop()` — só configura os pinos em `setup()` e nunca mais toca PWM/ADC. O teste antigo assumia o
comportamento do `main.cpp`; o `merged.bin` real reflete `main0.cpp`.

**Conclusão revisada em 2026-07-24 (ver 32.3.6):** a sequência MMIO do QEMU estava correta. A perda
ocorria no ACK do Core, entre `poll()` e `dispatchArenaEvent()`, e foi corrigida no commit `848c347`.

#### 32.3.6 Causa definitiva e recorrência aparente depois do merge

O tracing separado dos dois consumidores mostrou que `stamp()` não perdia a alteração elétrica:
quando ele despacha uma escrita, a mesma chamada já estampa o estado novo, portanto o retorno
`changed` descartado não exige outro `markDirty()`. A entrada ausente era avançada sem nunca ter
sido a entrada retornada pelo `poll()`.

O protocolo v3 mantém escritas/heartbeats na fila, mas aceita eventos de QEMUs de transição no slot
único legado. A corrida era:

1. `poll()` copiava um `SIM_FREQ` do slot legado;
2. antes do ACK, o QEMU publicava uma escrita MMIO na fila;
3. `dispatchArenaEvent()` escolhia o ACK pelo tipo da ação e tratava qualquer evento que não fosse
   `SIM_READ` como escrita;
4. `acknowledgeWrite()` via a fila agora não vazia e avançava `queueReadIndex`, descartando a
   primeira escrita (frequentemente `GPIO_ENABLE_REG`) sem despachá-la.

A correção registra a **origem** em `QemuArenaEvent::fromQueue`: só uma entrada copiada da fila chama
`acknowledgeWrite()`; `SIM_READ` confirma o slot com resposta e eventos legados sem resposta chamam
`acknowledgeEventSlot()`, que zera apenas `simuTime`. O teste
`testLegacySlotAckNeverConsumesNewQueueEntry` reproduz exatamente a janela “poll do slot → chegada
na fila → ACK” e prova que `queueReadIndex` permanece intacto.

Depois do merge `2cf87c2`, a correção continuava no `HEAD`, mas o checkout local executava
`core/build/Release/lasecsimul-core.exe` compilado às 06:45, anterior a
`QemuArenaBridge.cpp`/`McuComponent.cpp` corrigidos (07:46/08:50). Parecia uma regressão do GitHub,
mas era um artefato local obsoleto selecionado pela Extension. O processo que reproduzia na UI foi
confirmado ainda mais diretamente: vinha da extensão 0.0.13 instalada em
`.vscode/extensions/.../bundled/core`, empacotada em 22/07 e portanto também anterior ao fix.
`coreExecutable.ts` agora recusa, em checkout de desenvolvimento, iniciar qualquer Core mais antigo
que os fontes e informa o comando de rebuild; instalações empacotadas não contêm a árvore
`core/src`, logo precisam ser geradas novamente para incorporar o Core novo. A ordem de produção
permanece firmware/condições antes de `Run`: mudar a ordem só alterava o timing e podia mascarar a
corrida, não era sua causa.

### 32.4 Testes adicionados

- `core/test/core/mcu/McuRestartStressTest.cpp` (novo): 25 ciclos de start/stop de QEMU real via
  `McuController` puro (sem Scheduler) — isola que o ciclo de vida de processo/arena é sólido.
- `core/test/core/mcu/SessionRestartStressTest.cpp` (novo): 15 ciclos de Stop→Run com Scheduler +
  QEMU reais — reproduziu e agora prova corrigida a trava da seção 32.2.
- `core/test/core/mcu/QemuQueueStressTest.cpp` (novo): 60s de sessão única sustentada — valida a
  sincronização cross-process da fila sob carga.
- `test/core/simulation/SchedulerTest.cpp`: 5 casos síntéticos (sem MCU/QEMU) cobrindo só o
  mecanismo de `AdvanceLimitFn`/`pacingQuantumNs()` em isolamento — teto aplicado (`nowNs()` nunca
  ultrapassa posição+folga derivada), teto sobe e o elétrico retoma IMEDIATAMENTE (sem decaimento
  gradual), `nullopt` idêntico a sem hook, teto se aplica mesmo com `realTimeRate(0)`/ilimitado
  (mudança deliberada), e ausência de busy-spin comprovada (contagem de chamadas do hook limitada
  numa janela fixa com o teto permanentemente travado).
- `core/test/core/mcu/McuSchedulerPacingSyncTest.cpp` (reescrito): MCU sintético (sem QEMU real, sem
  flakiness de host) publicando heartbeats numa taxa controlada -- prova posição some sem evento e
  recomeça sem hiato numa recarga (sem estado nenhum pra "detectar retrocesso"), prova fim-a-fim que
  o GAP entre `nowNs()` e a posição do MCU nunca excede a folga máxima (20ms) e que a taxa média de
  avanço converge MUITO perto do alvo injetado (medido: ~0.40 alvo, ~0.398-0.400 observado --
  bem mais preciso que o ~0.22 de subestimação da EMA antiga), e um caso bônus com 2 MCUs provando
  que o elétrico segue o MAIS LENTO, não uma média nem o mais rápido.
- `core/test/core/mcu/McuSchedulerPacingSyncRealQemuTest.cpp` (novo): QEMU real + Scheduler real +
  a sincronização de ritmo nova, numa ÚNICA sessão sustentada de 90s (flash em branco) -- fecha a
  lacuna de cobertura da seção 32.3.4. Monitora o maior intervalo sem avanço tanto do MCU
  (`latestVirtualTimeNs()`) quanto do elétrico (`Scheduler::nowNs()`) -- nenhuma trava em 90s
  (maior intervalo: 222ms MCU, 318ms elétrico, limiar de trava 10s).
- `core/test/core/mcu/McuUartToLasecPlotTest.cpp`: estendido pra cobrir 921600 baud, não só 115200.

Suíte completa do Core (`ctest`) e `npm test` da extensão 100% verdes depois de todas as correções
desta seção.

### 32.5 MTTCG + ABI v4: gap de avanço (`m_nextPendingEventNs`) confirmado corrigido; nova causa
raiz isolada para a falha residual (2026-07-26)

Sessão anterior (agente que esgotou os tokens, retomada aqui) investigou uma recorrência do
travamento de boot já sob MTTCG/ABI v4 (seção 32.3.6 fechada, `docs/37-arena-abi-v4-negociada-*`):
firmware real, ~1 em 10 execuções travava com tempo virtual avançando mas UART parada e GPIO13
nunca saindo de LOW. Cadeia de correções aplicadas na sessão anterior (`McuComponent.cpp/hpp`):

1. **Causa raiz identificada e corrigida**: `pacingPositionNs()` só publicava a posição do ÚLTIMO
   evento APLICADO (`m_latestVirtualTimePs`), nunca a do PRÓXIMO evento já conhecido (a cabeça da
   fila, espiada mas ainda não despachada porque `eventNs > nowNs()`). Quando o gap até essa cabeça
   excedia a folga do `AdvanceLimitFn` (~10,8ms observados > 5ms de folga), o Scheduler nunca
   alcançava o callback que a despacharia -- deadlock circular: fila enche 32/32, QEMU para de
   publicar. Corrigido separando `m_nextPendingEventNs` (cabeça futura, só fronteira segura de
   avanço) de `m_latestVirtualTimePs` (métrica de evento aplicado, inalterada) -- ver
   `McuComponent::pacingPositionNs()`/`pollStepLocked()`.
2. Retomada nesta sessão: bateria dedicada (`session_restart_stress_test`, firmware real
   `EININDI01_GitHub_VSCode_PIO/.pio/build/esp32/merged.bin`, sem alterar o teste) rodada 2x (10 e
   20 ciclos) sobre o binário Core recompilado com a correção acima. **Resultado: 29/30 ciclos
   perfeitos** (6-8 bordas de GPIO13 cada, nenhuma trava de fila/Scheduler) -- a correção do item 1
   está confirmada e não é mais hipótese.

**A 1 falha residual observada NÃO é a mesma classe de bug.** Log da falha: QEMU imprime
`Guru Meditation Error: Core / panic'ed (Cache error). Cache disabled but cached memory region
accessed`, com dump de registradores dos DOIS núcleos, ainda durante o boot (logo após as primeiras
linhas de trace do firmware, antes do `app_main`). `arena->running` permanece 1 (processo QEMU não
morre) e o tempo virtual continua avançando (heartbeats), mas o firmware guest está genuinamente
travado/reiniciando em loop -- não é falta de heartbeat nem fila cheia. **Fora deste repositório**
(Core), mas o fork QEMU está disponível localmente em `C:\SourceCode\qemu_lasecSimul` (não é uma
dependência externa inacessível) -- ver seção 32.5.1 para a investigação feita e o que falta.

**Achado colateral**: o "fix de timer de frame da UART" narrado pelo agente anterior (duplicação de
temporização FIFO/adaptador) nunca foi commitado em `qemu_lasecSimul` -- `git log`/`git status` lá
mostram a árvore limpa em `73392afd7256aaa2adba03c0473e6b2b6744ac3d` (só a negociação da ABI v4),
sem o diff de `hw/char/esp32_uart.c` descrito. As edições devem ter se perdido quando os tokens do
agente anterior esgotaram, antes de um commit. Não impediu a verificação do item 2 acima (a bateria
de 30 ciclos não reproduziu nenhum sintoma de UART travada em `uart_tx_one_char`), mas fica
registrado -- se esse sintoma reaparecer, a correção precisa ser refeita do zero.

#### 32.5.1 Investigação do "Cache error" (2026-07-26): hipótese original descartada por evidência
direta; causa raiz ainda em aberto

Reproduzido de forma confiável (~1/30 a 1/60 ciclos, `session_restart_stress_test` com
`LASECSIMUL_TEST_FIRMWARE`/`LASECSIMUL_TEST_QEMU_BINARY` apontando pro firmware real e um binário
QEMU de rascunho, sem tocar o binário oficial implantado em `devices/qemu-esp32/bin/`).

**Hipótese 1 (descartada por instrumentação direta)**: corrida entre as duas threads MTTCG no
toggle de `DPORT_..._CACHE_CTRL_REG` -- um núcleo habilitando o mapeamento de cache DROM0/IRAM0
(`esp32_cache_state_update()`/`memory_region_set_enabled()`) enquanto o outro ainda accessa via
`illegal_access_trap_mem` (`esp32_cache_ill_read()`, ambos em `hw/misc/esp32_dport.c`).
Instrumentado (`fprintf` de core/timestamp em toda transição de enable e em todo hit do trap),
recompilado via `ninja qemu-system-xtensa.exe` (ambiente UCRT64 em
`C:\SourceCode\tools\msys64`), reproduzida a falha de novo com o binário instrumentado -- **o trap
NUNCA disparou**. O mecanismo instrumentado não é o caminho da falha; hipótese descartada.
Instrumentação revertida (`git checkout -- hw/misc/esp32_dport.c` em `qemu_lasecSimul`), árvore de
novo limpa em `73392afd7256aaa2adba03c0473e6b2b6744ac3d`.

**Evidência nova capturada**: o log do próprio QEMU (`[LasecSimul][ESP32 reset] count=N mask=...
cause0=... cause1=... expected=...`) mostra, no ciclo que falha, uma sequência de resets
`ESP32_SW_CPU_RESET` (causa 12 -- reset de software por-núcleo, não watchdog: `ESP32_TGWDT_CPU_RESET`
é 11) depois do reset esperado de app-cpu-startup (count=2): primeiro só o APP_CPU (count=3), de
novo só o APP_CPU (count=4), depois PRO_CPU (count=5) -- três reinícios auto-disparados em
sequência, todos `expected=no`. O PC do APP_CPU logo antes do count=3 (`pc1=0x401218b3`) fica dentro
da janela de cache de instrução mapeada em flash (`iram0`, base `0x40000000`, 4MB -- ver
`esp32_cache_init_region()`), a MESMA classe de região da Hipótese 1, só que o mecanismo específico
lá não é o trap direto.

**Leitura mais provável (não confirmada)**: o `Guru Meditation Error (Cache error)` acontece uma
PRIMEIRA vez em algum ponto anterior ao que foi inspecionado nos logs até agora; o handler de panic
do ESP-IDF então reinicia o núcleo (`SW_CPU_RESET`) -- e como um reset por-núcleo neste modelo QEMU
(`esp32_cpu_reset()`/`esp32_timg_cpu_reset()` setam só `ESP32_SOC_RESET_PROCPU`/`APPCPU`, nunca
`ESP32_SOC_RESET_PERIPH`) NÃO reresseta o DPORT (`cache_state`/tabelas MMU de flash), o boot
seguinte herda o mesmo estado ruim e falha de novo -- daí a cascata de 3 reinícios
antes do teste desistir. **A causa do PRIMEIRO panic continua desconhecida**: exigiria instrumentar
mais cedo (ou capturar via gdbstub/`-d exec` num ciclo isolado) para flagrar o exato acesso/instrução
que dispara o cause=7 (`PC_VALUE_ERROR_CAUSE`) que antecede o rótulo "Cache error" do panic handler.

**Estado ao pausar**: nenhuma mudança foi commitada em `qemu_lasecSimul` (árvore limpa); o binário
implantado em `devices/qemu-esp32/bin/` não foi tocado por esta investigação. Decisão do usuário:
pausar aqui, documentar e retomar depois em vez de continuar o ciclo instrumentar→recompilar→rodar
sem prazo definido. Próximo passo recomendado pra quem retomar: capturar o log completo (não só uma
janela) do PRIMEIRO ciclo que falha, com `LASECSIMUL_TEST_VERBOSE=1`, e localizar o exato instante
do primeiro `Guru Meditation` antes de reinstrumentar.

#### 32.5.2 Investigação time-boxed de retomada (2026-07-26): primeiro panic isolado por
`addr2line`, hipótese de lock refutada, segundo modo de falha distinto encontrado

Retomada focada, sem fix amplo: capturar o PRIMEIRO panic (core, PC, causa, registradores, estado
de cache/DPORT, causa do reset, saída UART) antes de qualquer reavaliação de causa raiz.

**Núcleo que falhou, isolado via `xtensa-esp32-elf-addr2line` contra `firmware.elf`** (sem precisar
recompilar QEMU): o PC/backtrace de um dump capturado anteriormente resolvem para:
- **Core 0 (PRO_CPU)**: `esp_cpu_wait_for_intr` ← `prvIdleTask` -- idling de verdade, não envolvido.
- **Core 1 (APP_CPU)**: `adc_oneshot_ll_start` (`hal/adc_ll.h:437`) ← `adc_oneshot_read` ←
  `__analogRead` ← **`loop()` em `main.cpp:29`** ← `loopTask`. É o APP_CPU, executando a escrita de
  registrador que inicia uma leitura de ADC, o núcleo diretamente implicado.

(Achado colateral: `platformio.ini` usa `build_src_filter = +<main.cpp>` -- diferente do suposto na
seção 32.3.5/32.3.6 antiga, `main.cpp` CHAMA `analogRead()` a cada 10ms; `>graf:N:0|g` é esse próprio
trace, não instrumentação de cobertura.)

`EXCCAUSE=7` em ambos os dumps não corresponde a nada que este QEMU realmente levante --
`PC_VALUE_ERROR_CAUSE` (valor 7 no enum do `target/xtensa/cpu.h`) não aparece em nenhuma chamada de
`HELPER(exception_cause)`/`gen_exception_cause` no fork inteiro. Ou é um valor sintético/residual
escrito pelo próprio handler de panic do ESP-IDF (via NMI cross-core), ou aponta pra um mecanismo
ainda não instrumentado.

**Hipótese testada e REFUTADA**: `m_arenaOrderLock` (mutex de serialização MTTCG introduzido em
`ec22444`, ver `arenaTransactionBegin()`/`End()` em `softmmu/simuliface.c`) sendo mantido preso
durante o busy-wait de fila cheia em `waitForSynch()` -- poderia starvar o heartbeat (`simu_event`)
ou o núcleo oposto por segundos. Instrumentado (log de espera/posse > 5ms, com core e timestamp),
recompilado, rodado em duas baterias (60 e 90 ciclos, firmware real): **zero ocorrências do lock
sendo disputado**, mesmo no ciclo que falhou na bateria de 90. Hipótese descartada; instrumentação
revertida (`git checkout -- softmmu/simuliface.c`).

**Segundo modo de falha, distinto do "Cache error", encontrado na mesma bateria de 90 ciclos**
(ciclo 76): `schedulerNow=20565100000` (20,5s de tempo virtual contra um alvo de 5s de execução real)
e **captura de UART completamente VAZIA** (nenhum banner de boot, nenhum trace) -- só os dois resets
esperados (inicial + app-cpu-startup), sem a cascata de `SW_CPU_RESET` do primeiro modo. Isso bate
com um comportamento já documentado e revertido deliberadamente: `SimulationSession::
computeSlowestMcuPositionNs()` exclui um MCU do piso de avanço até ele despachar seu primeiro evento
de verdade (ver comentário "Achado 2026-07-23" no código, e seção 32.3.5 acima) -- sem nenhum MCU
contribuindo e sem `realTimeRate` configurado (este teste nunca configura), nada limita o avanço do
Scheduler, que pode disparar numa rajada antes do QEMU sequer ter produzido alguma coisa.

**Tentativa de reaplicar a reversão, testada e REFUTADA de novo**: reimplementado o tratamento
"posição 0 em vez de nullopt" (mantendo a MESMA exclusão por staleness de `kStaleMcuTimeout` como
rede de segurança, na expectativa de que ela cobrisse o caso que causou a reversão original).
Recompilado o Core, rodado `session_restart_stress_test` SEM firmware real (15 ciclos de 600ms,
flash em branco -- exatamente o cenário que motivou a reversão de 2026-07-23): **14 de 15 ciclos
TRAVARAM NO MEIO** (contra 0/15 antes da mudança) -- regressão severa, confirma que a reversão
original estava certa e que o raciocínio de "o teste de firmware real usa ciclos de 5s, bem mais que
`kStaleMcuTimeout`" não se aplica ao teste de flash em branco (que continua rodando ciclos de
600ms). Mudança revertida (`git checkout -- core/src/session/SimulationSession.cpp`), Core
recompilado de volta ao estado limpo. **Este caminho está fechado**: `computeSlowestMcuPositionNs()`
deve continuar excluindo (não zerando) um MCU sem posição ainda.

**Estado ao final desta rodada**: nenhuma mudança de código sobrevive desta investigação (só
`.spec` foi atualizado) -- `qemu_lasecSimul` limpo, `core/src/session/SimulationSession.cpp` limpo,
nenhum binário implantado foi tocado. Dois modos de falha residuais permanecem em aberto,
aparentemente independentes um do outro:
1. "Cache error" (Guru Meditation, cascata de `SW_CPU_RESET`) -- causa do PRIMEIRO panic ainda
   desconhecida (ver 32.5.1).
2. "UART vazia + salto de tempo virtual" -- mecanismo entendido (MCU sem posição não limita o
   avanço), mas a correção óbvia (zerar em vez de excluir) já foi tentada duas vezes e regride o
   teste de flash em branco as duas vezes. Precisaria de uma abordagem mais fina (ex.: um teto
   temporário SÓ durante uma janela inicial curta, não indefinidamente, ou alguma forma de o MCU
   sinalizar "processo já vivo, aguardando primeiro evento" sem reintroduzir o travamento de
   flash em branco) -- não tentado ainda.

#### 32.5.3 Medição da latência "abertura de arena -> primeira posição" pro item 2 de 32.5.2 (2026-07-26)

Retomando o item 2 em aberto acima ("abordagem mais fina... não tentado ainda"): antes de tentar
qualquer janela de avanço inicial limitada, medido isoladamente (repositório trabalhado num worktree
Git dedicado, `investigate/scheduler-empty-uart-2026-07-26`, pra não disputar o build do Core com a
investigação paralela do "Cache error" acima) quanto tempo `pacingPositionNs()` de fato fica `nullopt`
depois de `loadMcuFirmware()`, tanto na condição que já regrediu a tentativa anterior (flash em
branco, ciclos de 600ms) quanto numa condição ainda não medida (firmware real, ciclos de 5s).

**Instrumentação (temporária, `[MEASURE-TEMP]` em `SessionRestartStressTest.cpp`, revertida depois
desta medição)**: cada ciclo cronometra de "`loadMcuFirmware()` chamado" até
`pacingPositionNs().has_value()` virar verdadeiro (ou até a MCU morrer/4s de timeout), imprime
`positionLatencyMs` em stderr. Adicionado também `McuComponent::arenaOpenWallNs()` (getter lock-free
do instante de abertura da arena, `steady_clock`) como infraestrutura preparatória -- NÃO consumido
por nenhum código de produção nesta sessão (comentário correspondente em `McuComponent.hpp` deixa
isso explícito pra não confundir leitura futura); revertido junto com a instrumentação de medição.

**Flash em branco** (`session_restart_stress_test`, 30 ciclos e depois 15 -- padrão do teste):
latência tipicamente 114-232ms; dois outliers isolados (819ms no ciclo 0 da bateria de 30 -- primeiro
carregamento do processo, provável custo de I/O a frio do binário/DLL; 412ms num ciclo tardio isolado
da mesma bateria). 0/30 e 0/15 falhas em ambas.

**Firmware real, primeira bateria (15 ciclos de 5s)**: rodada por engano em paralelo com uma
recompilação completa do Core (`cmake --build --parallel 4`) -- RAM livre do sistema caiu a ~0,2GB de
7,35GB totais durante a sobreposição (o `--parallel 4` já tinha esgotado o *heap* do compilador,
`error C1060`, em dois targets antes disso). Latência disparou nos ciclos 10-12 (1289ms, 841ms,
2720ms) e o ciclo 13 travou com GPIO13 preso em HIGH (`bordas=1 high=sim low-apos-high=nao`) -- mesma
classe do "Cache error" ainda em aberto na seção 32.5.1 (`arena->running=1`, fila cheia 1105/1105,
tempo virtual seguia avançando). **Refeita isolada** (nada mais competindo por CPU/RAM): 15/15 ciclos
OK, latência 115-364ms (média ~162ms). Isso confirma que a bateria contaminada não mede a
variabilidade intrínseca do firmware real -- a pressão de RAM da recompilação concorrente
provavelmente inflou os outliers de latência e pode ter contribuído pra tornar o travamento de Cache
error mais provável de disparar dentro da janela do teste. A falha de GPIO13 fica registrada como mais
uma reprodução do bug aberto em 32.5.1 (não investigada mais a fundo aqui -- fora do escopo desta
medição).

**Leitura pro item 2 de 32.5.2**: mesmo isolando a interferência de recompilação, a cauda de latência
do firmware real (364ms, só 15 amostras) já é quase 2x o pior caso limpo do flash em branco (232ms) --
e ambas as amostras (15-30 ciclos) são pequenas demais pra confiar num teto curto e fixo sem repetir
com a mesma bateria de 60-90 ciclos usada em 32.5.1/32.5.2. `kStaleMcuTimeout` (1000ms,
`SimulationSession.cpp:35`, já documentado como "ponto de partida a refinar com medição real") folga
confortavelmente acima de toda amostra limpa coletada aqui (>2,7x o pior caso limpo de 364ms) -- os
dados não sustentam reduzi-lo, e também não chegam a sustentar uma janela inicial curta separada com
confiança (a mesma ordem de grandeza de `kStaleMcuTimeout` já cobre o caso limpo observado, sem deixar
claro que uma janela dedicada menor seria seguro sob carga real). **Nenhuma mudança de comportamento
de produção foi feita** nesta rodada -- só a infraestrutura de medição (revertida). O item 2 continua
aberto: qualquer tentativa futura de janela inicial limitada precisa de uma bateria maior (60-90
ciclos) de firmware real, sem contaminação de recompilação concorrente, antes de escolher um valor.

#### 32.5.4 Pista forte para a causa do primeiro panic: `EXCCAUSE=7` aciona um hang JÁ COMPILADO no
ESP-IDF quando o cache-IA nunca latcheia -- evidência estática, ainda NÃO confirmada ao vivo (2026-07-26)

Retomada sem bateria ao vivo concluída (ver "Bloqueios de ambiente" abaixo) -- progresso via
engenharia reversa direta dos binários prebuilt do ESP-IDF que este firmware realmente linka
(`framework-arduinoespressif32-libs/esp32/lib/libesp_system.a`, objetos extraídos com `ar x` e lidos
com `xtensa-esp32-elf-objdump -dr`/`nm`), uma fonte de evidência que nenhuma sessão anterior tinha
usado, cruzada com o código-fonte do fork QEMU.

**Confirmado por leitura direta do binário do ESP-IDF**: `EXCCAUSE=7` nos dumps é
`PANIC_RSN_CACHEERR` (`panic_reason.h`), NÃO uma causa real do xtensa -- a tabela real de causas
xtensa (`reason$1[]` em `panic_arch.c.obj`) rotula o índice 7 como `"PCValue"`; o índice 7 que
efetivamente aparece nos dumps vem de uma tabela SEPARADA e sintética do ESP-IDF (`pseudo_reason$0[]`,
índice 7 = `"Cache error"`, confirmado despejando os bytes crus de `.rodata.str1.1` nos offsets
relocados). Bate com a suspeita já registrada em 32.5.2, agora com evidência do binário real em vez
de inferência.

**Achado novo, confirmado por desmontagem de `panic_handler.c.obj` (função `panicHandler`)**: quando
`panic_get_cause(frame)==7`, o código chama `esp_cache_err_get_cpuid()`; se o retorno for `-1`
(nenhum núcleo com `illegal_access_status` latchado no momento) E o núcleo em pânico for o APP_CPU
(`core_id==1`), o ESP-IDF JÁ COMPILADO entra num loop infinito de auto-salto (`j` pro próprio
endereço) -- **um hang real do firmware, não um artefato do QEMU**. PRO_CPU com `cpuid==-1` em vez
disso segue o caminho normal do panic handler.

**Cruzamento com o fork QEMU, verificado linha a linha nesta sessão contra `hw/misc/esp32_dport.c` e
`hw/xtensa/esp32.c`**: `illegal_access_status` só é setado em `esp32_cache_ill_read()`
(`esp32_dport.c:326,333`) e só é limpo em `esp32_dport_clear_ill_trap_state()` (`esp32_dport.c:352`),
chamada apenas por `esp32_dig_reset()` (`esp32.c:160,165`) e `esp32_timg_sys_reset()`
(`esp32.c:217,222`) -- NUNCA por `esp32_cpu_reset()` (`esp32.c:170`, o caminho `ESP32_SW_CPU_RESET`
usado pelo reboot-por-panic real) nem por `esp32_timg_cpu_reset()` (`esp32.c:197`) nem por
`esp32_app_cpu_reset_async()` (`esp32.c:146`) -- exatamente os três caminhos de reset usados pela
cascata documentada em 32.5.1/32.5.2. Além disso, os handlers de escrita de `A_DPORT_PRO_CACHE_CTRL1`/
`A_DPORT_APP_CACHE_CTRL1` (`esp32_dport.c:182-210`) só armazenam o registrador cru e chamam
`esp32_cache_state_update()` -- nenhum bit tipo `MMU_IA_CLR` (o mecanismo de limpeza por software que
o hardware real expõe) é sequer inspecionado; uma escrita nesse bit é descartada em silêncio.

**Hipótese unificada (evidência estática forte, ainda NÃO confirmada ao vivo)**: uma vez que
`illegal_access_status` latcheia por qualquer motivo -- inclusive um evento raro/transitório que o
hardware real tolera via `MMU_IA_CLR` -- este fork não dá ao guest NENHUMA forma de limpar isso pelos
caminhos que o reboot-por-panic real do ESP-IDF de fato usa. Se isso ocorrer no APP_CPU, o próprio
ESP-IDF trava para sempre por design (achado do parágrafo anterior) -- batendo exatamente com o
sintoma observado (`arena->running=1`, heartbeats seguem, guest genuinamente travado).

**Bloqueios de ambiente que impediram a confirmação ao vivo nesta sessão** (nenhum é do código sob
investigação): disco a 0 bytes livres no início (ENOSPC numa edição banal; liberado ~5GB via
lixeira+cache pip/npm -- ~3,8GB livres ao final, confirmado; vale atenção independente deste bug);
um `qemu-system-xtensa.exe` (binário oficial implantado) órfão de ~4h consumindo ~8h de CPU
acumuladas, provável espécime do próprio hang, morto para liberar CPU; contenção pesada da
investigação paralela da seção 32.5.3 recompilando o Core; e um hang REPRODUZIDO 4/4 vezes (com o
binário oficial E com um instrumentado, descartando as próprias mudanças como causa) no próprio
`session_restart_stress_test.exe` -- ver 32.5.5 abaixo, achado novo e distinto que impediu a coleta
de uma bateria ao vivo.

Instrumentação usada (log dedicado sem cap em `c:/tmp/lasecsimul_cache_trace.log`, fechando o risco de
truncamento do `qemuLogs()` de 1MiB já apontado em 32.5.1: trap hits em `esp32_cache_ill_read()`,
chamadas de clear em `esp32_dport_clear_ill_trap_state()`, tentativas de escrita em `MMU_IA_CLR`, e
status a cada reset por-núcleo em `esp32.c`) foi testada só até compilar; revertida sem rodar bateria
completa (`git checkout -- hw/misc/esp32_dport.c hw/xtensa/esp32.c` em `qemu_lasecSimul`, árvore de
novo limpa, confirmado).

**Próximo passo recomendado**: (1) resolver o ambiente primeiro -- espaço em disco, recompilar
`session_restart_stress_test` com a fonte atual (que já tem `LASECSIMUL_STRESS_BOOT_MS`, ver 32.5.5)
e investigar o hang pós-falha-de-boot como bug separado; (2) só depois, reaplicar a instrumentação
descrita acima numa bateria real de 60-90 ciclos, correlacionando timestamps pra confirmar se o trap
de fato dispara mais cedo do que a janela truncada da Hipótese 1 (já refutada em 32.5.2) conseguiu
capturar, e se `cpuid==-1` com o panic no APP_CPU realmente precede o travamento observado.

#### 32.5.5 Achado colateral: `session_restart_stress_test.exe` trava indefinidamente se o boot do
ciclo 0 não alcançar `arena->running==1` a tempo -- bug de harness novo e distinto (2026-07-26)

Durante a tentativa de bateria ao vivo da seção 32.5.4, achado que o binário compilado de
`session_restart_stress_test` (`core/build/Debug/`, timestamp 2026-07-25 19:48) estava desatualizado
em relação ao `.cpp` fonte atual (commit `c67ac1e`, 2026-07-26, que já introduziu
`LASECSIMUL_STRESS_BOOT_MS` como variável de ambiente pro timeout de boot) -- o binário rodando não
reflete esse knob, o timeout de boot fica fixo em 5000ms independente da variável.

Mais importante: **reproduzido 4/4 vezes, tanto com o binário QEMU oficial quanto com um
instrumentado** (descartando a própria instrumentação como causa) -- sempre que o boot do ciclo 0 não
alcança `arena->running==1` dentro do timeout, `session_restart_stress_test.exe` trava
INDEFINIDAMENTE, sem sequer chegar a imprimir o dump de `qemuLogs()` daquele ciclo (muito menos
`stopSimulation()`/ciclo 1/o resumo final). Só morre por kill externo. Este é um bug de harness novo
e distinto de tudo documentado em 32.3-32.5 até aqui -- ortogonal às duas falhas sob investigação, mas
foi o que efetivamente bloqueou a coleta de uma bateria ao vivo em 32.5.4, então fica registrado.
Ainda não investigado a fundo (fora do escopo desta sessão); candidato óbvio a next-step é localizar
POR QUE o caminho de timeout de boot não retorna controle pro laço de ciclos (suspeita: algum
`join()`/wait sem timeout próprio no caminho de cleanup de um MCU que nunca chegou a ficar pronto).

#### 32.5.6 Causa raiz do hang de 32.5.5 encontrada e corrigida: duas esperas sem limite, uma delas
uma corrida real de perda de wakeup -- e nova reprodução ao vivo do "Cache error" (2026-07-27)

Retomada focada no achado colateral de 32.5.5. Ambiente preparado conforme o protocolo pedido:
~35GB livres em disco, sem processos órfãos de `qemu-system-xtensa.exe`/`session_restart_stress_test.exe`,
`core/build` reconfigurado (o `cmake.exe` original do `CMakeCache.txt`, `C:\Strawberry\c\bin\cmake.exe`,
não existe mais nesta máquina -- reapontado pro `cmake.exe` empacotado com o VS Build Tools 2022,
`ZERO_CHECK` voltou a funcionar) e `session_restart_stress_test.exe` recompilado do `.cpp` atual.

**Duas esperas sem limite encontradas e corrigidas** (`Scheduler.cpp`/`QemuProcessManager.cpp`, ver
commit `test: prevent session restart stress harness hang on boot timeout`):

1. `QemuProcessManager::reapProcess()` fazia `WaitForSingleObject(hProcess, INFINITE)` depois de
   `TerminateProcess()`. Bate exatamente com o achado de 32.5.4 (processo órfão de ~4h/~8h de CPU
   acumulada): se o SO nunca reaper o processo depois do Terminate, este wait nunca retorna, e com
   ele qualquer chamador (inclusive o harness inteiro). Corrigido com um teto de 3s; se estourar,
   loga um aviso alto e abandona a limpeza (handle/thread leitor ficam pra trás de propósito) em vez
   de travar o chamador.
2. `Scheduler::stop()` fazia `m_running.store(false)` seguido de `m_wake.notify_all()` SEM segurar
   `m_mutex`. **Corrida real de perda de wakeup, reproduzida ao vivo**: existe uma janela dentro de
   uma ÚNICA chamada a `m_wake.wait(lock, predicate)` (branches "pausado"/"sem trabalho" de
   `start()`) entre o predicado ser avaliado falso e a worker de fato registrar a espera de baixo
   nível -- se `stop()` notifica nessa janela sem seguir o mesmo mutex, o notify não acorda ninguém
   (a worker ainda não estava registrada) e a espera seguinte nunca mais recebe outro. Reproduzido
   com um repro dedicado: qualquer `fprintf`/`fflush` por evento (a instrumentação óbvia de primeira
   tentativa) muda o timing o bastante pra MASCARAR a corrida inteira (0/212 repros instrumentados
   dessa forma) -- só reproduziu de forma confiável com um ring buffer em memória (sem I/O por
   evento) + uma thread watchdog externa que aborta o processo se a sequência não terminar num
   prazo, em vez de bloquear esperando por ela (o mesmo padrão pedido pro lado QEMU nesta tarefa,
   valido aqui primeiro). ~60% das execuções da sequência `pause()` -> drenar comando -> `stop()`
   travavam antes da correção. Corrigido protegendo a troca de `m_running` com `m_mutex` antes de
   notificar.
   - **Tentativa relacionada, revertida por causar um DEADLOCK diferente**: proteger `pause()`/
     `resume()` da mesma forma (mesma classe teórica de corrida) reabre um ciclo fechado contra um
     settle não-convergente -- `settleUntilStableLocked()` pode segurar `m_mutex` por tempo
     arbitrário e só solta ao ver `m_paused`/`m_stopRequested` num POLL sem lock (mecanismo
     deliberado pra permitir que `pause()`/`stop()` interrompam esse laço de fora); se `pause()`
     também precisar do mesmo lock, ela nunca roda enquanto o settle não converge, e o settle só
     converge vendo `m_paused`, que só muda depois que `pause()` conseguir o lock -- sem saída.
     `stop()` escapa desse ciclo porque `m_stopRequested` (lock-free, não alterado) já basta pra
     destravar o settle ANTES do `lock_guard` novo rodar. `pause()`/`resume()` permanecem lock-free;
     o risco teórico fica documentado no código, sem reprodução ao vivo confirmada (ao contrário do
     de `stop()`).
   - Teste de regressão permanente adicionado (`testPauseThenStopNeverHangsAcrossManyIterations`,
     200 iterações com watchdog próprio) -- uma única execução da suíte só pegava a corrida ~60% das
     vezes, insuficiente pra confiar numa regressão futura.

Harness também enriquecido (branch de timeout de boot agora registra `arena->running`/índices de
fila/UART parcial, não só `firmwareRunning()`) conforme os itens pedidos.

**Validado**: `scheduler_test` (15+ execuções consecutivas limpas + 4500+ iterações de stress nos três
cenários afetados), `qemu_process_manager_test`, `mcu_crash_resilience_test`, `mcu_debug_launch_test`,
e `session_restart_stress_test` (cenários de falha de boot forçada via binário QEMU falso + bateria
real de 15 ciclos).

**Achado colateral importante**: a própria bateria real de 15 ciclos (rodada como validação do fix de
harness, sem tocar o binário QEMU) reproduziu o "Cache error" ainda em aberto (32.5.1-32.5.4) **2 vezes
em 15 ciclos** (ciclos 0 e 6) -- taxa bem mais alta que o ~1/30-1/60 documentado antes, embora sem
mudança conhecida no binário QEMU que explique a diferença (pode ser variância normal de amostra
pequena). O dump de registradores de AMBOS os núcleos nas duas ocorrências mostra `EXCCAUSE=0x00000007`
e `EXCVADDR=0x00000000` IDÊNTICOS nos dois cores -- mais uma confirmação direta (agora com uma segunda
amostra) de que isto é o valor sintético `PANIC_RSN_CACHEERR` do ESP-IDF (32.5.4), não uma causa real
por núcleo. PCs resolvidos com sucesso via `addr2line`/`nm` genéricos do MinGW/MSYS2 já presentes na
máquina (`C:\SourceCode\tools\msys64\ucrt64\bin\addr2line.exe` -- BFD lê ELF xtensa sem precisar de
toolchain cross específico; nenhuma instalação do PlatformIO foi localizada nesta máquina) contra
`merger.elf` (`C:\SourceCode\EININDI01_GitHub_VSCode_PIO\sourcecode\merger.elf`):
- **Core 0 (PRO_CPU)**: `esp_cpu_wait_for_intr` (`esp_hw_support/cpu.c:64`) ←
  `esp_vApplicationIdleHook` ← `prvIdleTask` ← `vPortTaskWrapper` -- idle de verdade, igual à amostra
  de 32.5.2.
- **Core 1 (APP_CPU)**: PC dentro de `adc_ll_set_controller` (inline, `hal/esp32/include/hal/adc_ll.h:611`)
  ← `adc_oneshot_hal_setup` (`adc_oneshot_hal.c:88`) ← `adc_oneshot_read` (`adc_oneshot.c:227`) ←
  `__analogRead` (`esp32-hal-adc.c:316`) ← `loop()` (`main.cpp:29`) ← `loopTask`. Resolução mais fina
  que 32.5.2 (que só tinha chegado a `adc_oneshot_ll_start`), mas MESMA conclusão: o PC está dentro de
  uma escrita de registrador do controlador ADC (SENS/RTC), não numa região de cache DROM0/IRAM0 --
  reforça a leitura já registrada em 32.5.2/32.5.4 de que isto é só onde o APP_CPU estava executando
  quando o panic/NMI de dump foi disparado, não necessariamente a instrução que causou o acesso
  ilegal (que pode ter ocorrido antes, ou no outro núcleo). **Não investigado mais a fundo aqui** --
  confirma que resolver os PCs do dump de panic sozinho não basta; a instrumentação QEMU-side pedida
  na seção 3 desta tarefa (capturar o PRIMEIRO evento em `esp32_cache_ill_read()` com timestamp,
  núcleo, PC e estado de cache) é o próximo passo necessário, agora com um ambiente de teste
  confiável (harness corrigido) e uma taxa de reprodução (2/15) alta o bastante pra não exigir
  baterias enormes.

#### 32.5.7 Instrumentação QEMU-side implementada; achado que refuta a Hipótese 1 (trap de acesso
ilegal) de forma direta e nova; forte evidência de que o gatilho é uma corrida ligada ao MTTCG,
não ainda confirmada na instrução exata (2026-07-27)

**Ambiente de trabalho**: fork em `C:\SourceCode\qemu_lasecSimul` (repositório git próprio, separado
do monorepo `LasecSimul`), toolchain UCRT64 em `C:\SourceCode\tools\msys64\ucrt64` (`ninja`/`cc`),
build de rascunho nunca sobrepôs o binário oficial implantado em `devices/qemu-esp32/bin/`. Achado
de ambiente: uma cópia de rascunho feita só do `.exe` (`cp build-ucrt64/qemu-system-xtensa.exe`
pra um diretório novo) falha silenciosamente com `error while loading shared libraries:
libslirp-0.dll` -- o processo morre em milissegundos, o handshake da ABI v4 falha rápido (não por
timeout de 5s), e isso pareceu inicialmente com o harness "travando" numa bateria maior (múltiplos
ciclos citando `loadMcuFirmware lancou: ... handshake failed`, sem nunca progredir) até isolar com
`ps`/execução manual direta do binário. Correção: usar `run-ucrt64/` (já populado com todas as DLLs
do UCRT64 ao lado do `.exe` pelas builds anteriores) como destino do binário de rascunho, sobrescrito
a cada rebuild.

**Instrumentação implementada** (`hw/misc/esp32_dport.c`, `hw/xtensa/esp32.c`,
`include/hw/misc/esp32_dport.h` -- todas marcadas `[CACHE-TRACE]`, a reverter depois da causa raiz
confirmada, ver critério de aceitação): ring buffer em memória (sem I/O por evento, evitando repetir
o efeito Heisenbug já documentado na seção 32.5.6 para o bug do Scheduler -- qualquer `fprintf`/
`fflush` por evento muda timing o bastante pra mascarar corridas reais) com os seguintes pontos:
- `esp32_cache_ill_read()`: registra TODO hit no trap (mesmo com `illegal_access_trap_en==false`),
  core dono da região (via `crs->cache->core_id`, atribuição inequívoca -- cada núcleo tem seu
  próprio `cpu_specific_mem[i]`), PC do núcleo dono, `writer_core`/`writer_pc` (ver abaixo), endereço,
  tamanho, estado de cache/status ilegal de AMBOS os núcleos antes do evento.
- As quatro escritas de registrador de cache (`A_DPORT_{PRO,APP}_CACHE_CTRL{,1}`): old/new value,
  só quando o valor realmente muda (filtra escritas redundantes, que eram ~metade do volume).
- `A_DPORT_CACHE_IA_INT_EN` e `esp32_dport_clear_ill_trap_state()`.
- Os cinco resets por-núcleo em `esp32.c` (`esp32_cpu_reset`, `esp32_timg_cpu_reset`,
  `esp32_app_cpu_reset_async`, `esp32_dig_reset`, `esp32_timg_sys_reset`), via
  `esp32_cache_trace_reset_event()` novo, exportado no header.
- **`writer_core`/`writer_pc`** (achado de correção sobre a primeira versão da instrumentação): o
  parâmetro `core` original identificava só o DONO do registro/região (pra PRO_CACHE_CTRL é sempre
  0, pra APP_CACHE_CTRL é sempre 1) -- usá-lo pra resolver o PC dava o PC do núcleo DONO, não
  necessariamente de quem EXECUTOU a escrita (qualquer núcleo pode escrever no registro do outro,
  são só endereços MMIO comuns). Corrigido lendo `current_cpu` (global thread-local do QEMU, correto
  sob MTTCG porque cada vCPU tem sua própria thread) via `CPUClass::get_pc()` -- o mesmo hook
  genérico usado pro PC do dono, evitando incluir `target/xtensa/cpu.h` em código "common"
  (`hw/misc/*` é compilado sem headers per-target; a build recusa com
  `#error cpu.h included from common code` se tentado).
- **Despejo em disco throttled + captura permanente do primeiro evento crítico**: despejar o ring
  inteiro a CADA evento reabrindo/reescrevendo o arquivo travou uma bateria de 20 ciclos por mais de
  240s (nenhum ciclo além do 0 rodou) -- o loop de disable/enable de cache do flash (achado abaixo)
  dispara register-writes rápido demais pra sustentar um `fopen("w")`+N linhas de `fprintf` por
  evento. Corrigido: despejo do ring geral limitado a 1x/200ms de tempo de parede (`g_get_monotonic_time`),
  e uma captura SEPARADA, incondicional e permanente (`c:/tmp/lasecsimul_cache_trace_FIRST.log`,
  nunca reescrita de novo) disparada na primeira vez que `illegal_access_status` realmente latcheia
  (`illegal_access_trap_en==true`) -- despeja uma JANELA das últimas 500 entradas do ring até esse
  evento, garantindo contexto de lead-up mesmo que o ring geral (capacidade fixa, 20000 entradas)
  já tenha dado a volta muitas vezes por causa do volume do loop de flash.
- Nenhum dos dois arquivos cresce sem limite (capacidades fixas do array em memória e da janela) --
  ver achado de disco cheio na 32.5.4.

**ACHADO PRINCIPAL, reprodução ao vivo (3 ocorrências em baterias de 15 e 20 ciclos, firmware real,
binário instrumentado em `run-ucrt64/`)**: `c:/tmp/lasecsimul_cache_trace_FIRST.log` **NUNCA foi
criado em nenhuma das 3 reproduções do "Cache error"**, apesar do `Guru Meditation Error (Cache
error)` aparecer no UART em todas as 3. Ou seja: **`esp32_cache_ill_read()` nunca dispara com
`illegal_access_trap_en==true`** durante o panic -- o mecanismo de trap de acesso ilegal do DPORT
(a única coisa que pode setar `illegal_access_status`/levantar `cache_ill_irq` neste modelo) está
genuinamente inocente. Isto **refuta definitivamente a Hipótese 1** de 32.5.1 (já suspeita ali, mas
com instrumentação mais estreita e sem as três reproduções agora obtidas) com evidência direta e
independente: o "Cache error" relatado pelo ESP-IDF não vem de um hit real no trap deste modelo.

**Mecanismo ESP-IDF identificado ao redor do momento da falha** (via `nm`/`addr2line` genéricos do
MinGW/MSYS2 contra `merger.elf`, mesma técnica de 32.5.6 -- confirma que funcionam bem o bastante
pra este trabalho, nenhuma instalação do PlatformIO localizada nesta máquina): o log capturado (ring
geral, não o FIRST) mostra, imediatamente antes/depois da região temporal da falha, um loop RÁPIDO
(microssegundos de tempo virtual entre iterações) alternando `write_pro_cache_ctrl`/
`write_app_cache_ctrl` entre `CACHE_ENA=1` (0x28) e `CACHE_ENA=0` (0x20) em ambos os núcleos. PCs
resolvidos: `cache_ll_l1_disable_cache`/`cache_ll_l1_enable_cache`/`cache_ll_l1_enable_bus`
(`hal/esp32/include/hal/cache_ll.h`), chamadas a partir de `spi_flash_op_block_func`
(`components/spi_flash/cache_utils.c:109`) -- o mecanismo OFICIAL do ESP-IDF que desabilita o cache
de AMBOS os núcleos ao redor de qualquer operação de flash SPI (proteção padrão, não um bug em si).
**Achado de atribuição**: `writer_core` mostra que é sempre o **CORE 0 (PRO_CPU)** quem executa AMBAS
as escritas (`write_pro_cache_ctrl` E `write_app_cache_ctrl`) -- não é o APP_CPU (que roda
`analogRead()`) quem desabilita seu próprio cache; é o PRO_CPU quem coordena o disable/enable dos
DOIS núcleos via IPC, escrevendo diretamente nos registros do outro núcleo.

**Teste de controle direto do MTTCG, achado forte**: bateria de 15 ciclos com
`LASECSIMUL_ESP32_EXECUTION_MODE=deterministic` (modo `-icount`, single-thread, sem MTTCG) --
**15/15 ciclos OK, ZERO ocorrências de "Cache error"** (contra 2/15 e 3/15 em baterias comparáveis do
MESMO binário instrumentado sob MTTCG default). Bateria maior de confirmação (45 ciclos, mesmo modo
determinístico) iniciada para descartar "sorte" de amostra pequena -- ver resultado abaixo se já
concluída ao ler isto. Ressalva honesta (auto-imposta pela diretriz desta tarefa de não presumir
corrida só por haver duas threads): este resultado é evidência CIRCUNSTANCIAL forte, não ainda uma
demonstração direta, com timestamps, da sequência exata de uma thread executando com estado de
cache obsoleto enquanto a outra o altera. A bateria com o binário OFICIAL não-instrumentado (32.5.6,
seção "Achado colateral", 2/15 falhas) mostra taxa na MESMA ordem de grandeza da bateria instrumentada
-- indício de que a própria instrumentação (I/O throttled, não devia ser cara) NÃO é a causa principal
da taxa mais alta que o ~1/30-1/60 histórico; pode ser variância real de amostra pequena ou alguma
diferença de ambiente/host não identificada.

**Hipótese de trabalho (ainda não confirmada na instrução exata)**: o disable/enable coordenado pelo
PRO_CPU toca `esp32_cache_state_update()` → `esp32_cache_data_sync()` → `memory_region_flush_rom_device()`
(invalidação de TB/tradução do QEMU) SEPARADAMENTE para os `Esp32CacheRegionState` de CADA núcleo
(estruturas completamente separadas por núcleo, mesmo backing de flash). Sob MTTCG (uma thread TCG
por vCPU), se a invalidação dessa API não alcançar de forma síncrona/completa a thread do OUTRO
núcleo (ex.: um Translation Block já buscado por essa thread, mas ainda não invalidado no exato
instante da mudança), esse núcleo pode continuar executando/buscando instrução de conteúdo obsoleto
-- isto bateria com a exigência do item 3 da seção 4 desta tarefa ("Invalidação incompleta de TB ou
TLB") e com o item da "Condição de corrida MTTCG", e explicaria por que o EXCCAUSE real (7,
"PCValue" na tabela real do xtensa, não a pseudo-causa "Cache error" do ESP-IDF) aparece: buscar uma
instrução com conteúdo obsoleto/incorreto pode produzir um alvo de salto inválido, dessa vez uma
exceção XTENSA GENUÍNA (não sintética) que o `panic_soc_check_pseudo_cause()` do ESP-IDF
(`esp_system/port/arch/xtensa/panic_arch.c:261`) então relabela como "Cache error" por checar
alguma outra condição de estado SOC (não necessariamente `illegal_access_status` -- dado que esse
bit nunca latcheia nas 3 reproduções, a condição que `panic_soc_check_pseudo_cause()` realmente
verifica ainda não foi identificada linha a linha; candidato natural a próximo passo).

**Bateria de confirmação determinística concluída**: 45/45 ciclos adicionais, ZERO "Cache error"
(total acumulado 60/60 ciclos limpos em modo `-icount` determinístico, contra falhas em toda bateria
comparável sob MTTCG default -- ~15-20% neste ambiente). Estatisticamente muito forte: se a taxa sob
determinístico fosse sequer parecida com a pior taxa observada sob MTTCG (~20%), a chance de 0/60 por
acaso seria ~0,0002%. Reforça com solidez que o MTTCG (multithreading real do QEMU, não o
sincronismo Core↔QEMU) é condição necessária pra reproduzir o bug.

**Experimento direcionado, HIPÓTESE REFUTADA (2026-07-27, retomada após um crash do editor que
matou a sessão anterior no meio de uma bateria -- dois processos órfãos, `session_restart_stress_test.exe`
e `qemu-system-xtensa.exe`, encontrados e encerrados ao retomar; nenhum dado corrompido, os 3 arquivos-fonte
instrumentados sobreviveram intactos)**: adicionado um flush SÍNCRONO explícito extra de TLB em
todas as vCPUs (`tlb_flush_all_cpus_synced()`, a primitiva mais forte do QEMU pra isso, via
`async_safe_run_on_cpu()` -- garante que cada vCPU rode o flush antes do próprio próximo Translation
Block) logo após `memory_region_set_enabled()` em `esp32_cache_state_update()`, testando a hipótese
de que o mecanismo padrão do QEMU (`memory_region_transaction_commit()` → `tcg_commit()`) não estaria
alcançando as outras threads TCG a tempo sob MTTCG. **Resultado: bateria de 30 ciclos sob MTTCG (log
parcial, 18 ciclos observados antes do crash do editor interromper a coleta) ainda reproduziu o
"Cache error" 1 vez (ciclo 4/18 ≈ 5,5%)** -- dentro da mesma ordem de grandeza da taxa basal sem o
flush extra (~15-20%), não uma melhora estatisticamente convincente. **Hipótese refutada**: o
gargalo NÃO é falta de invalidação de TLB a nível de região de memória -- o mecanismo padrão do QEMU
já é suficiente nesse aspecto (consistente com ele ser um mecanismo central, testado por todo o
ecossistema QEMU, não específico deste fork). A alteração experimental foi revertida (removida de
`hw/misc/esp32_dport.c`, `hw/xtensa/esp32.c` e `include/hw/misc/esp32_dport.h`; árvore de instrumentação
voltou a conter só o tracing legítimo, ainda ativo) -- **não deixar essa reversão implícita**: o
helper `esp32_cache_trace_flush_all_tlbs()` e sua chamada existiram por um tempo curto só como teste,
nunca foram considerados a correção final.

**Achado adicional desta rodada**: no ciclo que falhou com o flush extra ativo, o dump de registrador
do Core 0 (PRO_CPU) mostrou, pela primeira vez nas reproduções desta sessão, um PC (`0x4008cb86`)
DENTRO da própria sequência de disable/enable de cache (`xt_utils_get_core_id`,
`xtensa/include/xt_utils.h:37` -- uma leitura trivial do ID do núcleo, tipicamente inlined dentro de
`spinlock_acquire()`), em vez de idle (`esp_cpu_wait_for_intr`) como nas capturas anteriores. Ou seja:
PRO_CPU também já foi capturado no meio do próprio mecanismo de coordenação `spi_flash_op_block_func`
no instante do panic, não só o APP_CPU rodando `analogRead()` -- mais um indício (ainda não prova)
de que a coordenação cross-core desse mecanismo (IPC/interrupção cruzada, stall do APP_CPU) é onde
observar em seguida, não a topologia de memória/TLB por si só.

**Estado ao pausar esta rodada**: `run-ucrt64/qemu-system-xtensa.exe` atualizado com o binário revertido
(só tracing, sem o flush extra), recompilado e confirmado limpo. Nenhum processo órfão, ~35GB livres em
disco. `hw/misc/esp32_dport.c`, `hw/xtensa/esp32.c`, `include/hw/misc/esp32_dport.h` seguem modificados
(tracing) em `qemu_lasecSimul` -- ainda não commitados (aguardando a causa raiz ser fechada, ou uma
decisão explícita de commitar a instrumentação separadamente). Harness fix já commitado e limpo em
`LasecSimul` (`5685825`). **Próximo passo mínimo e objetivo, em ordem de prioridade**: (1) instrumentar
o mecanismo de stall/IPC do APP_CPU (`appcpu_stall_state`/`appcpu_stall_req`, e o crosscore-interrupt
em `esp32_crosscore_int.c`) com timestamp, pra checar se existe uma janela em que o PRO_CPU já
desabilitou o cache do APP_CPU (`write_app_cache_ctrl`, sempre disparado pelo PRO_CPU per o achado
de `writer_core`) ANTES do APP_CPU efetivamente estar parado/estolado; (2) se essa janela existir e
for suficientemente larga, isso é a causa raiz; (3) se não, considerar tracing de execução do QEMU
(`-d exec,cpu`, mais pesado, non-trivial de correlacionar) como próximo recurso.

#### 32.5.8 Handshake completo instrumentado (IPC cross-core, stall de hardware, PC dos dois núcleos
em todo evento); NENHUM sinal de stall/quiescência observável precede os disables de cache
encontrados; causa raiz ainda NÃO fechada -- gargalo real é uma camada mais funda que a de
dispositivo (2026-07-27, retomada pós-crash do editor, rodada explicitamente time-boxed)

**Escopo desta rodada** (pedido explícito do usuário, restrito): instrumentar o handshake COMPLETO de
`spi_flash_op_block_func`/`esp_ipc_isr` -- pedido de IPC, stall do APP_CPU, confirmação de que o
APP_CPU parou, disable de cache, seção crítica de flash, re-enable, liberação do runstall -- gravando
o PC dos dois núcleos em CADA transição, e verificar (a) que nenhum disable de cache ocorre antes do
APP_CPU estar observavelmente quiescente e (b) que nenhuma tradução do APP_CPU executa com seu cache
desabilitado. Instrução explícita: **não usar MMU_IA_CLR como substituto desta investigação** -- não
implementado nesta rodada.

**Dois bugs corrigidos na própria instrumentação antes de conseguir dados confiáveis**:
1. `cache_trace_pid_path()` cacheava o buffer de path só verificando se o PID batia, não se a `base`
   (string) batia -- assim que QUALQUER chamada com QUALQUER base preenchia o cache uma vez por
   processo, todas as chamadas seguintes (mesmo com uma base diferente, ex.
   `CACHE_TRACE_UNEXPECTED_RESET_PATH`) recebiam de volta o path da PRIMEIRA base usada naquele
   processo. Resultado: a captura de "primeiro reset inesperado" (criada nesta mesma rodada, ver
   abaixo) nunca gerava um arquivo com esse nome -- os dados iam parar, silenciosamente, no arquivo
   do despejo regular. Corrigido formatando a string a cada chamada (custo desprezível -- só
   acontece nos poucos eventos que de fato despejam algo em disco).
2. **Achado colateral sério, fora do escopo da causa raiz do cache, mas com impacto direto na
   capacidade de rodar baterias longas sem supervisão**: durante uma bateria de 35 ciclos, o
   PRÓPRIO QEMU crashou internamente (`ERROR:../util/fifo8.c:62:fifo8_pop: assertion failed:
   (fifo->num > 0)` -- um assert do QEMU genérico, não deste fork, provavelmente num modelo de UART/
   FIFO tentando ler um FIFO já vazio; não investigado a fundo, fica registrado como achado aberto
   separado). Isso fez `session_restart_stress_test.exe` (processo PAI, build de Debug do MSVC)
   terminar com `abort()` (exit code 3) -- e o CRT de Debug do MSVC, por padrão, mostra uma caixa de
   diálogo MODAL ("Debug Error!... abort() has been called") que BLOQUEIA o processo esperando um
   clique humano. Isso travou a tela do usuário no meio de uma bateria automatizada (captura de
   tela confirmando o diálogo, processo precisou ser limpo manualmente). **Corrigido** (commit
   separado do harness, não misturado com a investigação do cache): `_CrtSetReportMode`/
   `_CrtSetReportFile`/`_set_abort_behavior`/`SetErrorMode` configurados no início de `main()` de
   `SessionRestartStressTest.cpp` pra redirecionar qualquer assert/erro do CRT e o WER pra
   stderr/saída direta do processo, nunca uma caixa de diálogo interativa -- essencial pra qualquer
   bateria futura de até 300 ciclos (pedida nos critérios de aceitação desta tarefa) rodar sem
   supervisão humana.

**Instrumentação adicionada** (além da já existente em 32.5.7): `pc0`/`pc1` (PC de AMBOS os núcleos,
sempre preenchidos em TODO evento, não só do dono do registro tocado); `esp32_cache_trace_generic_event()`
novo (não precisa de `Esp32DportState*`) usado por `hw/misc/esp32_crosscore_int.c` pra rastrear
`esp32_crosscore_int_write()` (o único ponto de IPC cross-core visível a nível de dispositivo --
`esp_ipc_isr_stall_other_cpu()`/`release_other_cpu()` escrevem aqui); rastreamento de escritas em
`A_DPORT_APPCPU_RUNSTALL` (o stall de HARDWARE via `xtensa_runstall`, distinto do handshake por
software). Capacidade do ring subida pra 20000 e path por-PID (achado de 32.5.7) garantem que cada
ciclo de uma bateria deixe seu próprio arquivo, sem se sobrescreverem.

**Dados coletados de uma falha real, cruzando uma sequência de disable/enable "boa" (início do boot,
sem reset depois) com outra que precede o primeiro reset inesperado**:
- Nenhuma escrita em `A_DPORT_APPCPU_RUNSTALL` e nenhuma `crosscore_int_write` aparece imediatamente
  antes de QUALQUER uma das sequências de disable/enable de cache observadas (nem a que terminou
  bem, nem a que precede o reset) -- ou seja, **este modelo (e, aparentemente, o firmware real
  ligado) não usa nenhum sinal de stall/quiescência visível a nível de registro/dispositivo antes de
  `cache_hal_suspend()`/`cache_ll_l1_disable_cache()` tocarem os registros de CACHE_CTRL dos dois
  núcleos**. A única atividade de `crosscore_int_write` observada em toda a bateria acontece nos
  primeiros ~2ms de boot (tráfego bidirecional PRO↔APP, mais consistente com notificação de
  scheduler do FreeRTOS entre núcleos do que com o protocolo `esp_ipc_isr` do spi_flash) -- depois
  disso, silêncio total nesses canais pelo resto da execução, mesmo com MÚLTIPLAS sequências de
  disable/enable de cache acontecendo (confirmado: o mecanismo de disable/enable repetido usado
  pelo firmware simplesmente não passa pelo protocolo IPC/runstall completo do
  `esp_ipc_isr_stall_other_cpu()`/`release_other_cpu()` nestas circunstâncias).
- Na sequência "boa" (múltiplos disables/enables nos primeiros ~2ms), o PC do APP_CPU
  (`pc1`) fica CONGELADO em `0x400817b5` (`spi_flash_op_block_func`, `cache_utils.c:109`) do início
  ao fim de toda a sequência -- interpretação mais provável (não confirmada por falta de acesso a
  memória/estado do FreeRTOS): o APP_CPU está girando numa espera de spinlock (`spinlock_acquire`)
  DENTRO da própria `spi_flash_op_block_func`, tentando entrar na mesma seção crítica que o PRO_CPU já
  segura -- código que roda em IRAM (seguro mesmo com o cache de flash desabilitado), não porque
  exista um sinal explícito de "pare agora" observado a nível de dispositivo.
- **Correção importante de uma leitura errada no meio desta própria investigação**: a princípio,
  interpretei uma segunda sequência de disable/enable (`pc1` CONGELADO em `0x401218c5`, dentro de
  `adc_ll_set_controller`/`adc_hal_set_controller` -- código dependente de cache, NÃO uma
  seção-crítica segura) como evidência direta de "cache desabilitado enquanto o APP_CPU ainda
  executava código perigoso". Reexaminando com mais cuidado: o PC de ESCRITA (`writer_pc`) dessa
  MESMA sequência (`0x40009ad0`/`0x40009aaf`/`0x40009ae5`) **não existe em nenhum símbolo do
  `merger.elf`** (confirmado via `nm` -- faixa `0x40009xxx` inteira sem nenhum símbolo) -- ou seja,
  é código da ROM de boot do chip (`esp32-v3-rom.bin`, um binário completamente separado que este
  fork carrega à parte, sem relação com os símbolos do firmware). Como a ROM de boot só roda bem no
  início de cada (re)inicialização, e o dump de `esp32_rtc_cntl.c` confirma que a escrita de reset
  por software (`A_RTC_CNTL_OPTIONS0`) já dispara `qemu_irq_pulse()` SINCRONAMENTE (sem timer/atraso
  de por-meio) para o handler de reset já rastreado, **a leitura mais provável agora é que esta
  segunda sequência de disable/enable já é PARTE DA LIMPEZA PÓS-PANIC do próprio panic handler do
  ESP-IDF** (a tentativa de gravar um core dump em flash, mencionada nos logs UART como
  `esp_core_dump_flash: Failed to erase flash`, que usa rotinas de SPI flash da ROM -- daí os
  símbolos ausentes), rodando DEPOIS que o panic real já aconteceu -- e o PC congelado do APP_CPU em
  `adc_ll_set_controller` é simplesmente o estado FINAL, já travado/em pânico, do núcleo (o MESMO PC
  visto em TODOS os dumps de registrador coletados até aqui), não um núcleo ainda executando
  perigosamente. **A hipótese de "corrida no handshake" fica portanto NEM confirmada NEM refutada
  por estes dados -- eles mostram consequência pós-panic, não a causa.**

**Gap real identificado**: entre o último evento rastreável antes da falha (fim da sequência "boa",
virt_ns≈2,08ms) e a primeira atividade pós-panic capturada (virt_ns≈5,976s), há quase 4 SEGUNDOS de
tempo virtual em que NENHUM dos registros hoje instrumentados (CACHE_CTRL/CTRL1, CACHE_IA_INT_EN,
crosscore-int, APPCPU_RUNSTALL, os cinco resets por-GPIO) muda de estado -- ou seja, **o evento que
efetivamente dispara o panic não passa por NENHUM destes registros**. Isso é consistente com o já
confirmado em 32.5.7 (a trap `esp32_cache_ill_read()` deste modelo nunca dispara): o `EXCCAUSE=7`
real (não a pseudo-causa "Cache error") é uma exceção XTENSA GENUÍNA levantada inteiramente dentro da
execução da CPU (um alvo de salto/PC inválido) -- ela nasce em `target/xtensa/` (o helper que gera a
exceção, ex. `gen_exception_cause`/`HELPER(exception_cause)`), não em nenhum modelo de dispositivo
(`hw/misc`/`hw/xtensa`) que este fork tenha instrumentado até agora. **Instrumentar mais um
dispositivo (DPORT, RTC_CNTL, crosscore-int) não vai alcançar esse evento** -- ele é uma camada
abaixo, no núcleo de tradução/execução do QEMU.

**Estado ao final desta rodada (time-boxed, conforme pedido)**: nenhum fix de causa raiz foi
implementado (a causa raiz não está confirmada na instrução -- correto não implementar MMU_IA_CLR
como pedido explicitamente). `hw/misc/esp32_dport.c`, `hw/xtensa/esp32.c`,
`hw/misc/esp32_crosscore_int.c`, `include/hw/misc/esp32_dport.h` seguem com a instrumentação de
tracing (ainda não commitada em `qemu_lasecSimul` -- será commitada junto da correção final ou
descartada, conforme o critério de aceitação "todas as alterações experimentais foram removidas").
`core/test/core/mcu/SessionRestartStressTest.cpp` ganhou a supressão de diálogo do CRT (achado
2, acima) -- este SIM deve ser commitado como parte do commit de harness já feito (ou um commit de
harness adicional pequeno, separado da investigação do cache). Nenhum processo órfão, ~35GB livres em
disco, árvore do harness (`LasecSimul`) com só essa mudança pendente de commit.

**Próximo passo mínimo e objetivo**: instrumentar a geração de EXCCAUSE real no nível de
`target/xtensa/` (candidatos: o helper que popula `EXCCAUSE`/`EPC1` antes de entrar no vetor de
exceção, ou o ponto que decide um PC de salto inválido) com o mesmo padrão de ring buffer +
throttle já validado (evitando o Heisenbug de I/O por evento já documentado duas vezes nesta
investigação) -- é a ÚNICA forma de capturar a instrução exata que gera a exceção real antes que o
firmware a relabele como "Cache error" e reinicie. Sem isso, qualquer fix seria especulativo.

#### 32.5.9 `target/xtensa/exc_helper.c` instrumentado nos dois únicos pontos de entrada de exceção/
interrupção; hipótese-âncora de 32.5.8 ("EXCCAUSE=7 é uma exceção Xtensa genuína") **REFUTADA por
dados diretos** -- NENHUMA exceção síncrona genuína ocorre em nenhuma das 26 inicializações
rastreadas, incluindo 3 que gerou "Cache error" (2026-07-27, rodada explicitamente time-boxed,
escopo restrito a `target/xtensa/`, sem alterar handshake nem implementar MMU_IA_CLR)

**Escopo desta rodada** (pedido explícito do usuário, restrito): instrumentar o caminho mais cedo
possível de levantamento de exceção/interrupção em `target/xtensa/exc_helper.c`, ANTES do ESP-IDF
tratar qualquer coisa, capturando core, PC, próximo PC, causa, endereço virtual, endereço físico
quando disponível, tipo de acesso, bytes da instrução, e disparando um dump de ring buffer limitado
no PRIMEIRO evento qualificado, sem tocar no handshake nem implementar MMU_IA_CLR.

**Dois pontos de instrumentação**, escolhidos por serem os ÚNICOS lugares onde `env->pc` é
sobrescrito pelo vetor de exceção/interrupção (qualquer captura depois disso já perderia o PC/estado
que causou o evento):
1. `handle_interrupt()`, dentro do ramo `level > 1` (interrupções de alta prioridade/NMI), ANTES de
   `env->sregs[EPC1 + level - 1] = env->pc` sobrescrever qualquer coisa.
2. `xtensa_cpu_do_interrupt()`, dentro do switch de `cs->exception_index`, restrito a
   `EXC_KERNEL`/`EXC_USER`/`EXC_DOUBLE` (excluindo deliberadamente `EXC_WINDOW_OVERFLOW*`/
   `EXC_WINDOW_UNDERFLOW*` -- rotina de ABI de janela de registradores, dispara constantemente -- e
   `EXC_DEBUG`, irrelevante aqui), ANTES de `env->pc = relocated_vector(env, vector)`.

**Bug de instrumentação encontrado e corrigido antes de conseguir dados úteis**: a primeira versão
gravava QUALQUER evento `EXC_KERNEL`/`EXC_USER`/`EXC_DOUBLE`, inclusive os que carregam
`EXCCAUSE=LEVEL1_INTERRUPT_CAUSE` -- que é como `handle_interrupt()` disfarça QUALQUER interrupção de
nível 1 (UART, tick de timer, etc., ver código em 32.5.8 do mesmo arquivo) de exceção síncrona. Como
isso acontece milhares de vezes por bateria (1651 eventos num único boot de ~3s virtuais, contra uma
capacidade de ring de 256), o ring ficava 100% ocupado por ruído de interrupção rotineira e a
primeira captura ("primeiro evento", arquivo separado permanente) nunca continha nada além do
primeiro tick de nível 1 do boot -- o mesmo padrão de "ruído afogando o sinal" já visto (e corrigido
de outras formas) em 32.5.7/32.5.8. **Corrigido** filtrando `EXCCAUSE == LEVEL1_INTERRUPT_CAUSE` para
fora do ponto 2 (não é uma exceção síncrona genuína, é uma interrupção relabeled) -- o ring passou a
conter exclusivamente causas síncronas reais (ILLEGAL_INSTRUCTION, LOAD/STORE error, TLB, privilégio,
etc.) e interrupções de alta prioridade genuínas (ponto 1).

**Bateria de validação**: 30 ciclos com firmware real (`merged.bin`), MTTCG, `LASECSIMUL_STRESS_RUN_MS=5000`.
Duas rodadas:
- Rodada 1 (antes do filtro): 3 panics "Cache error" (ciclos 0, 3, 19) em 30 -- confirma taxa de
  reprodução consistente com o já observado (~10-15%). Ring 100% ruído de nível 1 em TODOS os
  processos, inclusive os que panicaram -- inconclusivo, motivou o filtro acima.
- Rodada 2 (depois do filtro, binário recompilado e re-implantado em `run-ucrt64/` e
  `devices/qemu-esp32/bin/`, SHA-256 documentado em `BUILD-PROVENANCE.txt`): 3 panics "Cache error"
  (ciclos 0, 1, 16) em 26 completados -- a bateria foi interrompida no ciclo 25 por um crash INTERNO
  do próprio QEMU (`ERROR:../util/fifo8.c:62:fifo8_pop: assertion failed: (fifo->num > 0)`, o MESMO
  bug genérico (não deste fork) já registrado em 32.5.8 achado 2 -- `session_restart_stress_test.exe`
  terminou com exit code 3, sem travar a tela graças à supressão de diálogo do CRT já commitada).
  Achado central: **em TODOS os 26 processos rastreados, incluindo os 3 que geraram "Cache error", o
  ponto 2 (exceção síncrona genuína) NUNCA disparou uma única vez** -- confirmado por grep manual
  descartando linhas de cabeçalho (`grep -c -v LEVEL1_INTERRUPT_CAUSE\|HIGH_PRIO_INTERRUPT` em cada
  arquivo retornou exatamente 1, a própria linha de cabeçalho do dump, em todos os 26 arquivos). O
  ponto 1 (interrupção de alta prioridade) disparou 1 ou 3 vezes por processo, sempre no mesmo nível
  (5) e, nas ocorrências de 3 eventos, sempre no mesmo padrão temporal (dois eventos quase
  simultâneos em `cpu=1`/PC `0x400817b5` por volta de ~1,4-1,5ms virtuais, seguido de um terceiro
  evento isolado, em PC variável, entre ~3,1s e ~5,9s virtuais) -- **idêntico em ciclos que panicaram
  E em ciclos que passaram limpos**, ou seja, não é o diferenciador.

**Verificação adicional (dentro do escopo, confirmando a causa raiz do ponto 2 nunca disparar)**:
`grep -rn "sregs\[EXCCAUSE\]\s*="` em todo `target/xtensa/` mostra exatamente DOIS locais de escrita
em todo o emulador: `HELPER(exception_cause)` (linha ~299, o helper chamado por código gerado pelo
TCG para QUALQUER exceção síncrona genuína -- illegal instruction, load/store error, etc.) e
`handle_interrupt()` (linha ~427, o caminho de nível 1 já filtrado). Ambos os pontos estão cobertos
pela instrumentação (o ponto 2 captura o estado logo depois de `HELPER(exception_cause)` já ter
rodado, já que `HELPER(exception_cause)` termina chamando `HELPER(exception)` que faz
`cpu_loop_exit()`, devolvendo o controle exatamente para `xtensa_cpu_do_interrupt()`). Não existe
um terceiro caminho, oculto, de escrita em `EXCCAUSE` neste fork.

**Conclusão desta rodada -- refutação direta da hipótese-âncora de 32.5.8**: a hipótese registrada ao
final de 32.5.8 ("o `EXCCAUSE=7` real é uma exceção Xtensa genuína levantada inteiramente dentro da
execução da CPU, em `target/xtensa/`, ainda não instrumentada") está **refutada por dados diretos**:
agora que exatamente esse ponto está instrumentado, ele nunca dispara, nem nos 3 ciclos que de fato
geraram "Cache error". Isso força uma conclusão mais forte que a de 32.5.7: não é só que
`esp32_cache_ill_read()` (a trap de dispositivo) nunca dispara -- é que NENHUMA exceção síncrona
genuína do modelo de CPU Xtensa dispara. A única forma de o firmware real imprimir
`EXCCAUSE: 0x00000007` no dump do panic é o próprio ESP-IDF **sintetizar/sobrescrever** esse valor em
software no momento de montar a mensagem de panic (consistente com `panic_soc_check_pseudo_cause()`,
já identificado estaticamente em 32.5.4) -- a entrada real no panic handler deve vir de um caminho
completamente ordinário (mais provavelmente uma das interrupções de nível 1, rotineiras e filtradas
aqui por serem "ruído", ou a própria interrupção de nível 5 que dispara igualmente em ciclos bons e
ruins), e o ESP-IDF então lê, de forma totalmente independente de qualquer trap de CPU, algum estado
de dispositivo (candidato mais forte: o registrador de status de acesso ilegal ao cache,
`illegal_access_status`, ou equivalente, já rastreado em escrita desde 32.5.6/32.5.7 mas NUNCA em
leitura) e encontra esse estado incorretamente marcado -- e é ESSA leitura, não uma exceção de CPU,
que precisa ser instrumentada a seguir.

**Estado ao final desta rodada (time-boxed, conforme pedido)**: nenhum fix de causa raiz implementado
(correto -- a causa raiz ainda não está confirmada). MMU_IA_CLR e o handshake `esp_ipc_isr` NÃO foram
alterados, conforme pedido explicitamente. `target/xtensa/exc_helper.c` segue com a instrumentação de
tracing (não commitada -- será commitada junto da correção final ou descartada, conforme critério de
aceitação). `qemu-system-xtensa.exe` recompilado duas vezes nesta rodada e reimplantado em
`run-ucrt64/` e `devices/qemu-esp32/bin/` (SHA-256 final:
`94C9C4A52ECD4BC04636A1CA4D1088958A6E28B7C19B9E98686CB73A9C8164F3`, documentado em
`devices/qemu-esp32/bin/BUILD-PROVENANCE.txt`). Nenhum processo órfão confirmado após ambas as
baterias. ~35GB livres em disco. Arquivos de trace (`c:/tmp/lasecsimul_xtensa_exc_trace*.log`) são
artefatos de diagnóstico temporários, não commitados.

**Próximo passo mínimo e objetivo**: instrumentar a LEITURA (não só a escrita, já coberta desde
32.5.6/32.5.7) do registrador de status de acesso ilegal ao cache em `hw/misc/esp32_dport.c`,
correlacionando com a atividade da interrupção de nível 5 (candidato: o Interrupt Watchdog do
ESP-IDF, que por convenção do próprio ESP-IDF é alocado em `ESP_INTR_FLAG_LEVEL5` -- ainda não
confirmado contra o binário/símbolos do firmware, fica como hipótese a verificar) -- para determinar
se esse registrador é lido com um valor indevidamente marcado ANTES do texto "Cache error" aparecer,
e, se sim, rastrear para trás até a escrita que o deixou nesse estado incorreto.

#### 32.5.10 Leitura de `illegal_access_status` instrumentada; hipótese de 32.5.9 também REFUTADA --
o bit nunca é lido como setado, nem no lado PRO nem no lado APP (o lado APP nunca é sequer lido);
correlação com símbolos reais do ELF do firmware aponta para `esp_cache_err_get_cpuid()` retornando
sempre -1 como explicação mais provável para o valor fixo `EXCCAUSE: 0x00000007` (2026-07-27, rodada
time-boxed, escopo restrito à leitura do registrador, sem alterar handshake nem implementar MMU_IA_CLR)

**Escopo desta rodada**: instrumentar a LEITURA de `A_DPORT_PRO_DCACHE_DBUG3`/`A_DPORT_APP_DCACHE_DBUG3`
em `esp32_dport_read()` (`hw/misc/esp32_dport.c`) -- os únicos registradores deste modelo que expõem
`illegal_access_status` para software, até agora só rastreados em ESCRITA (32.5.6/32.5.7). Reaproveita
integralmente a infraestrutura já existente (`cache_trace_record()`, ring, path por-PID, throttle) --
nenhum mecanismo novo, só dois novos pontos de chamada dentro do `switch` já existente.

**Bateria de validação**: 30 ciclos, firmware real, MTTCG, `LASECSIMUL_STRESS_RUN_MS=5000` -- desta
vez completou os 30 ciclos limpos (sem o crash interno do QEMU visto na rodada anterior). 3 panics
"Cache error" (ciclos 3, 4, 8).

**Achado -- segunda hipótese consecutiva refutada por dados diretos**:
- `A_DPORT_PRO_DCACHE_DBUG3` é lido exatamente 1 vez por processo em 18 dos 30 processos (0 vezes nos
  outros 12) -- **em TODAS as 18 ocorrências, sem exceção, o valor lido é `0x00000000`** (nenhum bit
  `IA_INT_DROM0`/`IA_INT_IRAM0` setado), inclusive nos processos que geraram "Cache error".
- `A_DPORT_APP_DCACHE_DBUG3` **nunca é lido nem uma única vez em nenhum dos 30 processos** -- ninguém
  neste conjunto de reproduções consulta o status de acesso ilegal do APP_CPU.
- Confirmado via `grep -h EXCCAUSE` nos dumps de panic reais das 3 baterias desta sessão (9 panics ao
  todo): **`EXCCAUSE: 0x00000007` aparece em TODAS as 9 ocorrências, sem nenhuma variação** -- reforça
  que não é um valor de hardware genuíno lido no momento (já refutado em 32.5.9), é uma constante fixa
  que o firmware imprime independente do que realmente aconteceu.

**Correlação nova com símbolos reais do ELF** (`nm` em `merger.elf`, mesmo binário desta bateria):
a única leitura de `A_DPORT_PRO_DCACHE_DBUG3` acontece com o núcleo executor (`writer_pc`) em
`0x40082a8b`-`0x40082a93` -- dentro de `esp_dport_access_reg_read` (`T esp_dport_access_reg_read` em
`0x40082a88`, o wrapper de acesso "seguro" a registradores DPORT do próprio ESP-IDF) -- e o PC do
OUTRO núcleo, no mesmo instante, tipicamente dentro do corpo de `panic_handler`
(`t panic_handler` em `0x400e1990`, próximo símbolo `print_state_for_core` em `0x400e1ad0`; PCs
observados: `0x400e19d9`, `0x400e19e1`, `0x400e19ec`) ou bem na entrada de
`esp_cache_err_get_cpuid` (`T esp_cache_err_get_cpuid` em `0x400e2170`, achado EXATO em pelo menos
duas ocorrências). Isso é uma correlação forte, não uma prova: o núcleo que efetivamente lê o
registrador está executando `esp_dport_access_reg_read()` (chamado de dentro de
`esp_cache_err_get_cpuid()`, que por sua vez é chamado de dentro de `panic_handler()` -- todos os
três símbolos existem e são adjacentes na faixa `0x400e19xx`-`0x400e21xx`/`0x40082a8x` do firmware
real).

**Hipótese mais forte até agora, ainda NÃO confirmada por instrumentação de PC-de-entrada de função**:
`esp_cache_err_get_cpuid()` (padrão conhecido, já citado explicitamente na tarefa original: "não deve
retornar -1 para um acesso real do APP_CPU") verifica o status PRO primeiro; como está SEMPRE zerado
neste modelo (`esp32_cache_ill_read()`, o único ponto que setaria `illegal_access_status=true`, nunca
dispara -- confirmado repetidamente desde 32.5.7), a função deveria then verificar o status APP -- mas
isso NUNCA acontece em nenhuma das 30 execuções (`read_app_dcache_dbug3` com contagem zero). Duas
explicações possíveis, nenhuma confirmada ainda: (a) a lógica real teria um curto-circuito diferente
do assumido (ex.: check condicionado por qual núcleo está chamando), ou (b) -- mais provável dado o
padrão já sinalizado na tarefa original -- a função sempre retorna `-1` (nem PRO nem APP com bit
setado) e ESP-IDF, ao encontrar `cpuid == -1`, cai num caminho de fallback que força a exibição do
panic como "Cache error"/`EXCCAUSE=7` independente de qualquer estado real de hardware. Isso
uniificaria TODOS os achados desta investigação até aqui: nenhuma exceção síncrona genuína (32.5.9),
nenhum bit de status real setado (esta rodada), e um valor de EXCCAUSE sempre idêntico (9/9 ocorrências).

**Por que esta rodada parou aqui**: confirmar a hipótese acima com certeza exigiria rastrear a ENTRADA
por PC em `esp_cache_err_get_cpuid`/`panic_soc_check_pseudo_cause` (endereços `0x400e2170`/`0x4016ec54`,
achados via `nm` nesta mesma rodada) via um mecanismo de "breakpoint" por PC arbitrário -- uma técnica
qualitativamente diferente e mais pesada do que tudo usado até aqui neste fork (todos os pontos
instrumentados até agora reaproveitam despacho de exceção/interrupção ou MMIO já existente; nenhum
observa código ordinário chegando num PC arbitrário). Por prudência (pedido explícito do usuário pra
manter cada rodada estritamente time-boxed e escopada), isso fica como o próximo passo proposto, não
implementado nesta rodada.

**Estado ao final desta rodada**: nenhum fix implementado. MMU_IA_CLR e o handshake `esp_ipc_isr` não
alterados. `hw/misc/esp32_dport.c` ganhou só as duas chamadas de `cache_trace_record()` nos cases
`A_DPORT_PRO_DCACHE_DBUG3`/`A_DPORT_APP_DCACHE_DBUG3` de `esp32_dport_read()` (instrumentação, não
commitada). `qemu-system-xtensa.exe` recompilado e reimplantado em `run-ucrt64/` e
`devices/qemu-esp32/bin/` (SHA-256:
`F5CEA00AF32BEB30AE46AE85B3860C8EDA2BA6B3871CC487FD2742D0CDA44983`, em `BUILD-PROVENANCE.txt`).
Nenhum processo órfão. ~35GB livres em disco.

**Próximo passo mínimo e objetivo**: instrumentar entrada por PC em `esp_cache_err_get_cpuid`
(`0x400e2170`) e `panic_soc_check_pseudo_cause` (`0x4016ec54`) -- endereços específicos DESTE build do
firmware, não genéricos -- registrando qual núcleo entra, em que `virt_ns`, e o `EXCCAUSE`/`EXCVADDR`
reais do núcleo que panica NAQUELE instante (antes de qualquer possível sobrescrita em software), pra
confirmar ou refutar de vez a hipótese de "cpuid == -1 -> fallback força Cache error".

#### 32.5.11 Escalada explicitamente autorizada pelo usuário ("pode escalar"): observador de entrada
por PC (não-intrusivo, sem exceção) implementado em `target/xtensa/`; `esp_cache_err_get_cpuid()` e
`panic_soc_check_pseudo_cause()` capturados em execução real; `EXCCAUSE` no momento da chamada é
SEMPRE 4 (LEVEL1_INTERRUPT_CAUSE), nunca 7; três locais de chamada resolvidos por símbolo real do
ESP-IDF via `addr2line` (2026-07-27, rodada time-boxed, escopo restrito à observação, sem alterar
handshake nem implementar MMU_IA_CLR)

**Escopo desta rodada**: com autorização explícita do usuário para escalar além de pontos de
despacho de exceção/interrupção/MMIO já existentes (técnica usada em todas as rodadas anteriores),
implementar um observador de ENTRADA POR PC ARBITRÁRIO em duas funções específicas do firmware real
(`esp_cache_err_get_cpuid` em `0x400e2170`, `panic_soc_check_pseudo_cause` em `0x4016ec54`, endereços
obtidos via `nm` no ELF real usado nesta bateria -- não genéricos, específicos deste build).

**Mecanismo implementado** (deliberadamente NÃO-intrusivo -- diferente de um breakpoint/exceção de
debug real):
1. `target/xtensa/helper.h`: novo `DEF_HELPER_3(trace_watched_pc, void, env, i32, i32)` -- um helper
   comum de TCG (`void`, não `noreturn`), não uma exceção.
2. `target/xtensa/exc_helper.c`: `HELPER(trace_watched_pc)` grava um evento (core, PC, `A0` --
   endereço de retorno --, `A2`/`A3`, `EXCCAUSE`/`EXCVADDR`/`PS` reais do momento) num ring pequeno
   (64 entradas) com despejo throttled por-PID, mesmo padrão já validado nas demais instrumentações
   desta investigação. NÃO chama `cpu_loop_exit()`, não mexe em `cs->exception_index` nem em
   `env->pc` -- é estritamente uma observação lateral, sem efeito no comportamento/timing da CPU
   além do custo (desprezível) da própria chamada de helper.
3. `target/xtensa/translate.c`: nova `gen_pc_watch_check(dc)`, seguindo o mesmo padrão estrutural de
   `gen_ibreak_check()` (o mecanismo REAL de hardware breakpoint deste emulador, `IBREAKA`/
   `IBREAKENABLE`) mas SEM chamar `gen_debug_exception()` -- só emite
   `gen_helper_trace_watched_pc()` quando `dc->pc` bate com um dos dois endereços observados. Chamada
   incondicionalmente em `xtensa_tr_translate_insn()` (ao contrário de `gen_ibreak_check`, que só
   roda se `dc->debug` estiver setado) -- precisa observar toda entrada real, independente do estado
   de debug arquitetural do guest.

**Bateria de validação**: 30 ciclos, firmware real, MTTCG, `LASECSIMUL_STRESS_RUN_MS=5000` -- completou
limpo, 3 panics "Cache error" (ciclos 7, 14, 18).

**Achados**:
- `esp_cache_err_get_cpuid()` foi capturado em 11 dos 30 processos (1 a 5 vezes cada); em TODAS as
  capturas, sem exceção, `EXCCAUSE=4` (`LEVEL1_INTERRUPT_CAUSE`) e `EXCVADDR=0x00000000` -- ou seja,
  no exato momento em que essa função roda, o registrador de causa real da CPU mostra uma interrupção
  de nível 1 ROTINEIRA, nunca `7`. Isso é uma confirmação direta, agora por observação de dentro do
  próprio caminho do panic (não só por eliminação como em 32.5.9/32.5.10), de que a entrada nesse
  código vem de uma interrupção comum, não de uma exceção síncrona genuína.
- `panic_soc_check_pseudo_cause()` foi capturado em apenas 1 dos 11 processos com atividade
  (`lasecsimul_xtensa_pcwatch.2164.log`) -- a diferença entre "só entra em esp_cache_err_get_cpuid"
  (10 processos, aparentemente sem escalar a panic) e "chega a chamar panic_soc_check_pseudo_cause
  também" (1 processo) é o candidato mais provável para o que efetivamente decide se vira panic ou
  não -- ainda não confirmado com certeza (não foi possível correlacionar o PID desse arquivo com o
  número exato do ciclo pelos logs disponíveis, mas a proporção -- 1 em 11 -- é consistente com 3
  panics em 30 ciclos totais).
- **Resolução por símbolo real via `addr2line` nos endereços de retorno (`A0`, decodificados com a
  fórmula real de call windowed do Xtensa -- `(a0 & 0x3FFFFFFF) | 0x40000000`, confirmada
  empiricamente por bater exatamente com `panic_handler` em dois casos diferentes)**:
  - `0x40081c80` → `panicHandler`, `esp_system/port/panic_handler.c:301` -- o site de chamada MAIS
    comum, usado tanto por `esp_cache_err_get_cpuid()` quanto por `panic_soc_check_pseudo_cause()`
    (mesma linha/região chama as duas em sequência).
  - `0x400e1a95` → `panic_handler` (minúsculo, wrapper específico do SoC), `panic_handler.c:266`.
  - `0x4017d6c6` → `esp_panic_handler`, `panic.c:423` (camada genérica, independente de chip).
  - As três resoluções batem exatamente com a arquitetura conhecida do ESP-IDF (`panicHandler` é o
    despachante de baixo nível chamado pelo vetor de exceção real; `panic_handler`/`esp_panic_handler`
    são as camadas de SoC/genérica que processam e imprimem o relatório) -- ou seja,
    `esp_cache_err_get_cpuid()` É chamada DE DENTRO do próprio fluxo de tratamento de panic, em
    múltiplos pontos, consistente com apuração de qual núcleo culpar DEPOIS que algo já decidiu entrar
    em modo panic -- não como um trigger independente.
  - Ambos os núcleos (`cpu=0` e `cpu=1`) entram em `esp_cache_err_get_cpuid()` de forma
    quase-simultânea (microssegundos a poucos milissegundos de diferença em `virt_ns`) nos processos
    onde há atividade -- consistente com o núcleo que panica notificando/parando o outro núcleo como
    parte do próprio protocolo de panic (não uma corrida acidental).
  - Código fonte real do ESP-IDF (`panic_handler.c`/`panic.c`) não está disponível localmente nesta
    máquina para leitura direta das linhas exatas -- a correlação acima vem inteiramente do DWARF
    embutido no `merger.elf` via `addr2line`, não de acesso ao repositório do ESP-IDF.

**Por que esta rodada parou aqui**: o próximo nível de detalhe (confirmar exatamente qual condição,
dentro de `panicHandler.c:301`/`panic_soc_check_pseudo_cause()`, decide entre "só verificar e seguir"
vs. "escalar pra panic com Cache error") exigiria either (a) acesso ao código-fonte real do ESP-IDF
correspondente a este build (não disponível nesta máquina) ou (b) mais um nível de observação por PC
dentro do próprio corpo de `panic_soc_check_pseudo_cause` (ex.: nos possíveis pontos de retorno/branch
internos) -- viável com a MESMA técnica já validada nesta rodada, mas sem o código-fonte real como
referência corre-se o risco de instrumentar o endereço errado por suposição.

**Estado ao final desta rodada**: nenhum fix implementado. MMU_IA_CLR e o handshake `esp_ipc_isr` não
alterados. Novos arquivos com instrumentação (não commitados): `target/xtensa/helper.h`,
`target/xtensa/exc_helper.c` (bloco `[XTENSA-PC-WATCH]`), `target/xtensa/translate.c`
(`gen_pc_watch_check`). `qemu-system-xtensa.exe` recompilado e reimplantado em `run-ucrt64/` e
`devices/qemu-esp32/bin/` (SHA-256:
`4BB25AA49010D539C3D87FD9D75EDFB07261B7627DCDF1129E697F36D635D285`, em `BUILD-PROVENANCE.txt`).
Nenhum processo órfão. ~35GB livres em disco. Arquivos de trace
(`c:/tmp/lasecsimul_xtensa_pcwatch*.log`) são artefatos de diagnóstico temporários, não commitados.

**Próximo passo mínimo e objetivo**: obter (com o usuário) o código-fonte real do ESP-IDF
correspondente a este build (`panic_handler.c`, `panic.c`, `cache_err_int.c` ou equivalente) pra ler
diretamente a condição que decide escalar pra "Cache error" -- muito mais eficiente e confiável do que
continuar adivinhando endereços por instrumentação. Alternativa, se o código-fonte não estiver
disponível: instrumentar mais dois ou três pontos de retorno/branch dentro do corpo de
`panic_soc_check_pseudo_cause`/`esp_cache_err_get_cpuid` (offsets pequenos a partir de `0x4016ec54`/
`0x400e2170`, ainda a determinar) com a mesma técnica de PC-watch já validada.

#### 32.5.12 Versão exata do ESP-IDF identificada (v5.5.4), fonte oficial clonado e correspondência
com o binário CONFIRMADA por desmontagem cruzada; MECANISMO EXATO de como "Cache error"/EXCCAUSE=7
é produzido agora totalmente explicado pelo próprio código-fonte real (não mais inferência); hipótese
de 32.5.11 sobre `panic_soc_check_pseudo_cause` REFUTADA pelo fonte real (é um stub no xtensa); achada
uma lacuna concreta de modelagem neste fork (`DPORT_PRO/APP_INTR_STATUS_0_REG` não existe em lugar
nenhum) que, por si só, já explicaria a rotulagem incorreta independente da causa raiz de fundo
(2026-07-27, pedido explícito do usuário: identificar a versão exata, clonar o repositório oficial,
e SÓ DEPOIS confirmar a correspondência fonte↔binário antes de continuar instrumentando)

**Passo 1 -- identificação da versão exata**: `pio`/PlatformIO NÃO está instalado nesta máquina
(`~/.platformio` existe mas está vazio -- confirmado, nenhum cache de `framework-arduinoespressif32`/
`framework-arduinoespressif32-libs` em lugar nenhum do disco `C:`). A única fonte de verdade
disponível localmente é o próprio `merger.elf`. `strings` nele mostra `v5.5.4` (sem sufixo `-dirty`/
commits extras) duas vezes, e a estrutura real `esp_app_desc_t` (símbolo `esp_app_desc`, endereço
`0x3f400020`, campo `idf_ver`) confirma que essa é a string oficial de versão do ESP-IDF embutida no
binário pelo próprio processo de build -- não uma suposição.

**Passo 2 -- clone e checkout**: `git clone --branch v5.5.4 --depth 1 https://github.com/espressif/esp-idf.git C:\SourceCode\esp-idf`. `git describe --tags` confirma `v5.5.4` exato (tag limpa, commit
`735507283d5b2f9fb363a1901172dbd9e847945d`).

**Passo 3 -- toolchain de desmontagem**: nenhum `xtensa-esp32-elf-objdump` funcional estava disponível
nesta máquina (o `objdump` genérico do MSYS2/UCRT64 lê o ELF via BFD mas não tem o decodificador de
instruções Xtensa embutido -- `can't disassemble for architecture UNKNOWN`; achados de crash dumps
antigos em `%LOCALAPPDATA%\CrashDumps` confirmam tentativas anteriores mal-sucedidas). Instalado via
o próprio instalador oficial do ESP-IDF (`python tools/idf_tools.py install xtensa-esp-elf`, rodado
via PowerShell nativo -- o `idf_tools.py` recusa rodar sob MSYS/MinGW, `ERROR: MSys/Mingw is not
supported`) em `C:\SourceCode\esp-idf-tools` (fora da árvore do repositório, não commitado). Resultado:
`xtensa-esp32-elf-objdump.exe` funcional, confirmado desmontando corretamente `.iram0.vectors` do
`merger.elf` real.

**Passo 4 -- correspondência fonte↔binário, função por função**:
- `esp_cache_err_get_cpuid` (`0x400e2170`): desmontagem bate **EXATAMENTE**, instrução por instrução,
  com `components/esp_system/port/soc/esp32/cache_err_int.c:79-105` da v5.5.4 real -- inclusive os
  endereços literais carregados (`l32r a10, ... => 0x3ff003fc` e `=> 0x3ff00424`) batem exatamente com
  `DPORT_PRO_DCACHE_DBUG3_REG`/`DPORT_APP_DCACHE_DBUG3_REG` (base DPORT `0x3FF00000` + offsets `0x3FC`/
  `0x424`, os MESMOS offsets já usados no modelo deste fork em `include/hw/misc/esp32_dport.h`) e a
  extração de bits (`extui a10, a10, 9, 6`) bate exatamente com a máscara de 6 bits (`OPPOSITE`,
  `DRAM1`, `IROM0`, `IRAM1`, `IRAM0`, `DROM0`, bits 9-14) usada no código-fonte real. Lógica confirmada
  linha a linha: checa o registrador PRO primeiro (retorna `PRO_CPU_NUM`=0 se setado), senão o APP
  (retorna `APP_CPU_NUM`=1 se setado), senão retorna `-1`.
- `panic_soc_check_pseudo_cause` (`0x4016ec54`): desmontagem mostra um STUB TRIVIAL (`movi.n a2, 0;
  memw; retw.n` -- sempre retorna `false`, não lê nenhum registrador). Isso bate EXATAMENTE com
  `components/esp_system/port/arch/xtensa/panic_arch.c:260-264` da v5.5.4 real:
  ```
  bool panic_soc_check_pseudo_cause(void *f, panic_info_t *info)
  {
      // Currently only needed on riscv targets
      return false;
  }
  ```
  **Isso REFUTA diretamente a hipótese registrada em 32.5.10/32.5.11** de que esta função seria
  responsável por "relabelar" a causa para "Cache error" -- no xtensa/ESP32 ela não faz absolutamente
  nada. Foi uma suposição meramente baseada no nome da função e no achado estático de 32.5.4 (que
  citou o SÍMBOLO, não o conteúdo real), exatamente o tipo de erro que a verificação pedida pelo
  usuário existe para prevenir.
- A relabelagem real acontece em `panic_soc_fill_info()` (`components/esp_system/port/arch/xtensa/
  panic_arch.c:266-298`, símbolo `0x400e1e44` já visto desde 32.5.9): `if (frame->exccause ==
  PANIC_RSN_CACHEERR) { info->core = esp_cache_err_get_cpuid(); }` seguido de
  `info->reason = pseudo_reason[frame->exccause]` (tabela estática incluindo `"Cache error"` no
  índice 7). Ou seja: `frame->exccause` (um CAMPO DE SOFTWARE na estrutura de frame salva, DIFERENTE
  do registrador de hardware `EXCCAUSE` lido via `RSR.EXCCAUSE`) já teria que estar em `7` (=
  `PANIC_RSN_CACHEERR`, confirmado em `components/xtensa/include/esp_private/panic_reason.h:10`)
  ANTES desta função rodar -- ela só usa esse valor pra escolher a string e chamar
  `esp_cache_err_get_cpuid()`, não decide o valor em si.

**Passo 5 -- de onde vem `frame->exccause = PANIC_RSN_CACHEERR`, lido diretamente de
`components/esp_system/port/soc/esp32/highint_hdl.S` (o handler de interrupção de alta prioridade
REAL, em assembly, não C)**:
- Este build usa `CONFIG_ESP_SYSTEM_CHECK_INT_LEVEL_5` (confirmado batendo com o achado de 32.5.9/
  32.5.11 de que só o nível 5 aparece nos traces, nunca o nível 4) -- `xt_highintx` é definido como
  `xt_highint5`, o MESMO handler compartilhado documentado no próprio comentário do arquivo: "usado
  para: handler IPC_ISR, handler de panic de erro de cache, handler de panic do interrupt watchdog"
  -- as TRÊS coisas na MESMA interrupção de CPU, distinguidas só por bits lidos em runtime.
- `ETS_T1_WDT_CACHEERR_INUM = 26` (`components/soc/esp32/include/soc/soc.h:225`, bloco
  `CONFIG_ESP_SYSTEM_CHECK_INT_LEVEL_5`) -- **o watchdog TG1 e a interrupção de acesso ilegal ao
  cache (`ETS_CACHE_IA_INTR_SOURCE`, roteada explicitamente para este MESMO número via
  `esp_rom_route_intr_matrix()` em `cache_err_int.c:48`) são deliberadamente roteados para a MESMA
  linha de interrupção de CPU (26) neste build** -- não é um bug de roteamento, é o design real da
  ESP-IDF para este nível de config.
- Ao entrar em `xt_highint5` com o bit 26 setado, o código PRECISA desambiguar entre "foi o WDT" e
  "foi o cache" lendo um SEGUNDO registrador -- a macro `get_int_status_tg1wdt` (linhas 116-138 do
  `.S`) lê `DPORT_PRO_INTR_STATUS_0_REG`/`DPORT_APP_INTR_STATUS_0_REG` (dependendo do núcleo) e
  extrai o bit `ETS_TG1_WDT_LEVEL_INTR_SOURCE` (=20, uma numeração DIFERENTE -- índice de fonte na
  matriz de interrupção, não número de linha de CPU). **Se esse bit vier SETADO -> confirmado WDT
  genuíno (`PANIC_RSN_INTWDT_CPU0/1`). Se vier ZERADO -> a lógica conclui, por ELIMINAÇÃO (sem
  nenhuma verificação adicional), que só pode ter sido o cache -- desabilita a própria interrupção,
  seta `a0 = PANIC_RSN_CACHEERR`, salva em `frame->exccause` e chama `panicHandler` (linhas 239-257
  e 273-285 do `.S`)**. Este é o EXATO ponto onde `EXCCAUSE: 0x00000007` nasce -- não é uma exceção
  de CPU (por isso nunca apareceu em nenhuma das ~145 inicializações rastreadas desde 32.5.9/32.5.10),
  é uma decisão de SOFTWARE em assembly, baseada inteiramente na leitura de UM bit de UM registrador.

**Achado concreto e verificável nesta própria rodada (grep no fork inteiro, não suposição)**:
`DPORT_PRO_INTR_STATUS_0_REG`/`DPORT_APP_INTR_STATUS_0_REG` **não aparece em NENHUM lugar deste fork
QEMU** (`grep -rln "INTR_STATUS_0" --include=*.c --include=*.h .` no repositório inteiro retorna
ZERO arquivos). Isso significa que `esp32_dport_read()` não tem nenhum `case` para esse endereço --
cai no valor padrão (`r = 0`, nunca escrito para este endereço) -- ou seja, **o bit
`ETS_TG1_WDT_LEVEL_INTR_SOURCE` SEMPRE lê como zero neste modelo, não importa o que aconteça de
verdade com o watchdog real**. Combinado com a lógica do `.S` acima, isso significa: **toda vez que a
linha de interrupção de CPU 26 for ativada neste emulador, por QUALQUER motivo -- inclusive um
timeout GENUÍNO e real do watchdog TG1 -- o ESP-IDF vai concluir erroneamente que não foi o watchdog
e vai rotular como "Cache error" incondicionalmente**, porque o registrador que ele usa pra
desambiguar nunca reflete o estado real do hardware. Isso reformula a pergunta original: mesmo que a
causa raiz de fundo seja um watchdog disparando de verdade (por jitter de agendamento sob MTTCG, por
exemplo -- ainda NÃO confirmado), o texto "Cache error" seria produzido de qualquer forma, o que
significa que **esta investigação pode ter perseguido, desde o início, um rótulo que nunca foi
confiável, independente de qual seja a causa real por trás da linha de interrupção 26**.

**O que NÃO foi confirmado ainda (deliberadamente não instrumentado nesta rodada, só leitura de
fonte/desmontagem)**: se a linha de interrupção de CPU 26 é ativada neste emulador por (a) um timeout
genuíno do watchdog TG1 (verificável: o modelo em `hw/timer/esp32_timg.c` claramente implementa um
WDT real com `qemu_irq_raise/pulse(get_..._irq(s, TIMG_WDT_INT))`), (b) a interrupção de acesso
ilegal ao cache genuína (já refutada repetidas vezes desde 32.5.7 -- `esp32_cache_ill_read()` nunca
dispara), ou (c) um roteamento espúrio/incorreto na matriz de interrupção deste fork que ativa a
linha 26 por outro motivo totalmente alheio. Confirmar qual dessas três é a causa raiz de fundo exige
instrumentar o roteamento da matriz de interrupção (`esp32_intmatrix`) e a linha `TIMG_WDT_INT` do
`hw/timer/esp32_timg.c` -- ainda NÃO feito, pendente de escopo/autorização explícita do usuário pra
esta próxima rodada, conforme o padrão já estabelecido nesta investigação.

**Estado ao final desta rodada**: nenhuma modificação de código QEMU nesta rodada -- só leitura de
fonte real (`esp-idf` clonado) e desmontagem (`objdump` real) do binário já existente. Nenhum fix
implementado. `C:\SourceCode\esp-idf` (clone raso, tag `v5.5.4`) e `C:\SourceCode\esp-idf-tools`
(toolchain `xtensa-esp-elf`) são novos artefatos nesta máquina, fora da árvore de nenhum dos dois
repositórios git desta investigação (`LasecSimul`/`qemu_lasecSimul`) -- não afetam nenhum commit
pendente. Nenhum processo órfão. ~35GB livres em disco (verificado antes do clone).

**Próximo passo mínimo e objetivo**: com autorização explícita do usuário, instrumentar (a) o
roteamento real da matriz de interrupção deste fork para a linha de CPU 26 (`esp32_intmatrix` ou
equivalente) e (b) a própria expiração do timer WDT do grupo TG1 (`hw/timer/esp32_timg.c`,
`TIMG_WDT_INT`), correlacionando com os já-confirmados eventos `HIGH_PRIO_INTERRUPT_LEVEL_5` (que
JÁ temos capturados desde 32.5.9/32.5.11, path=`handle_irq`) -- pra determinar definitivamente qual
das três causas (WDT genuíno, cache-IA genuíno, ou roteamento espúrio) ativa a linha 26 nas
reproduções reais do "Cache error". Implementar a modelagem faltante de `DPORT_PRO/APP_INTR_STATUS_0_REG`
é um candidato a fix de COMPATIBILIDADE (faz o ESP-IDF real conseguir se auto-diagnosticar
corretamente), mas NÃO substitui achar a causa raiz de por que a linha 26 é ativada em primeiro lugar
-- os dois são passos distintos e ambos necessários, conforme os critérios de aceitação originais da
tarefa (eliminar a causa na origem, não só implementar semântica de registrador correta).

#### 32.5.13 CONFIRMADO por instrumentação direta + correlação por PID: a linha de CPU 26 é ativada
por uma expiração GENUÍNA do watchdog do TIMER_GROUP1 (fonte 20, não a fonte 68/cache-IA); mecanismo
de tolerância a livelock do ESP32 ECO3 (`CONFIG_ESP32_ECO3_CACHE_LOCK_FIX`) identificado como o
verdadeiro árbitro entre "ciclo passa" e "vira panic" -- refina e corrige a leitura simplificada de
32.5.12 (2026-07-27, rodada autorizada explicitamente: "sim, faça a próxima rodada")

**Escopo desta rodada**: instrumentar (a) o roteamento real da matriz de interrupção (`hw/xtensa/
esp32_intc.c`) pra qualquer fonte mapeada pra linha de CPU 26, (b) a expiração real do WDT do
TIMER_GROUP1 (`hw/timer/esp32_timg.c`), e (c) o registrador `INTSET` bruto no momento de cada
interrupção de alta prioridade já capturada desde 32.5.9 (`target/xtensa/exc_helper.c`) -- pra
determinar, de uma vez, qual das três causas hipotetizadas em 32.5.12 (WDT genuíno, cache-IA genuíno,
ou roteamento espúrio) efetivamente ativa a linha 26 nas reproduções reais do "Cache error".

**Problema de correlação resolvido nesta rodada**: como cada ciclo da bateria sobe um processo QEMU
NOVO (PID diferente) e o harness só imprime "Logs QEMU do ciclo N" pra ciclos que FALHAM, não havia
como saber com certeza qual arquivo de trace por-PID pertencia a qual ciclo. Resolvido adicionando
`pid=%d` (via `getpid()`) a uma linha de log JÁ EXISTENTE e já impressa em TODO reset
(`esp32_log_reset()` em `hw/xtensa/esp32.c`, achado 2026-07-27) -- não uma instrumentação nova, só um
campo a mais numa linha que já aparecia inline no log do harness pra ciclos que falham. Isso permitiu
identificar com certeza, por exemplo, que o ciclo 0 de uma bateria de 45 ciclos (`LASECSIMUL_STRESS_CYCLES=45`) que gerou "Cache error" correspondia ao processo PID 9868.

**Achado direto e definitivo, PID 9868 (ciclo confirmado como falho)**:
- `virt_ns≈3305490700` (~3,3s): `timg_wdt_expire core=1 ... new=0x00000001` -- **expiração GENUÍNA
  do WDT do TIMER_GROUP1** (`core` aqui carrega `s->id`, o ID do grupo de timer, não o núcleo de CPU
  -- 1 = TIMER_GROUP1, o mesmo usado pelo Interrupt Watchdog real da ESP-IDF; `new`=modo=1=
  `WDT_MODE_INT`, confirmado em `include/hw/timer/esp32_timg.h`).
- ~8ms depois (`virt_ns≈3313717000`): `intmatrix_line26 core=0 ... vaddr=0x00000014 new=0x00000001`
  e o mesmo pra `core=1` -- **a linha de CPU 26 é ativada, e a FONTE que a ativa é `vaddr=0x14`=20
  decimal = `ETS_TG1_WDT_LEVEL_INTR_SOURCE` EXATAMENTE, não 68 (`ETS_CACHE_IA_INTR_SOURCE`)**. Isso
  fecha definitivamente a pergunta aberta em 32.5.12: a linha 26 nesta reprodução real é ativada pelo
  watchdog GENUÍNO, não por acesso ilegal ao cache genuíno (já refutado repetidas vezes desde 32.5.7)
  nem por roteamento espúrio de uma terceira fonte inesperada.
- ~3,7ms depois: a linha volta a 0 em ambos os núcleos (`new=0x00000000`) -- consistente com
  `wdt_clr_intr_status TIMERG1` (visto no assembly real, `highint_hdl.S:261`) limpando o status do WDT
  como parte do tratamento.
- Só ~3,1 SEGUNDOS depois (`virt_ns≈6436417500`) é que o primeiro `reset_cpu_sw` de fato acontece --
  gap grande, consistente com o tempo real gasto imprimindo o relatório de panic, tentando (e
  falhando, conforme UART já registrado em baterias anteriores) escrever o core dump na flash, e só
  então reiniciar.

**Achado que refina e CORRIGE a leitura simplificada de 32.5.12**: comparando com os dados de
BASELINE já coletados na mesma rodada (30 ciclos completamente limpos, nenhum "Cache error" --
preservados em `c:/tmp/battery5_clean_baseline/`), **12 dos 30 processos LIMPOS também mostram um
`timg_wdt_expire` com `mode=WDT_MODE_INT` em timestamps `virt_ns` muito parecidos (~3,5-4,7s)** --
ou seja, uma expiração genuína do WDT do TIMER_GROUP1 sozinha NÃO implica panic. Reexaminando
`components/esp_system/port/soc/esp32/highint_hdl.S` com mais cuidado (linhas 202-212, que eu tinha
lido rápido demais em 32.5.12): **antes de montar o frame de exceção e chamar `panicHandler`, o
código verifica um CONTADOR DE LIVELOCK (`_lx_intr_livelock_counter` vs `_lx_intr_livelock_max`) --
se o contador ainda está abaixo do máximo, desvia para `.handle_livelock_int` (linhas 369-540), que
faz sincronização entre os dois núcleos, ALIMENTA o watchdog de novo (`wdt_feed TIMERG1`) e RETORNA
NORMALMENTE, sem nunca montar frame de exceção nem chamar `panicHandler`**. Só quando o contador
atinge o máximo é que o código continua adiante e de fato monta o frame/chama o panic handler (caindo
então na lógica de desambiguação já identificada em 32.5.12, que sempre conclui "não é WDT" por causa
do registrador `DPORT_..._INTR_STATUS_0_REG` não modelado, e rotula como "Cache error"). **Confirmado
que este mecanismo está de fato compilado neste firmware**: `nm` no `merger.elf` mostra
`.handle_livelock_int`, `_lx_intr_livelock_counter`, `_lx_intr_livelock_max`, `_lx_intr_livelock_app`,
`_lx_intr_livelock_pro`, `_lx_intr_livelock_sync` todos presentes -- confirma que
`CONFIG_ESP32_ECO3_CACHE_LOCK_FIX && CONFIG_ESP_INT_WDT` estão habilitados neste build. Este é o
workaround real da Espressif pra uma errata de silício do ESP32 (revisões ECO0-ECO2) relacionada a
livelock de cache-lock entre os dois núcleos -- ele TOLERA um número configurável de expirações
genuínas do WDT antes de declarar falha definitiva.

**Cadeia causal completa agora estabelecida, ponta a ponta, com evidência direta em cada elo**:
1. O WDT do TIMER_GROUP1 expira genuinamente e repetidamente (confirmado em runs limpos E no run que
   falhou) -- candidato mais provável: contenção genuína de cache-lock entre os dois núcleos (a MESMA
   condição que o workaround ECO3 existe pra tolerar) OU um artefato de timing/agendamento específico
   da emulação sob MTTCG que imita o mesmo sintoma -- **NENHUMA das duas ainda confirmada nesta
   rodada**.
2. Cada expiração ativa a linha de CPU 26 (compartilhada com cache-IA neste build) -- confirmado
   pela fonte 20 exatamente, via instrumentação direta desta rodada.
3. O workaround ECO3/livelock absorve um número tolerável dessas expirações silenciosamente
   (alimentando o WDT de novo, sem panic) -- confirmado: 12/30 ciclos limpos mostram exatamente esse
   padrão.
4. Quando o contador de livelock esgota (por acumular expirações rápido demais, ou por já estar
   perto do limite de uma sessão anterior -- AINDA NÃO determinado qual), o código finalmente monta
   o frame de exceção e chama `panicHandler`.
5. A lógica de desambiguação (`get_int_status_tg1wdt`, já detalhada em 32.5.12) lê
   `DPORT_PRO/APP_INTR_STATUS_0_REG` bit 20 -- registrador que este fork NÃO modela em lugar nenhum
   (confirmado por grep no repositório inteiro) -- sempre lê zero, sempre conclui "não é WDT
   confirmado", e rotula como `PANIC_RSN_CACHEERR`=7="Cache error", **mesmo a causa real, ponta a
   ponta, sendo o watchdog do TIMER_GROUP1, não qualquer coisa relacionada a cache**.

**O que isso significa pra investigação inteira**: o texto "Cache error"/EXCCAUSE=7 que motivou TODA
esta investigação, desde a seção 32.5.1, nunca teve relação direta com acesso ilegal ao cache -- é a
saída de um mecanismo de tolerância a erros (o workaround ECO3 de livelock) esgotando sua paciência
com expirações repetidas do Interrupt Watchdog, mal-rotulado por causa de um registrador de
desambiguação que este fork não implementa. As hipóteses das rodadas 1-2 desta investigação (corrida
no handshake `spi_flash_op_block_func`/`esp_ipc_isr`, disable/enable de cache) podem ainda ser
RELEVANTES -- mas não como causa direta de uma trap de cache, e sim como possível fonte da CONTENÇÃO
genuína entre núcleos que faz o watchdog do TIMER_GROUP1 expirar repetidamente o bastante pra esgotar
o contador de livelock. Isso NÃO está confirmado ainda -- é a hipótese mais bem fundamentada até agora
pra investigar a seguir.

**Estado ao final desta rodada**: nenhum fix implementado. Instrumentação nova (não commitada):
`hw/xtensa/esp32_intc.c` (roteamento pra linha 26), `hw/timer/esp32_timg.c` (expiração do WDT),
`target/xtensa/exc_helper.c` (campo `intset`/`line26` no hook de interrupção de alta prioridade),
`hw/xtensa/esp32.c` (campo `pid=` numa linha de log já existente, só pra correlação). `qemu-system-
xtensa.exe` recompilado múltiplas vezes nesta rodada, versão final reimplantada em `run-ucrt64/` e
`devices/qemu-esp32/bin/` (SHA-256:
`D8F375F2C08480575EBC4925E56CC7771A1602F9898F62B96F057D4213CB36B9`, em `BUILD-PROVENANCE.txt`).
Nenhum processo órfão. ~31GB livres em disco (uso subiu um pouco por causa do clone do `esp-idf` e do
toolchain `xtensa-esp-elf` instalados em 32.5.12 -- nenhum dos dois faz parte de nenhum dos dois
repositórios git desta investigação). Baseline de 30 ciclos limpos preservado em
`c:/tmp/battery5_clean_baseline/` pra comparação futura.

**Próximo passo mínimo e objetivo**: determinar se a contenção genuína entre núcleos que faz o WDT do
TIMER_GROUP1 expirar repetidamente é (a) uma condição de cache-lock real, análoga à que o workaround
ECO3 existe pra tolerar, correlacionando com o handshake `spi_flash_op_block_func`/cache disable-
enable já instrumentado desde a rodada 2 (32.5.7/32.5.8), ou (b) um artefato específico de emulação
sob MTTCG (jitter de agendamento entre os dois threads TCG) sem equivalente em hardware real --
instrumentando o valor de `_lx_intr_livelock_counter` em cada entrada de `.handle_livelock_int` e
cruzando com o estado de cache/handshake já rastreado, pra ver se o contador sobe mais rápido durante
sequências de disable/enable de cache do que durante execução normal.

#### 32.5.14 Hipótese do contador de livelock (32.5.13) REFUTADA por instrumentação direta --
`.handle_livelock_int` nunca é executado em nenhum dos 45 processos rastreados; achado NOVO e ainda
NÃO resolvido: entrar em `panicHandler` com a linha 26 confirmada setada NÃO implica sempre em crash +
reboot visível -- há pelo menos um ciclo que PASSOU limpo apesar de ambos os núcleos terem chamado
`esp_cache_err_get_cpuid()` a partir do MESMO ponto de entrada usado pelos ciclos que falham
(2026-07-27, rodada autorizada explicitamente: "pode fazer")

**Escopo desta rodada**: adicionar um terceiro ponto de observação por PC (mesma técnica não-intrusiva
de 32.5.11) em `.handle_livelock_int` (`0x4008214c`, achado via `nm` no `merger.elf`), lendo
diretamente da memória do guest (via `cpu_memory_rw_debug`, não registradores) os valores de
`_lx_intr_livelock_counter` (`0x3ffbdd40`) e `_lx_intr_livelock_max` (`0x3ffbdd44`) -- endereços
específicos deste build -- pra testar a hipótese de 32.5.13 de que o workaround ECO3 tolera um número
de expirações do WDT antes de escalar pra panic.

**Bateria de validação**: 45 ciclos, firmware real, MTTCG. 4 panics "Cache error" (ciclos 3, 9, 20, 39
-- PIDs 4648, 16088, 13940, 2668 respectivamente, identificados com certeza via o campo `pid=` já
adicionado em 32.5.13 a uma linha de log existente).

**Achado 1 -- hipótese do contador de livelock REFUTADA**: `grep -l "handle_livelock_int"` em TODOS os
arquivos de trace desta bateria (45 processos, incluindo os 4 que falharam) retorna ZERO ocorrências.
**`.handle_livelock_int` nunca roda, nem uma vez, em nenhum processo**. Reexaminando
`highint_hdl.S` com a MESMA atenção que já rendeu a correção de 32.5.13: o desvio pra
`.handle_livelock_int` (linha 209, `bltu a0, a5, .handle_livelock_int`) só é alcançado se a PRIMEIRA
chamada de `get_int_status_tg1wdt` (linha 196) retornar `a0 != 0` -- ou seja, exige que
`DPORT_.._INTR_STATUS_0_REG` bit 20 esteja setado. Como esse registrador **nunca é modelado neste
fork** (achado de 32.5.12, confirmado de novo por grep nesta rodada), essa condição NUNCA é
verdadeira -- o código sempre pula direto pro `beqz a0, 1f` (linha 202), NUNCA passando por
`.handle_livelock_int`, em NENHUM cenário, WDT genuíno ou não. **A causa raiz do "12/30 ciclos limpos
com expiração genuína do WDT sem panic" registrada em 32.5.13 continua sem explicação -- não é o
workaround ECO3, que está efetivamente inerte nesta emulação.**

**Achado 2 -- novo e mais intrigante, ainda não resolvido**: cruzando o arquivo `lasecsimul_xtensa_exc_trace.<PID>.log` (o hook de interrupção de alta prioridade, já capturando o campo `line26` desde
32.5.13) com `lasecsimul_xtensa_pcwatch.<PID>.log` pro PID 10356 (ciclo que passou limpo nesta mesma
bateria, confirmado por ter só os 2 resets normais de boot): **o evento `handle_irq` em `cpu=0`
mostra `intset=0x04000040 line26=1` -- confirma que a CPU realmente despachou pra `xt_highint5` com a
linha 26 setada, exatamente como nos ciclos que falharam** -- e, ~1,2ms de tempo virtual depois,
`esp_cache_err_get_cpuid()` é chamado por AMBOS os núcleos (`cpu=0` e `cpu=1`), com o MESMO endereço
de retorno (`0x80081c80` = `panicHandler.c:301`, a checagem de arbitragem entre núcleos por
`busy_wait()`/`esp_cache_err_get_cpuid()==-1` já lida em `panic_handler.c:176-189`) observado em
TODOS os ciclos que falharam. **Apesar disso, o ciclo passou -- nenhum reset adicional, GPIO/UART
normais pelo resto dos 5 segundos do teste.**

**Por que isso não fecha ainda**: pela leitura de `panic_handler.c:166-199` (já lido integralmente em
32.5.13), com `esp_cache_err_get_cpuid()==-1` (sempre verdadeiro neste fork), só o núcleo com
`core_id != 0` deveria cair em `busy_wait()` (loop infinito) -- o núcleo com `core_id == 0` deveria
prosseguir incondicionalmente até `panic_restart()` (`__attribute__((noreturn))`, nunca retorna) via
`frame_to_panic_info()`/`esp_panic_handler()`. Isso implicaria que TODO ciclo que chega neste ponto
deveria terminar em reset -- o que contradiz diretamente o PID 10356 (passou limpo). A comparação com
os PIDs que falharam mostra uma diferença observável: os que falharam têm chamadas ADICIONAIS de
`esp_cache_err_get_cpuid()` resolvendo pra `panic_handler.c:266` (dentro de `frame_to_panic_info`) e
`panic.c:423` (`esp_panic_handler`) -- indicando progressão real até o relatório de panic -- enquanto
o PID 10356 nunca mostra essas chamadas mais profundas. Mas essa mesma comparação NÃO é consistente
entre os 4 PIDs que falharam nesta bateria: 2 deles (16088, 2668) mostram essa progressão completa (5
eventos), mas os OUTROS 2 (4648, 13940) mostram só os 2 eventos iniciais -- o MESMO padrão do ciclo que
passou! Isso sugere fortemente que a diferença de contagem de eventos (2 vs 5) é dominada por um
artefato da PRÓPRIA instrumentação (o throttle de despejo de 200ms do `[XTENSA-PC-WATCH]`, compartilhado
entre os wp_ids, mais provavelmente capturando ou não uma REENTRADA de uma segunda inicialização
pós-reset) e NÃO reflete de forma confiável "quão longe" a execução avançou dentro de uma única
tentativa de panic -- ou seja, **os dados atuais não são suficientes pra confirmar ou refutar a
hipótese do `busy_wait()`/arbitragem entre núcleos; exigem uma leitura mais cuidadosa de
`panic_handler.c` (a lógica completa de `busy_wait()`/`esp_cpu_stall()`/`panic_restart()`) e,
possivelmente, uma instrumentação NOVA e mais precisa (ex.: observar por PC a entrada em
`panic_restart()`/`esp_restart_noos()` diretamente, em vez de inferir progressão pela presença/ausência
de chamadas a `esp_cache_err_get_cpuid()`), não mais instrumentação QEMU-side genérica.**

**Estado ao final desta rodada**: nenhum fix implementado. Instrumentação nova (não commitada):
`target/xtensa/exc_helper.c` (terceiro `wp_id`, campos `livelock_counter`/`livelock_max`),
`target/xtensa/translate.c` (endereço `.handle_livelock_int`). `qemu-system-xtensa.exe` recompilado e
reimplantado em `run-ucrt64/` e `devices/qemu-esp32/bin/` (SHA-256:
`75422BD59C88396C3CC54C4A29FF16285A32B91B2CECB919FFD5D45B31A010C3`, em `BUILD-PROVENANCE.txt`).
Nenhum processo órfão. ~32GB livres em disco.

**Próximo passo mínimo e objetivo**: ler `panic_handler.c` com foco específico em `esp_cpu_stall()`
(o stall de HARDWARE, não `busy_wait()` por software, que congela de vez o núcleo "perdedor" ANTES de
`frame_to_panic_info`/`panic_restart()`) e em `panic_restart()`/`esp_restart_noos()` -- determinar
exatamente qual condição permite que um núcleo chegue a `esp_cache_err_get_cpuid()` (via a checagem de
arbitragem) SEM terminar em `panic_restart()`. Só depois disso soubermos precisar se faz sentido
instrumentar por PC a entrada em `panic_restart()` diretamente, o observador mais direto e inequívoco
de "este ciclo realmente vai reiniciar" -- eliminando a ambiguidade do throttle de despejo que
atrapalhou a leitura desta rodada.

#### 32.5.15 RESOLVIDO: o "ciclo que passa apesar dos mesmos sintomas iniciais" (enigma de 32.5.14) NÃO
é uma falha do firmware nem uma corrida real -- é o HARNESS DE TESTE matando o processo QEMU no meio
da própria impressão do relatório de panic, ANTES de `panic_restart()` sequer ser alcançado; o motivo
raiz completo agora está identificado ponta a ponta, incluindo por que o orçamento de tempo do teste
é insuficiente quando o panic acontece tarde na janela do ciclo (2026-07-27, rodada autorizada
explicitamente: "então continue")

**Escopo desta rodada**: 1) ler `esp_hw_support/cpu.c`/`hal/esp32/cpu_utility_ll.h` pra entender
`esp_cpu_stall()` (achado: usa `RTC_CNTL_OPTIONS0_REG`/`RTC_CNTL_SW_CPU_STALL_REG` com o valor mágico
`0x86` partido em dois campos -- MECANISMO DIFERENTE do `DPORT_APPCPU_RUNSTALL`/`esp_ipc_isr`
rastreado desde a rodada 2; confirmado que este fork JÁ modela isso corretamente em
`hw/misc/esp32_rtc_cntl.c:148-163`, nada de errado encontrado aqui). 2) Achar e instrumentar
`panic_restart` (`0x400e1b40`, via `nm`) como um quarto ponto de observação por PC -- o sinal mais
direto e inequívoco de "este núcleo está comprometido a reiniciar" (função `noreturn`, só chama
`esp_restart_noos[_dig]()` em seguida).

**Bug crítico na PRÓPRIA instrumentação encontrado e corrigido nesta rodada**: confirmado por leitura
direta de `core/src/mcu/qemu/QemuProcessManager.cpp:153,182` que o harness encerra o processo QEMU
entre ciclos com `TerminateProcess()` -- um kill DURO que nunca roda `atexit()`/destrutores/qualquer
cleanup do processo. O despejo throttled (200ms de tempo de parede real) do `[XTENSA-PC-WATCH]` corria
o risco real de nunca refletir os ÚLTIMOS eventos antes desse kill -- exatamente a janela mais crítica
pra esta pergunta. Como os 4 watchpoints atuais empiricamente disparam no máximo ~5 vezes em todo o
boot (não a "torrente" de eventos por milissegundo que justificou o throttle no ring de
`[XTENSA-EXC-TRACE]`/`[CACHE-TRACE]` em rodadas anteriores), o throttle aqui não tinha a mesma
justificativa de performance -- **removido**: despejo incondicional a cada evento.

**Achado definitivo, PID 15116 (ciclo 0 de uma bateria de 45, confirmadamente falho)**: mesmo com o
despejo incondicional corrigido, `panic_restart` **continua nunca aparecendo em NENHUM dos 45
processos desta bateria** (nem no único que falhou). Cruzando com o UART bruto capturado pelo próprio
harness pra este ciclo: **o log da bateria corta literalmente NO MEIO da impressão do dump de
registradores do Core 1** (`LCOUNT  : 0x000` -- truncado, deveria ser `0x00000000`) -- ou seja, **o
processo QEMU foi encerrado (`TerminateProcess`) enquanto o firmware ainda estava imprimindo o
relatório de panic pela UART, MUITO antes de qualquer chance de chegar em `panic_restart()`**. Isso
não é ambiguidade de instrumentação -- é uma prova direta e definitiva: o firmware nunca teve a
CHANCE de terminar sua própria sequência de recuperação neste ciclo específico.

**Por que o orçamento de tempo se esgota -- reconciliando com o achado da rodada 2026-07-27 anterior
(32.5.13, PID 9868)**: o teste usa `LASECSIMUL_STRESS_RUN_MS` (padrão 5000ms com firmware real) +
`LASECSIMUL_STRESS_GPIO_GRACE_MS` (padrão 3000ms) como orçamento efetivo de ~8 segundos de tempo
virtual por ciclo (`core/test/core/mcu/SessionRestartStressTest.cpp:183-188`). Em PID 9868 (32.5.13),
o WDT expirou cedo (`virt_ns≈3,3s`) e o reset genuíno aconteceu em `virt_ns≈6,44s` -- uma sequência de
recuperação real levando **~3,1 segundos**, com folga de sobra dentro do orçamento de ~8s. Em PID
15116 (esta rodada), os sintomas do panic começam tarde (`virt_ns≈5,37s` -- já perto do próprio
`RUN_MS`) e o kill acontece em `schedulerNow≈7,99s` -- só **~2,6 segundos de folga**, insuficiente pra
completar a MESMA sequência de ~3,1s observada no caso que teve tempo de sobra. **A diferença entre
"ciclo passa" e "ciclo falha (GPIO13 TRAVOU)" não é determinística pela natureza do bug -- é uma
corrida entre QUANDO na janela do ciclo o WDT do TIMER_GROUP1 decide expirar (evento com timing
inerentemente variável) e QUANTO tempo resta no orçamento do teste pra completar o relatório de panic
+ tentativa de core dump (que falha rápido) + reboot.**

**Reconciliação com o enigma de 32.5.14**: o ciclo que "passou limpo apesar dos mesmos sintomas
iniciais" (PID 10356, rodada anterior) não passou por acaso ou por algum caminho de recuperação
oculto no código -- ele simplesmente teve os mesmos sintomas iniciais (ambos os núcleos chamando
`esp_cache_err_get_cpuid()`) mas ou (a) o panic aconteceu cedo o bastante na janela pra a sequência
completa (incluindo o reboot real) terminar dentro dos ~8s E o teste ainda considerar o ciclo "OK" no
critério de GPIO/UART final (compatível com o achado de PID 2416 em 32.5.14, que mostrou 7 resets mas
não foi sinalizado como "GPIO13 TRAVOU"), ou (b) o processo foi encerrado no fim natural do ciclo
antes de qualquer sintoma visível se materializar em falha de GPIO. Ambos os cenários são consistentes
com "não há bug de deadlock/corrida real no firmware" -- é inteiramente uma questão de orçamento de
tempo do harness vs. timing variável do WDT.

**Implicação pra investigação inteira**: em NENHUM momento, em nenhuma das ~200+ inicializações
rastreadas nesta investigação inteira (todas as baterias desde 32.5.9), foi encontrada qualquer
evidência de deadlock, corrida trava-tudo, ou estado permanentemente inconsistente. A cadeia causal
completa (`TIMER_GROUP1` WDT expira genuinamente → linha de CPU 26 compartilhada ativa → desambiguação
sempre erra por registrador não modelado → rotula "Cache error" → relatório de panic (LENTO por
imprimir 2 dumps de registrador + backtrace pela UART a 115200 baud + tentativa de core dump que
falha) → reboot real) é inteiramente LINEAR e LIMITADA (bounded), nunca um loop infinito genuíno --
só às vezes mais lenta do que o orçamento de tempo do teste tolera.

**Estado ao final desta rodada**: nenhum fix de causa raiz implementado ainda. Corrigido nesta rodada
(instrumentação, não fix de produção): remoção do throttle de despejo do `[XTENSA-PC-WATCH]` (achado
crítico de metodologia, evita conclusões erradas por amostragem truncada em rodadas futuras).
Instrumentação nova: `target/xtensa/exc_helper.c` (quarto `wp_id`, `panic_restart`, despejo
incondicional). `qemu-system-xtensa.exe` recompilado e reimplantado em `run-ucrt64/` e
`devices/qemu-esp32/bin/` (SHA-256:
`96BFDDF4CA3725D928923211DE5EC0B17B7888E8F47B8AC039D6661711332C90`, em `BUILD-PROVENANCE.txt`).
Nenhum processo órfão. ~32GB livres em disco.

**Próximo passo mínimo e objetivo -- agora dividido em DUAS frentes distintas e independentes,
conforme os critérios de aceitação originais da tarefa**:
1. **Causa raiz de fundo** (por que o WDT do TIMER_GROUP1 expira genuinamente, repetidamente): ainda
   não determinado se é contenção real de cache-lock entre núcleos (a mesma condição que o workaround
   ECO3 existiria pra tolerar, se estivesse funcional) ou um artefato de timing/agendamento específico
   do MTTCG. Candidato a próxima instrumentação: o handshake `spi_flash_op_block_func`/cache
   disable-enable já rastreado desde a rodada 2 (32.5.7/32.5.8), correlacionando com os momentos exatos
   em que o WDT expira.
2. **Compatibilidade/semântica de registrador** (por que a desambiguação sempre erra): implementar
   `DPORT_PRO/APP_INTR_STATUS_0_REG` -- bit 20 refletindo o estado real do TG1WDT -- permitiria ao
   ESP-IDF real se autodiagnosticar corretamente (rotular como Interrupt Watchdog, não Cache error).
   Esta é uma correção de COMPATIBILIDADE, não de causa raiz -- não elimina a expiração genuína do WDT,
   só corrige o rótulo exibido.
3. **Harness de teste** (fora do escopo do fork QEMU): considerar se `LASECSIMUL_STRESS_GPIO_GRACE_MS`
   (padrão 3000ms) precisa ser maior pra acomodar o pior caso observado (~3,1s de recuperação real) com
   margem de segurança, IMPORTANTE: isso NÃO deve ser feito como atalho pra "esconder" o problema
   (violaria a proibição explícita da tarefa original contra "aumentar timeouts pra mascarar
   travamentos") -- só é apropriado APÓS confirmar (via 1 e 2 acima) que não há de fato nenhum
   deadlock/corrida real, e que o tempo observado é inteiramente explicado pela sequência linear já
   mapeada nesta seção.

#### 32.5.16 As três frentes atacadas em paralelo (pedido explícito do usuário: "já pode fazer as três
etapas"): fix de COMPATIBILIDADE implementado e VALIDADO por teste direto (o ESP-IDF real agora rotula
corretamente "Interrupt wdt timeout" em vez de "Cache error"); causa raiz de fundo (por que o TIMER_
GROUP1 expira) permanece ABERTA -- uma hipótese promissora (spin-wait genuíno no driver real do ADC)
foi levantada E REFUTADA por verificação direta antes de ser aceita; harness de teste NÃO alterado
ainda, só recomendação registrada (2026-07-27)

**Frente 1 -- causa raiz de fundo (WDT genuíno)**: cruzando `write_pro/app_cache_ctrl` (handshake de
cache já rastreado desde a rodada 2) com `timg_wdt_expire` no PID 15116 (falho, já usado em 32.5.15):
encontrada uma rajada de ~730 toggles de disable/enable de cache em ~159ms de tempo virtual (tudo por
`writer_core=0`/PRO_CPU, endereços dentro de `spi_flash_op_block_func`/`cache_hal_suspend`/`resume`),
terminando em `virt_ns≈3,9s`. **O `timg_wdt_expire` só acontece ~1,47s DEPOIS que essa rajada termina**
-- não durante ela -- com uma janela de ~1,3s completamente silenciosa no meio (nenhum registro
rastreado por este fork, de nenhum tipo, muda de estado). Verificado que os PCs de AMBOS os núcleos
mudam de valor nos poucos eventos que cercam essa janela (não ficam congelados no mesmo endereço) --
evidência CONTRA um spinlock/deadlock genuíno, a favor de execução normal (só não tocando em nada que
este fork rastreia).

**Hipótese promissora levantada E CORRETAMENTE REFUTADA antes de ser aceita** (disciplina já
estabelecida nesta investigação desde 32.5.8): o PC do núcleo que efetivamente sofre o timeout
(`0x40121dbf`), resolvido via `addr2line` contra a v5.5.4 real, cai em
`hal/esp32/include/hal/adc_ll.h:437`, DENTRO de `adc_oneshot_ll_start()` -- a MESMA função citada
explicitamente na tarefa original (Seção 4, o caminho do ADC). Essa função tem, no código-fonte REAL,
um spin-wait genuíno e incondicional: `while (HAL_FORCE_READ_U32_REG_FIELD(SENS.sar_slave_addr1,
meas_status) != 0) {}` (linha 435) -- um candidato PERFEITO pra causa raiz SE este fork não limpasse
o bit `meas_status` corretamente. **Verificado diretamente em `hw/misc/esp32_sens.c`**: o registrador
real correspondente (`SENS_SAR_SLAVE_ADDR1_REG`, offset `0x3C` confirmado contra
`components/soc/esp32/register/soc/sens_reg.h` da v5.5.4 real) **não é modelado em lugar nenhum
neste arquivo** -- cai no `return r` padrão (`r=0`), ou seja, **`meas_status` sempre lê 0, fazendo o
`while` sair IMEDIATAMENTE, nunca travar**. E MAIS: reexaminando a linha exata que `addr2line` resolveu
(`adc_ll.h:437`), essa é a linha `SENS.sar_meas_start1.meas1_start_sar = 1` -- uma ESCRITA simples, não
o próprio `while` da linha 435 -- ou seja, o PC capturado é só o INSTANTÂNEO ponto de execução no
momento exato do evento de watchdog, não evidência de um loop travado ali. **Esta hipótese está
REFUTADA -- exatamente o tipo de conclusão prematura que a disciplina desta investigação (e o pedido
explícito do usuário em rodadas anteriores) existe pra prevenir.** A causa raiz de fundo continua
ABERTA: a janela silenciosa de ~1,3s não tem explicação confirmada ainda -- exigiria amostragem
CONTÍNUA do PC de ambos os núcleos durante a janela (não só um único instantâneo no momento do
timeout), uma técnica de instrumentação ainda não construída nesta investigação.

**Frente 2 -- fix de compatibilidade, IMPLEMENTADO E VALIDADO**: `DPORT_PRO_INTR_STATUS_0_REG`/
`DPORT_APP_INTR_STATUS_0_REG` (offsets reais `0xEC`/`0xF8`, confirmados contra
`components/soc/esp32/register/soc/dport_reg.h` da v5.5.4 real) implementados em
`hw/misc/esp32_dport.c`, expondo o estado bruto real da matriz de interrupção
(`esp32_intmatrix_get_raw_status_bits()`, nova função exportada de `hw/xtensa/esp32_intc.c`, ligada via
um ponteiro opaco `Esp32DportState::intmatrix_opaque` setado em `hw/xtensa/esp32.c` logo após os dois
dispositivos-irmãos serem inicializados -- `hw/misc/esp32_dport.c` é código "common" e não pode incluir
`esp32_intc.h` por causa de `target/xtensa/cpu.h`, mesma restrição já documentada desde 32.5.9).
**Validado por teste direto**: bateria de 45 ciclos reproduziu 2 panics reais que agora imprimem
`"Guru Meditation Error: Core  1 panic'ed (Interrupt wdt timeout on CPU1)."` -- rótulo CORRETO,
substituindo o antigo "Cache error" incondicional -- e o dump de registrador mostra corretamente só o
núcleo 1 (o que realmente disparou o watchdog), não mais os dois núcleos indiscriminadamente (compor-
tamento também corrigido, já que a lógica de arbitragem `busy_wait()` em `panic_handler.c:172-174`
agora reconhece corretamente `PANIC_RSN_INTWDT_CPU1` em vez de cair no caso `-1`/"não sei quem foi").
Nenhuma modificação de comportamento fora deste registrador especificamente -- `esp_cache_err_get_
cpuid()` e a checagem de acesso ilegal ao cache continuam intocados e continuam corretamente nunca
disparando (achado desde 32.5.7, ainda válido).

**Frente 3 -- harness de teste**: NÃO alterado nesta rodada. A causa raiz de fundo (Frente 1) ainda não
está fechada -- a condição explícita do usuário pra mexer em `GPIO_GRACE_MS` ("só APÓS confirmar que
não há deadlock/corrida real") ainda não foi plenamente satisfeita, apesar da evidência já reunida
(PCs avançando normalmente, nenhum padrão de deadlock em nenhuma das ~250+ inicializações rastreadas
nesta investigação inteira) apontar consistentemente pra "não há deadlock". Registrada como
recomendação, não como mudança de código -- decisão do usuário se quer prosseguir com ela antes ou
independente de fechar a Frente 1.

**Estado ao final desta rodada**: `hw/misc/esp32_dport.c`, `include/hw/misc/esp32_dport.h`,
`hw/xtensa/esp32_intc.c`, `hw/xtensa/esp32.c` ganharam o fix de compatibilidade (ainda não commitado --
aguardando a organização final em commits separados por critério de aceitação). `qemu-system-xtensa.exe`
recompilado e reimplantado em `run-ucrt64/` e `devices/qemu-esp32/bin/` (SHA-256:
`7F1E031D6298B2167F9EBA3379E30364270B3AC91A616E14DA6396C17F414E55`, em `BUILD-PROVENANCE.txt`). Dois
crashes do bug pré-existente e não relacionado `fifo8_pop` (já documentado desde 32.5.8) interromperam
duas baterias nesta rodada -- ambas vezes sem travar a tela (a supressão de diálogo do CRT já commitada
funcionou) e sem processo órfão remanescente (confirmado). ~32GB livres em disco.

**Próximo passo mínimo e objetivo**: construir uma amostragem CONTÍNUA (não um instantâneo único) do
PC de ambos os núcleos durante a janela silenciosa de ~1,3s que precede toda expiração do WDT --
candidatos: um temporizador QEMU periódico (não ligado a nenhum evento do guest) que registra `env->pc`
de cada CPU a cada N microssegundos de tempo real, ativado só quando dentro dessa janela (após o
handshake de cache se acalmar, antes do próximo evento rastreado) -- pra determinar de vez se é um
spin-wait genuíno em algum registro NÃO instrumentado ainda (SENS/ADC teve uma pista forte mas
refutada; outros candidatos: I2C, UART, ou o próprio mecanismo de tick do FreeRTOS) ou execução normal
simplesmente lenta sob esta emulação.

#### 32.5.17 Amostrador contínuo de PC implementado; achado NOVO e decisivo -- não é um spin-wait em
nenhum periférico: quase toda expiração do WDT é precedida por um SALTO ÚNICO e ANÔMALO de ~0,7 a
~1,1 SEGUNDOS no próprio tempo virtual, aparentemente uma pausa no mecanismo de temporização/pacing
deste fork, não uma condição do firmware; hipóteses de "erase de flash realista" e "ADC" refutadas
por verificação direta (2026-07-27, "de continuidade")

**Escopo desta rodada**: implementar um observador NÃO-ligado-a-eventos-do-guest -- um timer QEMU
periódico (`QEMU_CLOCK_VIRTUAL`, a cada 2ms de tempo virtual nominal) que amostra continuamente
`env->pc` dos dois núcleos, independente de qualquer escrita/leitura/exceção -- pra resolver a
limitação de 32.5.16 (um único instantâneo de PC no momento do evento não distingue núcleo
genuinamente parado de núcleo só passando por ali).

**Implementação**: `hw/xtensa/esp32.c` ganhou `Esp32SocState::pc_sampler_timer` (novo campo,
`timer_new_ns`/`timer_mod` armado logo após os dois núcleos existirem, em `esp32_soc_realize()`), um
ring de 8192 amostras (~16s de histórico a 2ms/amostra), e `esp32_pc_sampler_capture_window()` --
despejo incondicional (sem throttle, lição já aprendida em 32.5.15) das últimas ~2048 amostras (~4s),
declarada em `include/hw/misc/esp32_dport.h` (mesmo padrão de ponte "common"↔"target-specific" já
usado pra `esp32_intmatrix_get_raw_status_bits()`) e chamada de `hw/timer/esp32_timg.c` no exato
momento em que o WDT do TIMER_GROUP1 expira. Teste de fumaça (3 e 1 ciclos) confirmou o timer disparando sem custo de performance perceptível antes de rodar a bateria completa.

**Bateria de validação**: 45 ciclos, firmware real, MTTCG (mesmo binário com o fix de 32.5.16 já
aplicado). 2 panics "Interrupt wdt timeout on CPU1" (rótulo correto, confirma que o fix de
compatibilidade continua funcionando) -- mas **18 dos 45 processos mostraram uma expiração do WDT do
TIMER_GROUP1 capturada pelo amostrador**, muito mais que os 2 que de fato viraram panic visível --
consistente com o achado já registrado (32.5.13/32.5.16) de que uma expiração isolada nem sempre
escala.

**Achado 1 -- núcleo PRO idle é normal, não é a causa**: em vários arquivos, `pc0` (núcleo PRO) fica
está CONGELADO no mesmo endereço (`0x40089d06`) por dezenas de amostras consecutivas antes da
expiração. Resolvido via `addr2line`: **`esp_cpu_wait_for_intr` (`esp_hw_support/cpu.c:64`) -- a
própria função de "esperar por interrupção" (`waiti`) usada pela tarefa idle do FreeRTOS**. Isso é
comportamento NORMAL e ESPERADO (o núcleo PRO simplesmente não tinha nada pra fazer), não evidência de
travamento -- e, de qualquer forma, o watchdog que expira é do núcleo APP (CPU1), não do PRO.

**Achado 2 -- núcleo APP (o que realmente aciona o watchdog) também NÃO mostra spin-wait**: `pc1`
mostra DIVERSOS endereços diferentes ao longo da mesma janela (não um único endereço repetido) --
inclusive alternando entre `esp_cpu_wait_for_intr` (idle) e breves execuções em outros endereços
(padrão típico de "acorda no tick, faz um pouco de trabalho do escalonador, volta a dormir" --
comportamento normal de RTOS ocioso). **Nenhum dos dois núcleos mostra assinatura de spin-wait
genuíno em nenhum registrador rastreado.**

**Achado 3 -- o achado decisivo desta rodada**: comparando o penúltimo e o último timestamp
`virt_ns` de CADA uma das 18 capturas (a amostra imediatamente anterior ao disparo do WDT):
**16 das 18 mostram um salto de tempo VIRTUAL, num ÚNICO tick do amostrador, entre ~0,71s e ~1,09s** --
agrupando-se em duas faixas bem definidas (~5 arquivos em ~0,72-0,75s, ~10 arquivos em ~1,05-1,09s).
Isso não é jitter aleatório do próprio amostrador (que nos outros ~800 ticks de cada arquivo mostra
intervalos de poucos milissegundos, consistentes com o nominal de 2ms) -- é um evento sistemático e
localizado, que acontece EXATAMENTE no ponto onde o WDT está prestes a expirar.

**Hipóteses concorrentes verificadas e refutadas antes de aceitar esta explicação** (mesma disciplina
desde 32.5.8/32.5.16):
- *Latência realista de erase de flash*: `hw/block/m25p80.c` (o modelo de flash SPI real usado por
  este fork, upstream do QEMU, não específico deste fork) não tem NENHUMA simulação de atraso de
  tempo pra operações de erase/write -- comandos SPI completam instantaneamente em tempo virtual.
  **Refutada** -- não é uma latência de hardware deliberadamente simulada.
- *Mecanismo de sincronização Core↔QEMU (`softmmu/simuliface.c`)*: inspecionado (só leitura, NENHUMA
  modificação) em busca de sleep/wait/polling bloqueante óbvio -- nenhum encontrado neste arquivo
  específico. Não é uma refutação definitiva (o mecanismo de pacing pode estar em outro lugar, ex.:
  no lado Core/Scheduler, ou em comportamento de agendamento de threads do host sob MTTCG) -- fica
  como candidato NÃO eliminado.

**Por que isso é significativo**: um salto de tempo VIRTUAL dessa magnitude, sem nenhuma atividade de
CPU ou dispositivo correspondente (achados 1 e 2), é mais consistente com uma PAUSA no próprio
mecanismo de avanço de tempo/temporização deste fork (thread do host não escalonada a tempo sob MTTCG,
ou uma característica do pacing "mttcg-realtime" personalizado) do que com qualquer condição do
firmware (contenção de cache-lock, ADC, ou qualquer periférico específico) -- isso aponta diretamente
pro ÚNICO mecanismo que a tarefa original pediu explicitamente pra só mexer com evidência direta de
envolvimento: **a sincronização Core↔QEMU**. Esta rodada reúne exatamente essa evidência, mas NÃO
implementa nenhuma mudança nesse mecanismo -- por prudência (o próprio pedido original), isso fica
para uma futura rodada explicitamente autorizada, com escopo restrito a essa investigação específica.

**Estado ao final desta rodada**: nenhum fix implementado pra esta causa raiz especificamente (o fix
de compatibilidade de 32.5.16 permanece validado e funcionando). Instrumentação nova (não commitada):
`include/hw/xtensa/esp32.h` (campo `pc_sampler_timer`, include de `qemu/timer.h`),
`hw/xtensa/esp32.c` (todo o bloco `[XTENSA-PC-SAMPLER]`), `include/hw/misc/esp32_dport.h`
(declaração de `esp32_pc_sampler_capture_window()`), `hw/timer/esp32_timg.c` (chamada no momento da
expiração do WDT do TIMER_GROUP1). `qemu-system-xtensa.exe` recompilado e reimplantado em
`run-ucrt64/` e `devices/qemu-esp32/bin/` (SHA-256:
`D2F282AEB7C9F69F219B51DFBEED216C41E1A2C18E6E9CDDFCF0331A72CB5BB3`, em `BUILD-PROVENANCE.txt`).
Nenhum processo órfão. ~32GB livres em disco.

**Próximo passo mínimo e objetivo**: com autorização explícita do usuário (dado o achado apontar pra
essa área especificamente protegida na tarefa original), investigar o mecanismo de pacing/agendamento
que avança `QEMU_CLOCK_VIRTUAL` sob `mttcg-realtime` -- candidatos a examinar: o lado Core/Scheduler
(fora deste repositório QEMU, em `core/src/simulation/`), e o próprio laço principal deste fork que
decide QUANTO tempo real deixar passar antes de permitir o próximo avanço de tempo virtual --
determinando se os saltos de ~0,7-1,1s são causados por (a) o host não escalonando as threads TCG a
tempo (recurso finito de CPU do host, fora do controle deste fork), (b) um bug genuíno de pacing
neste fork que PERMITE tempo virtual saltar sem correlação com trabalho real feito, ou (c) alguma
combinação -- e só depois disso decidir se e como corrigir, preservando explicitamente MTTCG,
desempenho, e a sincronização Core↔QEMU como pedido.

#### 32.5.18 Investigação do lado Core (`core/src/simulation/Scheduler.cpp`, fora do repositório QEMU)
autorizada explicitamente ("pode fazer tudo"); mecanismo de pacing por `realTimeRate` CONFIRMADO
inativo neste cenário; achado quantitativo direto -- uma única chamada de `settleUntilStableLocked()`
pode levar de 100 a 700ms, mesma ordem de grandeza dos saltos vistos do lado QEMU -- mas AINDA NÃO
correlacionado de forma direta e inequívoca com o ciclo específico que efetivamente falhou
(2026-07-27, "pode fazer tudo")

**Escopo desta rodada**: ler `softmmu/simuliface.c` (a ponte Core↔QEMU) por inteiro e
`core/src/simulation/Scheduler.cpp`/`.hpp` (fora do fork QEMU, mecanismo de pacing/agendamento do
lado Core) em busca do que poderia causar um salto de ~0,7-1,1s no avanço do tempo virtual.

**Achado 1 -- mecanismo de pacing por tempo real (`m_realTimeRate`/`m_pacingQuantumNs`) está INATIVO
neste cenário**: `simuliface.c` não implementa nenhum throttle próprio -- `QEMU_CLOCK_VIRTUAL` sob
`mttcg-realtime` (sem `-icount`) é essencialmente o relógio monotônico do HOST, sem nenhuma
manipulação. O Scheduler do Core TEM um mecanismo de pacing por tempo real (`m_realTimeRate`,
`Scheduler.cpp:306-354`) que DELIBERADAMENTE espera (`m_pacingWake.wait_until`) quando a simulação
está adiantada em relação ao tempo real -- mas **`grep` confirma que `setRealTimeRate()` nunca é
chamado em nenhum lugar do `McuComponent`/harness de teste usado nesta investigação** -- o campo
fica no seu valor padrão (`0.0`), o que ativa o ramo simples de "só re-ancora a origem" (linha 355),
não o ramo de espera. **Este mecanismo de pacing deliberado está descartado como causa nesta bateria
específica.**

**Achado 2 -- `settleUntilStableLocked()` pode legitimamente demorar MUITO mais que o normal, segurando
`m_mutex` o tempo todo**: o laço é limitado por `m_maxNonLinearIterations` (default do campo é 0/sem
limite no `Scheduler`, mas `SimulationSession.cpp:186` sempre configura a partir de
`settings.maximumNewtonIterations`, cujo default real é 20 -- `Transient.hpp:24`) -- ou seja, NÃO é
literalmente ilimitado neste uso, mas 20 iterações de um circuito complexo o bastante ainda podem,
juntas, consumir um tempo real substancial. Adicionada uma métrica NOVA e mínima
(`Scheduler::MetricsSnapshot::maxSettleNanoseconds`, `Scheduler.hpp`/`.cpp`) que rastreia a duração da
MAIOR chamada individual (não só a soma acumulada, que já existia) -- e um print de diagnóstico
temporário em `SessionRestartStressTest.cpp` (habilita profiling e imprime as métricas ao final de
CADA ciclo, passe ou falhe).

**Dados de duas baterias de 45 ciclos** (firmware real, MTTCG):
- Bateria 1 (interrompida em 5 ciclos pelo já conhecido `fifo8_pop`, não relacionado): ciclo 0 (que
  PASSOU, GPIO13 normal) mostra `maxSettleNanoseconds=699989700` (**699,99ms** -- exatamente a ordem
  de grandeza de um dos dois agrupamentos de saltos já vistos do lado QEMU, ~0,72s, em 32.5.17!)
  contra ~1,5-2,8ms em todos os outros ciclos desta mesma bateria (diferença de ~250-450x).
- Bateria 2 (completou 42 ciclos antes do mesmo `fifo8_pop`): maior valor foi `118586500` (**118,6ms**,
  ciclo 0 de novo, também um ciclo que PASSOU) -- ainda uma ordem de grandeza acima do baseline normal
  (~2-4ms), mas menor que a bateria 1. **O único ciclo que de fato falhou nesta bateria (ciclo 13,
  "GPIO13 TRAVOU") mostra `maxSettleNanoseconds=1641100` (1,64ms) -- SEM NADA de anômalo.**

**Conclusão honesta desta rodada**: o mecanismo (uma única chamada de settle segurando `m_mutex` por
100-700ms, uma ordem de grandeza real e mensurável, coincidindo em magnitude com os saltos de tempo
virtual já vistos do lado QEMU) está CONFIRMADO como um evento real que acontece nesta aplicação --
mas **NÃO foi correlacionado de forma direta e inequívoca com o ciclo específico que efetivamente
falhou nesta rodada** (o ciclo que falhou não mostrou nenhuma anomalia de settle; os ciclos com settle
anômalo, nas duas baterias coletadas, foram ciclos que PASSARAM). Isso é consistente com o quadro já
estabelecido (32.5.13/32.5.15/32.5.16): nem todo evento candidato causa panic (depende de quando na
janela do ciclo ele acontece), e a amostra é pequena (2 baterias, cortadas cedo pelo `fifo8_pop`) --
não é evidência suficiente pra afirmar que "settle longo" é a ÚNICA causa, nem pra descartá-la
completamente. **Pode haver mais de uma fonte contribuindo pro mesmo sintoma** (o mutex de ordenação
da arena em `simuliface.c`, `m_arenaOrderLock`, e seus laços de espera ocupada em
`waitForQueueDrain()`/`readReg()` -- lidos nesta rodada mas NÃO instrumentados -- são candidatos
igualmente plausíveis e ainda não descartados).

**Estado ao final desta rodada**: nenhum fix de causa raiz implementado -- a evidência ainda não é
conclusiva o bastante pra justificar uma mudança no mecanismo de sincronização Core↔QEMU (que a tarefa
original pede pra só alterar com evidência direta e justificativa formal). Instrumentação de
diagnóstico nova (não commitada, precisa de decisão de manter/reverter):
`core/src/simulation/Scheduler.hpp`/`.cpp` (campo `m_maxSettleNanoseconds`,
`MetricsSnapshot::maxSettleNanoseconds`), `core/test/core/mcu/SessionRestartStressTest.cpp` (print de
métricas por-ciclo). `session_restart_stress_test.exe` recompilado (MSBuild, projeto individual, não a
solução inteira) com sucesso. Nenhum processo órfão. ~32GB livres em disco. Dois crashes do
`fifo8_pop` pré-existente (não relacionado) interromperam ambas as baterias -- nenhum travamento de
tela, nenhum órfão remanescente.

**Próximo passo mínimo e objetivo**: coletar uma amostra maior (baterias mais longas, ou repetidas,
idealmente rodando ATÉ reproduzir um "GPIO13 TRAVOU" com `maxSettleNanoseconds` correspondentemente
anômalo NO MESMO ciclo) pra confirmar ou refutar definitivamente a correlação -- e, em paralelo,
instrumentar os laços de espera ocupada de `simuliface.c` (`waitForQueueDrain()`/`readReg()`'s wait,
`m_arenaOrderLock`) com a MESMA técnica de medição de duração máxima, já que continuam sendo candidatos
plausíveis e ainda não descartados por dados diretos.

#### 32.5.19 Rodada diagnóstica correlacionada de 200 ciclos -- Core↔QEMU sync REFUTADO como causa;
Guru Meditation Error é discriminador perfeito (9/9 falhas vs 0/143 passes visíveis); PC do panic e da
espera mais persistente convergem em `adc_ll.h` -- hipótese ADC revivida com evidência muito mais forte
que a de 32.5.16/32.5.17 (2026-07-27, pedido explícito e detalhado do usuário, critérios de correlação
pré-definidos antes da análise)

**Fix independente aplicado antes da bateria (não misturado com o resto)**: causa raiz do crash
pré-existente `fifo8_pop` (documentado desde 32.5.8 como "bug genérico do QEMU, não deste fork" --
na verdade É deste fork) finalmente encontrada em `hw/char/esp32_uart.c`: `esp32_uart_reset()` cancela
`throttle_timer` mas nunca cancelava `tx_timer` -- se um byte estava em trânsito no momento de um
reset, o timer permanecia agendado e disparava DEPOIS do reset, chamando `uart_tx_timer_cb() ->
fifo8_pop(&s->tx_fifo)` numa fifo que `fifo8_reset()` acabara de esvaziar. Corrigido cancelando
`tx_timer` também. Validado ao longo de TODA a bateria de 200 ciclos desta rodada (ver abaixo): zero
crashes `fifo8_pop`. **Fica como commit independente, não misturado com a instrumentação de
sincronização.**

**Instrumentação `[WAIT-DIAG]` implementada** (métricas agregadas, só o maior valor de cada tipo,
sem `fprintf` no caminho rápido -- só quando uma espera de verdade acontece, e só imprime ao bater um
novo máximo): `waitForQueueDrain()`, `readReg()` e `waitForSynch()` (só o ramo "fila cheia", que é o
único que efetivamente espera) em `simuliface.c`, registrando duração, tempo virtual de início/fim,
núcleo, PC e ocupação da fila. Do lado Core, `Scheduler::MetricsSnapshot` ganhou `maxSettleAtNowNs`
(tempo virtual do Scheduler no INÍCIO da chamada de settle mais longa) além do `maxSettleNanoseconds`
já existente (32.5.18) -- permite situar cada settle longo na mesma linha do tempo virtual das esperas
QEMU (`m_nowNs` é alimentado pelos mesmos eventos da fila que carregam `simuClockNs()` do lado QEMU,
então os dois valores são diretamente comparáveis sem precisar alinhar relógios de parede entre
processos). `SessionRestartStressTest.cpp` ganhou timestamps de borda do GPIO13 (`gpioFirstHighNowNs`,
`gpioFirstLowAfterHighNowNs`, `gpioLastEdgeNowNs`) na mesma linha do tempo virtual, impressos
incondicionalmente a cada ciclo junto com as métricas do Scheduler.

**Bateria**: 200 ciclos em 4 lotes de 50 (firmware real `merged.bin`, MTTCG,
`LASECSIMUL_STRESS_RUN_MS=5000`, `LASECSIMUL_STRESS_GPIO_GRACE_MS=3000`), critério de parada "200
ciclos OU 10 falhas, o que vier primeiro" -- atingiu 200 ciclos primeiro (9 falhas, abaixo de 10).
Lote 1 sem `LASECSIMUL_TEST_VERBOSE` (só as 2 falhas desse lote têm log QEMU bruto); lotes 2-4 COM
verbose (todos os 150 ciclos, passem ou falhem, têm log QEMU completo incluindo `[WAIT-DIAG]`) --
necessário porque `qemuLogs()` só é impresso incondicionalmente com verbose, e sem essa mudança não
havia NENHUMA visibilidade das esperas QEMU em ciclos que passaram, tornando impossível aplicar os
critérios de correlação pré-definidos (que exigem comparar contra a população de ciclos aprovados).
**Resultado agregado**: 0/200 falharam ao iniciar, 0/200 travaram no meio, 9/200 (4,5%) falharam no
GPIO13, 0/200 deixaram estado sujo após Stop, **zero crashes `fifo8_pop`** (fix validado).

**Critérios de correlação pré-definidos** (antes de olhar os dados): forte = a mesma espera anômala
aparece imediatamente antes da maioria das falhas e raramente em ciclos aprovados; fraca = aparece em
ambas as populações sem relação temporal consistente; nenhuma = ciclos com falha não mostram espera
anômala antes do travamento.

**Distribuição PASS (n=191, 143 com visibilidade `[WAIT-DIAG]`) vs FAIL (n=9, todas com visibilidade)**:
- `maxSettleNanoseconds` (maior chamada individual de settle): PASS mediana 2,61ms / p90 3,17ms / máx
  124,4ms -- FAIL mediana 2,71ms / p90 457,4ms / máx 457,4ms. **Medianas praticamente idênticas.**
- Settle anômalo no boot (`maxSettleAtNowNs==0`, ou seja o maior settle do ciclo aconteceu ANTES de
  qualquer evento, em t=0): PASS 1/191 (0,5%) -- FAIL 3/9 (33%). Taxa elevada mas presente em só 1/3
  das falhas, e sempre segundos ANTES da última borda do GPIO13 (não "imediatamente antes").
- `synchFull` (espera de fila cheia em `waitForSynch()`) >100ms: PASS 81/143 (57%) -- FAIL 6/9 (67%).
  Magnitudes se sobrepõem quase totalmente (PASS p90=694ms, FAIL p90=991ms, PASS atinge até 990ms).
- `queueDrain` >100ms: PASS 74/143 (52%) -- FAIL 9/9 (100%). Taxa mais alta nas falhas, mas ainda
  presente em mais da metade dos ciclos aprovados, com magnitudes igualmente sobrepostas (PASS
  atinge até 1193ms, mais que o máximo das falhas).
- `readReg` >100ms: PASS 36/143 (25%) -- FAIL 2/9 (22%). **Taxas praticamente idênticas.**
- Ordem causa/consequência (comparando o início de cada espera-máxima contra `gpioLastEdgeNowNs` de
  cada ciclo que falhou): em NENHUMA das 9 falhas o `queueDrain` ou `synchFull` mais longo ocorre
  inteiramente ANTES da última borda do GPIO13 (2/9 "atravessam" a borda, o resto ocorre inteiramente
  DEPOIS) -- ou seja, quando aparecem em ciclos que falham, essas esperas são majoritariamente
  **consequência** (o processo já estava travado), não causa.

**Achado colateral que explica o "settleIterations/eventsProcessed maiores nas falhas"**: a SOMA
cumulativa (não o máximo) de iterações/eventos processados é ~2,5-3x maior em ciclos que falham
(mediana `settleIterations` 22891 vs 9009; `eventsProcessed` 25683 vs 8622) -- inicialmente parecia
um sinal forte, mas é explicado por um mecanismo totalmente diferente: contagem de reset do ESP32
(`[ESP32 reset] count=N`) mostra que ciclos aprovados nunca passam de `count=4` (91% ficam em
`count=2`), enquanto **5 das 9 falhas atingem `count=5`** -- ou seja, o firmware genuinamente
faz um SEGUNDO boot completo (panic + auto-reboot) dentro da mesma janela de 8s do ciclo, processando
o dobro de eventos só por isso. É consequência do panic, não causa.

**O discriminador real, 100% consistente**: "Guru Meditation Error" aparece em **9/9 (100%) dos
ciclos que falharam** e em **0/143 (0%) dos ciclos aprovados com visibilidade completa** (todos os
150 ciclos dos lotes 2-4, rodados com verbose). Dos 9 panics: 8 são "Interrupt wdt timeout on CPU1"
(expiração genuína do watchdog de interrupção do TIMER_GROUP1, confirmando o mecanismo já estabelecido
em 32.5.17) e 1 é "Double exception" no Core 0 (modo de falha distinto, PC resolvido pra
`_xt_context_save` -- só o ponto de entrada da exceção, não informativo sobre o disparo original).

**Achado novo mais promissor desta rodada**: resolvendo os PCs dos 8 panics de watchdog via
`xtensa-esp32-elf-addr2line` contra `merger.elf` (firmware real), TODOS caem em `adc_ll.h`:
`adc_ll_set_controller` (linhas 609-610) e `adc_oneshot_ll_get_raw_result` (linha 487). Mais: o PC
mais frequentemente capturado durante as maiores esperas `queueDrain` ao longo de TODA a bateria
(`0x40121cc4`, visto dezenas de vezes em ciclos aprovados E reprovados) resolve pra
`adc_oneshot_ll_set_channel` (linha 403) -- **o MESMO arquivo/região de código**. Isso revive a
hipótese de ADC já explorada e refutada em 32.5.16/32.5.17 -- mas aquela refutação se apoiava numa
ÚNICA amostra (`SENS_SAR_SLAVE_ADDR1_REG` não modelado, PC de uma única captura correspondendo a uma
instrução de escrita simples). Esta rodada tem 200 ciclos de evidência estatística agregada apontando
consistentemente pro mesmo arquivo HAL -- merece uma investigação dedicada (fora do escopo desta
rodada, que era limitada à correlação com o mecanismo de sincronização Core↔QEMU).

**Aplicação dos critérios pré-definidos**: nenhum dos três mecanismos de espera de `simuliface.c`
nem a duração do settle do Core atinge o patamar de correlação FORTE (mesma anomalia imediatamente
antes da maioria das falhas, rara nos aprovados) -- todos aparecem em taxas e magnitudes
substancialmente sobrepostas entre as duas populações, e quando aparecem em ciclos que falham,
ocorrem majoritariamente DEPOIS da última borda do GPIO13 (consequência, não causa). Classificação:
**correlação FRACA** para `queueDrain`/`synchFull`/settle-no-boot (presentes em ambas as populações,
taxa um pouco mais alta nas falhas mas sem relação temporal causal consistente); **SEM correlação**
para `readReg` (taxas e magnitudes praticamente idênticas). **O mecanismo Core↔QEMU investigado nesta
tarefa está REFUTADO como causa principal** com uma amostra estatisticamente sólida (200 ciclos).

**Mecanismo mais provável**: o watchdog de interrupção do TIMER_GROUP1 expira genuinamente dentro do
firmware emulado (confirmado, não é artefato da ponte QEMU↔Core) -- e a pista mais concreta que esta
rodada produziu pra explicar POR QUE ele expira em ~4,5% dos boots aponta pro código HAL/LL de ADC
(`adc_ll.h`) do firmware real, não para o mecanismo de sincronização protegido por esta tarefa.

**Hipóteses descartadas nesta rodada** (com dados diretos, 200 ciclos): settle único longo do Scheduler
como causa principal (medianas idênticas PASS/FAIL); qualquer um dos três waits de `simuliface.c`
como causa principal (taxas/magnitudes sobrepostas, maioria classificada como consequência via ordem
temporal); "settleIterations/eventsProcessed maiores nas falhas" como pista causal (é consequência do
duplo-boot, confirmado via contagem de reset do ESP32).

**Recomendação objetiva de correção**: NENHUMA mudança no mecanismo de sincronização Core↔QEMU é
justificada por esta rodada -- a evidência aponta o contrário do que se suspeitava. Próximo passo
recomendado (investigação, não fix): rastrear a sequência de chamadas ADC HAL/LL do firmware real
(`adc_ll_set_controller`/`adc_oneshot_ll_set_channel`/`adc_oneshot_ll_get_raw_result`) contra o modelo
de registradores SENS/ADC deste fork (`hw/misc/esp32_sens.c` ou equivalente) em busca de um gap de
modelagem que prenda a tarefa dona do watchdog dentro do HAL. Investigar separadamente o caso minoritário
de "Double exception" (1/9), que pode ser um modo de falha distinto.

**Decisão sobre a instrumentação desta rodada** (nenhuma foi commitada):
- `[WAIT-DIAG]` em `simuliface.c`: **recomenda-se reverter** -- cumpriu seu propósito diagnóstico
  (excluir o mecanismo de sincronização como causa principal com alta confiança) e não mostrou
  correlação forte o bastante pra justificar virar telemetria permanente.
- `Scheduler::maxSettleNanoseconds`/`maxSettleAtNowNs`: custo desprezível (lock-free, sem I/O no
  caminho quente) -- **recomenda-se manter** como telemetria permanente de baixo custo, útil para
  detectar regressões futuras de settle.
- Timestamps de borda do GPIO13 em `SessionRestartStressTest.cpp`: **recomenda-se manter**, mesmo
  raciocínio de custo desprezível e utilidade comprovada nesta rodada.
- Fix do `fifo8_pop` (`hw/char/esp32_uart.c`): validado, **pronto para commit independente**.
- Decisão final de manter/reverter/commitar cabe ao usuário -- nada foi commitado nesta rodada.

**Estado ao final desta rodada**: `qemu-system-xtensa.exe` recompilado com `[WAIT-DIAG]` completo
(SHA-256 `5C00BD199E0ECDB7BE278349E2D96DEE853CB41B7A33F429990AD1396DA5F77B`, `BUILD-PROVENANCE.txt`
atualizado, implantado em `run-ucrt64/` e `devices/qemu-esp32/bin/`).
`session_restart_stress_test.exe` recompilado (MSBuild, projeto individual) com as métricas de
`maxSettleAtNowNs` e timestamps de GPIO13. Nenhum processo órfão antes/depois da bateria. Dados brutos
das 4 baterias (logs completos, script de parsing Python, JSON estruturado de 200 ciclos e relatório
de distribuição) preservados em
`C:\Users\JOSUEM~1\AppData\Local\Temp\claude\c--SourceCode-LasecSimul-extension\38a1d3b1-ebc6-40eb-a397-305631658a60\scratchpad\wait-diag-battery\`.
Nada commitado (nem o fix do `fifo8_pop`, nem a instrumentação `[WAIT-DIAG]`/Scheduler/teste) --
aguardando decisão do usuário.

**Atualização pós-decisão do usuário ("pode prosseguir")**: ações executadas conforme recomendado
acima. `[WAIT-DIAG]` revertido em `softmmu/simuliface.c` (`git checkout --`, diff limpo, nada
residual). `hw/char/esp32_uart.c` (fix `fifo8_pop`) commitado sozinho, commit `3674866`
("fix(esp32-uart): cancel tx_timer on reset to prevent fifo8_pop assertion crash"). `qemu-system-
xtensa.exe` recompilado sem `[WAIT-DIAG]` (SHA-256
`7274F9267B6B794BD6AE10A565EEF753BD5C7B39E6B18CB3760F89E02948744F`, `BUILD-PROVENANCE.txt`
atualizado, implantado em `run-ucrt64/` e `devices/qemu-esp32/bin/`). `Scheduler.cpp`/`.hpp` +
`SessionRestartStressTest.cpp` (telemetria `maxSettleNanoseconds`/`maxSettleAtNowNs` + timestamps de
GPIO13) commitados juntos no repositório do Core, commit `54b561a` ("test(scheduler): add max single-
settle duration/position telemetry"). Demais arquivos de instrumentação pré-existentes de rodadas
anteriores (`esp32.c`, `esp32_dport.c`, `esp32_intc.c`, `esp32_timg.c`, `esp32_crosscore_int.c`,
`exc_helper.c`, `translate.c`, `helper.h`, os dois `.h`) permanecem NÃO commitados, fora do escopo
desta decisão -- fazem parte do plano original de "cinco commits separados" ainda pendente. O binário
implantado (`devices/qemu-esp32/bin/qemu-system-xtensa.exe`) e seu `BUILD-PROVENANCE.txt` também
permanecem não commitados no repositório do Core (o binário reflete uma mistura de mudanças ainda não
todas destinadas a commit individual).

**Investigação de continuação (mesma autorização "pode prosseguir") -- mecanismo causal completo
encontrado**: lendo `hw/misc/esp32_sens.c` (o modelo de ADC/SENS deste fork, 145 linhas), confirma-se
que **toda leitura de `SENS_MEAS1_START_SAR`/`SENS_MEAS2_START_SAR` (offsets 0x54/0x94) chama
`readReg()`** -- um round-trip SÍNCRONO e bloqueante pro processo Core via a arena (o mesmo mecanismo
medido nesta rodada, capaz de durar até ~1s em ~25-50% dos ciclos, PASSE ou FALHE). Este padrão não é
exclusivo do ADC: `grep` confirma `readReg`/`writeReg` usados também em `esp32_gpio.c`, `esp32_i2c.c`,
`esp32_iomux.c`, `esp32_ledc.c`, `esp32_spi.c`, `esp32_uart.c` -- é o mecanismo GERAL de qualquer
registrador cujo estado é refletido pela simulação elétrica do Core, não um caso especial do ADC.

Lendo o driver REAL (`esp-idf/components/esp_adc/adc_oneshot.c`, `adc_oneshot_read()` linhas 213-244):
a sequência inteira -- `adc_oneshot_hal_setup()` (que chama `adc_oneshot_ll_set_channel`/
`adc_ll_set_controller`, exatamente os PCs onde os panics desta rodada foram capturados) seguida de
`adc_oneshot_hal_convert()` (que chama `adc_oneshot_ll_get_raw_result`, o outro PC dos panics) -- roda
inteira dentro de **`portENTER_CRITICAL(&rtc_spinlock)` / `portEXIT_CRITICAL(&rtc_spinlock)`**
(linhas 221/240), ou seja, **com interrupções desabilitadas no núcleo que executa**. Em hardware real
essa seção crítica dura microssegundos (registrador de verdade, sem I/O). Neste fork, CADA acesso a
registrador dentro dela é um round-trip síncrono pro processo Core, que ocasionalmente (dados desta
mesma rodada) leva até ~1s.

**Mecanismo causal completo, agora mecanisticamente verificado (não só correlacional)**: quando o
round-trip síncrono de UM desses acessos a registrador coincide, por azar, com estar dentro da seção
crítica do `adc_oneshot_read()`, as interrupções ficam desabilitadas nesse núcleo por até ~1s de tempo
de parede real -- e como o TIMER_GROUP1 Interrupt Watchdog existe especificamente pra detectar
"interrupções não atendidas por tempo demais", e o "tempo" que ele mede é o relógio virtual do QEMU
(que sob `mttcg-realtime` é essencialmente tempo de parede real, não pausado por nada em
`simuliface.c`), um atraso de ~1s facilmente ultrapassa o orçamento típico do Interrupt WDT (tipicamente
300-400ms no framework Arduino-ESP32 usado por este firmware) -- **disparando um panic "Interrupt wdt
timeout" genuíno e corretamente modelado, não um bug na emulação do watchdog ou da matriz de
interrupções**. Isso explica TODOS os achados desta rodada de uma vez: por que nenhuma espera
individual isolada discrimina fortemente PASSE/FALHA (qualquer um dos registradores tocados dentro de
QUALQUER seção crítica do firmware é um candidato, não só ADC -- o que importa é a COINCIDÊNCIA
temporal com uma seção crítica, não a magnitude isolada da espera); por que os PCs dos panics e da
espera `readReg` mais recorrente convergem em `adc_ll.h` (é a seção crítica mais longa/mais chamada
deste firmware específico, não uma propriedade especial do ADC); e por que a taxa de falha é baixa e
probabilística (~4,5%) -- precisa da coincidência entre um round-trip lento E uma seção crítica ativa
no momento exato.

**Isto não foi implementado como fix nesta rodada** -- é uma mudança arquitetural no mecanismo
Core↔QEMU (exatamente a classe de mudança que a tarefa original pede pra só fazer com evidência direta
e justificativa formal, o que agora existe). Candidatos de correção a avaliar numa futura rodada,
preservando ordenação/determinismo/sincronismo: (a) tornar os round-trips de registrador dentro de
seções críticas do guest mais previsíveis/limitados em duração (não elimináveis, já que o valor real
vem do Core); (b) investigar se o atraso ocasional de ~1s em si tem uma causa raiz PRÓPRIA e corrigível
(ex.: por que o Core ocasionalmente demora tanto pra responder um `readReg`/drenar a fila -- pode ser
contenção de agendamento do host, não um bug de lógica) reduzindo a CAUSA do round-trip lento em vez de
mudar o protocolo de sincronização; (c) nenhuma mudança deve ser feita sem nova autorização explícita,
dado o histórico desta tarefa de proteger este mecanismo especificamente.

#### 32.5.20 Fix implementado e validado -- Scheduler solta/reobtém `m_mutex` por iteração do settle
(candidato (b) refinado; autorização explícita do usuário "pode corrigir", com escolha de abordagem
via pergunta direta entre três opções de risco distinto) (2026-07-27)

**Investigação da causa exata do bloqueio, antes de escolher a correção**: lendo
`core/src/mcu/McuComponent.cpp`/`.hpp` (`pollStepLocked()`, `runBackgroundPollLoop()`), confirmado que
a thread de poll do MCU, ao despachar um evento da arena síncrona (caminho direto, sem `deferred`,
usado pelo callback disparado na própria thread do Scheduler -- ver `startPolling()`), chama
`m_scheduler.markDirty(m_componentIndex)` **diretamente**, que precisa de `Scheduler::m_mutex`
(`Scheduler::markDirty()`, `Scheduler.hpp`). Esse é o MESMO mutex que `settleUntilStableLocked()`
segura pelo laço inteiro (até 20 iterações, 100-700ms observados em 32.5.18). Enquanto o settle
segura o mutex, `markDirty()` fica bloqueado, e a thread de poll -- presa nessa chamada -- **para de
consumir a fila da arena**, exatamente a causa do `queueDrain`/`synchFull` de ~1s medidos em 32.5.19.

**Três abordagens de correção apresentadas ao usuário** (pergunta direta, ver ferramenta de pergunta):
(A) soltar/reobter `Scheduler::m_mutex` uma vez por iteração do settle; (B) mutex separado só para
`m_dirty`, desacoplado do `Scheduler::m_mutex` grande; (C) não mexer em concorrência agora, investigar
só por que o settle é ocasionalmente lento. **Usuário escolheu (A)** -- menor escopo de mudança,
preserva a lógica de convergência e a ordem dos eventos, reusa um padrão já existente no próprio
arquivo (`processNextEventUntilLocked` já solta/reobtém o lock ao redor de um callback).

**Implementação**: `Scheduler::settleUntilStableLocked()` passou a receber
`std::unique_lock<std::mutex>& lock` (mesmo padrão de `processNextEventUntilLocked`). Ao final de cada
iteração que vai continuar (logo depois de `m_settleStep()` retornar true -- nunca no caminho já
convergido/interrompido), chama `lock.unlock(); lock.lock();`. Os dois call sites (`runUntil()`,
antes do laço e dentro dele) passam `lock`. Verificado ANTES de implementar que isso não reabre nenhum
dos deadlocks já documentados nesta função: `m_stopRequested`/`m_paused` são atômicos, checados sem
lock, não afetados; `m_commandDrain()` continua chamado sempre com o lock já reobtido (mesmo
comportamento de antes); os comentários em `SimulationSession.cpp:301-309`/`:1173-1178` (uso de
`dirtySet()` em vez de `markDirty()` dentro do próprio `drainCommandQueue()`, pra evitar lock
não-reentrante) continuam válidos porque o lock já está reobtido no momento em que `m_commandDrain()`
roda -- a invariante "esta thread já segura o mutex" não muda, só passa a ser solta e reconquistada
entre as chamadas de `m_settleStep()`.

**Validação**: `scheduler_test.exe` (suíte completa, inclui teste dedicado de settle não-convergente)
passou sem alteração de comportamento. Bateria de validação de 200 ciclos (mesmo firmware real, mesmos
parâmetros da bateria de 32.5.19, pra comparação direta): **3/200 (1,5%) falhas de GPIO13**, contra
**9/200 (4,5%) da bateria anterior sem o fix** -- redução de ~3x. As 3 falhas remanescentes mostram a
MESMA assinatura ("Interrupt wdt timeout"), não um novo modo de falha -- consistente com o mecanismo
ser probabilístico por natureza (depende de o SO realmente ceder a thread durante a janela de
unlock/lock, não uma garantia) e com haver, possivelmente, outras fontes menores do mesmo tipo de
atraso ainda não cobertas por este fix específico (ex.: um único `m_settleStep()` individualmente
lento, não apenas many-iteration overhead). Zero crashes `fifo8_pop`, zero falhas de boot, zero estado
sujo pós-Stop nos 200 ciclos.

**Decisão**: fix mantido e commitado (redução real e mensurável, sem regressão detectada). Não
elimina 100% o sintoma -- é uma mitigação da CAUSA identificada, não uma garantia absoluta, dado que o
mecanismo de fundo (round-trip síncrono ocasionalmente lento) continua existindo por design. Candidatos
(a)/(b) do achado anterior permanecem como possíveis reduções adicionais pra uma rodada futura, caso a
taxa residual de ~1,5% ainda seja considerada alta demais.

**Commit**: `core/src/simulation/Scheduler.cpp`/`.hpp`, repositório LasecSimul (Core).

#### 32.5.21 Investigação do caso minoritário "Double exception" (1/9 da bateria de 32.5.19) --
mesmo mecanismo de fundo, manifestação diferente (2026-07-28)

**Escopo**: das 9 falhas da bateria de 200 ciclos (32.5.19), 8 eram "Interrupt wdt timeout" (já
investigado e mitigado em 32.5.20) e 1 (ciclo global 145, `batch3` local 45) era um panic diferente:
"Guru Meditation Error: Core 0 panic'ed (Double exception)". Não tinha sido investigada até agora.

**Dados do register dump (ambos os núcleos, capturados simultaneamente no mesmo panic)**:
- Core 0: `EXCCAUSE=0x02` (InstructionFetchErrorCause) em `PC=0x40094bd6`, `EXCVADDR=0xffffffd0`
  (endereço de fetch claramente inválido/corrompido -- equivale a -48 como inteiro com sinal).
- Core 1: `EXCCAUSE=0x06` (IntegerDivideByZeroCause) em `PC=0x40094bcd` -- **9 bytes antes do PC do
  Core 0**, e seu backtrace mostra um frame corrompido (`0x0004001d:0x3ffbd620 |<-CORRUPTED`, endereço
  de retorno claramente inválido).

Resolvendo os dois PCs via `addr2line` contra `merger.elf`: **os dois caem em `_xt_context_save`**
(`esp-idf/components/xtensa/xtensa_context.S`, linhas 199-203) -- a rotina de baixíssimo nível (pura
montagem, chamada no início de QUALQUER exceção/interrupção antes de qualquer código C) que salva o
contexto da CPU na pilha. Os dois núcleos presos quase no MESMO PC dessa rotina, com valores de
registrador/pilha visivelmente corrompidos (endereço de fetch e de retorno ambos lixo), é o padrão
esperado de uma condição de corrida/inconsistência entre os dois núcleos durante o salvamento de
contexto -- não uma instrução real decodificada de código válido.

**Correlação com o mesmo mecanismo já identificado**: os dados de `[WAIT-DIAG]` deste MESMO ciclo
mostram exatamente o mesmo padrão de esperas gigantes já usado pra explicar os 8 panics de watchdog:
`queueDrain` de 214ms seguido de `readReg` de 367ms seguido de `synchFull` de 982ms, praticamente
consecutivos (tempo virtual ~2,6s-4,35s) -- mais de 1,5s de tempo de parede real com a fila da arena
travada. O PC capturado durante essas esperas (`0x400decd6`) resolve pra `gpio_ll_get_level`
(`hal/gpio_ll.h:537`) -- confirma, de novo, que o padrão de round-trip síncrono lento NÃO é exclusivo
do ADC (aqui é uma leitura de GPIO comum, `digitalRead()`), é geral a qualquer registrador MMIO.

**Conclusão**: a evidência (mesma assinatura de espera precedente, mesma classe de "tempo real
congelado por >1s enquanto o guest continua avançando seu próprio relógio virtual") aponta fortemente
pra **o mesmo mecanismo causal de 32.5.19/32.5.20** -- só que, desta vez, a coincidência de tempo
caiu de um jeito que corrompeu o salvamento de contexto entre os dois núcleos (ex.: uma IPC/interrupção
cross-core que dependia de uma janela de tempo que nunca existiria em hardware real) em vez de disparar
o watchdog de forma "limpa". **Não é um bug separado** -- é a MESMA causa raiz, com uma manifestação
mais rara e mais confusa. Amostra de n=1 (não há uma segunda ocorrência pra confirmar
estatisticamente), mas a convergência de evidência (mesmo padrão de espera, mesma classe de corrupção
por atraso, nenhum outro candidato plausível) é forte o bastante pra não justificar um fix separado.

**Decisão**: nenhum fix adicional necessário -- a mitigação já commitada em 32.5.20 (Scheduler solta
o mutex por iteração do settle, reduzindo a frequência/duração das esperas gigantes) ataca a MESMA causa
raiz e deve reduzir proporcionalmente também este modo de falha mais raro. Nenhuma ocorrência de "Double
exception" apareceu na bateria de validação pós-fix (200 ciclos, 32.5.20) nem das falhas de watchdog
remanescentes -- consistente com (mas não prova estatística de, dado n=1 original) a mesma redução.
Não foi feita uma bateria dedicada pra tentar reproduzir mais casos (taxa original ~0,5%, precisaria de
centenas de ciclos adicionais só pra esse modo específico) -- fora de escopo desta rodada.

#### 32.5.22 Correção definitiva da falha residual -- publicação `dirty` não bloqueante, wakeups
linearizáveis e compensação do Interrupt WDT para MTTCG em tempo real (2026-07-28)

**Escopo da continuação**: a correção de 32.5.20 reduziu a incidência, mas ainda deixava duas janelas
distintas. Primeiro, uma ÚNICA chamada lenta de `m_settleStep()` ainda mantinha
`Scheduler::m_mutex` durante toda a chamada; soltar o mutex somente ENTRE iterações não impedia
`McuComponent::runBackgroundPollLoop()` de bloquear em `markDirty()` e parar de drenar a arena.
Segundo, `pause()`/`resume()` e `notifyCommandPending()` ainda usavam `condition_variable::notify_*`
sem que toda alteração do predicado fosse feita sob o mesmo mutex, deixando a janela de wakeup perdido
já documentada no código.

**Correções no Scheduler**:

- `markDirty()` tenta publicar diretamente em `m_dirty` com `m_mutex.try_lock()`. Se uma iteração do
  solver já segura o mutex, publica em um segundo `SparseSet`, `m_pendingDirty`, protegido por um
  mutex curto e independente. O produtor da arena, portanto, não espera uma iteração elétrica longa.
- `mergePendingDirtyLocked()` incorpora essas marcações no início, depois de cada callback e antes de
  qualquer decisão de convergência/espera. Duplicatas continuam colapsadas com a mesma semântica de
  `SparseSet`; `dirty()`/`dirtyCount()` consideram os dois conjuntos.
- O wake da worker passou de `condition_variable` para um contador monotônico
  `std::atomic<uint64_t> m_workGeneration`, com `atomic::wait()`/`notify_all()`. A geração é lida
  ANTES da inspeção de estado: um sinal ocorrido antes do bloqueio muda o valor e faz `wait(valor)`
  retornar imediatamente, fechando as janelas de wakeup perdido de idle, pause/resume, comando e stop
  sem obrigar `pause()` a esperar pelo mutex do settle.
- Foi acrescentada regressão determinística em `SchedulerTest.cpp`: uma única iteração de settle fica
  bloqueada; outra thread chama `markDirty(2)` e precisa retornar em menos de 100ms, antes de a iteração
  ser liberada; depois a marca pendente precisa ser efetivamente processada.

Os testes `scheduler_test`, `mcu_component_live_poll_thread_test` e
`mcu_scheduler_pacing_sync_test` passaram. O teste concorrente processou 2.750.188 escritas de
registrador e 1.467.716 chamadas a `componentHealth()` em 4s, manteve duas MCUs saudáveis e concluiu
10 reloads ao vivo. O pacing medido foi 0,400 para alvo 0,400 e, com duas MCUs, 0,300 para a MCU mais
lenta de alvo 0,300.

**Evidência que separou a causa residual da contenção do Scheduler**: com a correção acima, uma bateria
foi interrompida depois de 88 ciclos por já reproduzir o baseline: **4/88 falhas de GPIO13
(aproximadamente 4,5%)**, nos ciclos 17, 54, 58 e 76. O ciclo 0 atravessou uma iteração única de
746ms e passou, demonstrando que a publicação não bloqueante cobre esse caso. Já as falhas tiveram
`maxSettleNanoseconds` de apenas aproximadamente 0,10-0,16ms. Logo, nesses casos, não havia espera no
mutex/solver capaz de explicar o WDT.

Os traces do ciclo 17 (`lasecsimul_xtensa_exc_trace.16744.log` e PC sampler) identificaram expiração
do **TIMER_GROUP1 Interrupt WDT** em tempo virtual 2,110s, CPU0 em `esp_cpu_wait_for_intr`. De
aproximadamente 1,54s a 1,88s, o firmware executava a sequência de desabilitar/habilitar flash/cache
enquanto a outra CPU estava parada em ROM; depois as CPUs voltaram a progredir e chegaram a idle, mas
o orçamento de watchdog medido em tempo de parede já havia sido consumido. Portanto, o caso residual
não era fila parada no Core: era uma diferença estrutural de escala temporal. Em
`mttcg-realtime`, `QEMU_CLOCK_VIRTUAL` acompanha o host, mas as instruções Xtensa de uma seção crítica
não são emuladas na velocidade do silício. Uma operação legítima de flash/cache de poucos ms no ESP32
real pode ocupar centenas de ms no host e o Interrupt WDT interpreta essa lentidão de emulação como
interrupções bloqueadas. Isso também explica o caráter probabilístico sob agendamento do host.

**Correção direcionada no QEMU** (`hw/timer/esp32_timg.c`,
`include/hw/timer/esp32_timg.h`):

- somente o watchdog do `TIMER_GROUP1` tem seu intervalo de armamento multiplicado por 8 no modo
  `mttcg-realtime`;
- `TIMER_GROUP0`, `millis()`, timers, periféricos e o relógio virtual não são alterados;
- o watchdog não é desabilitado: deadlocks continuam detectáveis, com orçamento compatível com a taxa
  de execução emulada;
- o modo `deterministic` mantém escala 1 por padrão;
- `LASECSIMUL_ESP32_WDT_SCALE=1` restaura a temporização literal para rollback/diagnóstico; valores
  entre 1 e 100 são aceitos e entradas inválidas geram warning com fallback seguro;
- o QEMU imprime a escala efetiva ao realizar o TIMER_GROUP1.

**Validação fim a fim**: o primeiro QEMU corrigido foi recompilado e passou uma prova inicial de 3
ciclos, inclusive com uma iteração única de settle de 435,695ms. A bateria completa, com o mesmo
firmware real e os mesmos parâmetros (`200` ciclos, `run_ms=5000`, grace GPIO de `3000ms`), terminou:
**0/200 falharam ao iniciar, 0/200 travaram, 0/200 falharam no GPIO13 e 0/200 deixaram estado após
Stop**. Todos os pontos de falha do baseline (17, 54, 58 e 76) passaram. Uma execução adicional com
`LASECSIMUL_ESP32_WDT_SCALE=1` confirmou o caminho de rollback e também concluiu seu ciclo.

**Build de produção da v0.0.18**: antes da publicação, foi criado um worktree limpo no commit-base
QEMU `3674866`, aplicando somente a correção do WDT e a implementação funcional dos registradores
`DPORT_PRO/APP_INTR_STATUS_0` (73 linhas, patch reproduzível incluído em
`devices/qemu-esp32/patches/`). Toda a instrumentação `[CACHE-TRACE]`, `[XTENSA-EXC-TRACE]`,
`[XTENSA-PC-WATCH]` e `[XTENSA-PC-SAMPLER]` foi excluída do executável de produção. O binário final
implantado tem SHA-256
`C468F89EAA592A76C0BBEE4AA490803DB79F60C4E1D2B010CBD9DEF7DC17AE7E` e passou uma bateria adicional
de **50/50 ciclos**, com zero falha nas quatro categorias e uma iteração inicial de settle de
535,136ms. O patch aplicado, origem, opções de configuração e hash estão em `SOURCE.md` e
`BUILD-PROVENANCE.txt`, ambos embarcados no VSIX.

**Decisão**: manter as duas correções. A mudança do Scheduler remove bloqueios reais e fecha riscos de
concorrência independentemente do firmware. A mudança do QEMU corrige somente a base de tempo do
Interrupt WDT que é incompatível com a velocidade de instrução do MTTCG em tempo real, sem mascarar
outros watchdogs ou alterar a temporização observável dos periféricos. A árvore de investigação com
instrumentação permanece separada e preservada localmente, mas não faz parte da release.
