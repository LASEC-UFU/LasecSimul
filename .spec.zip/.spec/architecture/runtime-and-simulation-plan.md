---
id: ARCH-002
kind: architecture
status: active
dependsOn: [ARCH-001, ARCH-006]
supersedes: []
---

# Runtime e SimulationPlan

## Pipeline canônico

```text
AuthoringSnapshot -> Validator/Normalizer -> PlanCompiler
                  -> shared_ptr<const SimulationPlan>
                  -> RuntimeState por sessão
```

Para IEC 61131-3 existe um estágio de build anterior ao `PlanCompiler`:

```text
IecProjectAuthoring -> IecCompiler -> PlcCompiledArtifact
                                      |
AuthoringSnapshot --------------------+-> PlanCompiler -> PlcPlan
```

O `SimulationPlan` referencia somente artefatos compilados válidos; parser, AST e editor IEC não executam no hot path.

`SimulationPlan` agrega planos específicos por domínio. Não é um objeto universal que mistura estado elétrico, PLC, Python e UI.

## Conteúdo mínimo

- geração e hash da autoria normalizada;
- handles e índices densos de componentes;
- listas densas de componentes reativos, FPGA, MCU, PLC, observers e subscribers;
- `ElectricalPlan` baseado na `Netlist::Topology` existente;
- `SignalPlan`, `BridgePlan` e `ExternalBindingPlan` quando suas fases existirem;
- `PlcPlan` com instâncias, tasks, RateGroups, mappings de I/O e referências `shared_ptr<const PlcCompiledArtifact>`;
- slots tipados e mapeamentos port-to-slot;
- SCCs, ordem topológica e RateGroups;
- referências a `CompiledSubsystemTemplate` imutáveis.

`PlcPlan` nunca contém source text nem nós React/graphical editor. Interfaces de POUs e I/O já chegam resolvidas para handles/offsets da ABI.

O plano não contém processos, handles do SO, tensões, estado interno dos blocos, buffers de telemetria ou callbacks capturando objetos de autoria.

## RuntimeState

É criado para uma geração do plano e contém todo estado mutável: tempo, dirty sets, soluções MNA, slots de sinal, estados de bloco, processos externos e buffers limitados.

Para cada instância PLC contém, no mínimo:

- memória da VM;
- imagens de entrada e saída;
- estados de `FUNCTION_BLOCK` e SFC;
- timers/counters;
- estado de tasks;
- área `RETAIN` quando habilitada;
- force/watch/debug runtime.

Duas instâncias podem compartilhar o mesmo `PlcCompiledArtifact`, mas nunca a memória acima.

O coordenador é o único escritor do estado global. Workers recebem plano e snapshots somente leitura, escrevem em scratch disjunto e têm resultados commitados em ordem do plano.

## Compilação e publicação

1. Validar schema e referências.
2. Compilar autoria IEC alterada para `PlcCompiledArtifact` antes do plano.
3. Validar `formatVersion`, `abiVersion`, hashes, bytecode e interface exportada.
4. Normalizar IDs, propriedades, tipos e unidades.
5. Resolver strings para índices/handles.
6. Construir grafos por domínio.
7. Detectar SCCs e formar RateGroups.
8. Compilar planos de domínio, `PlcPlan` e bindings.
9. Publicar o plano somente se toda a compilação for bem-sucedida.

Na primeira versão, um novo plano ou novo artefato PLC só é publicado com a simulação parada. Hot-swap durante `RUN` é adiado.

## Invalidação

- visual/viewport: nenhuma recompilação;
- parâmetro runtime-safe: atualização do estado;
- período/conexão de sinal: `SignalPlan` e RateGroups;
- fio/túnel elétrico: `ElectricalPlan` afetado;
- tipo/largura/unidade: domínio e bridges relacionados;
- conteúdo de subsistema: template e dependentes;
- VHDL/toolchain: artefato GHDL;
- corpo IEC sem mudança de interface: recompila artefato + `PlcPlan`, preservando topologia externa quando `exportedIo` for idêntico;
- interface IEC/exported I/O: recompila artefato, `PlcPlan`, endpoints e bindings afetados;
- task/resource IEC: recompila artefato e schedule do `PlcPlan`.

Incrementalidade inicial é por domínio. Recompilação fina por POU/SCC só entra com benchmark, embora cache por hash de POU seja permitido se não mudar semântica.

## Aceitação

- nenhuma resolução de alias/string no hot path do Signal Engine ou PLC VM;
- nenhuma varredura global para localizar reativos, FPGA ou PLC a cada passo;
- falha de compilação IEC preserva plano/runtime anterior;
- duas instâncias do mesmo artefato possuem estado PLC isolado;
- troca de implementação de um POU entre linguagens, mantendo interface e comportamento, não altera bindings externos;
- execução idêntica com 1, 2 e N workers dentro das tolerâncias numéricas fixadas.
